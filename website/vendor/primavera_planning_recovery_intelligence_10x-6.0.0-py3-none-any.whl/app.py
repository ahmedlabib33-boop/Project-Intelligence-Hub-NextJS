from __future__ import annotations

import json
import logging
import os
from pathlib import Path
import threading
import time
import uuid
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse, Response
from pydantic import BaseModel, ConfigDict, Field

from ai.providers import ask_with_fallback
from core.calendar_engine import add_workdays
from core.cpm import calculate_cpm
from core.errors import InvalidDecisionError, ScheduleError, ScenarioValidationError
from core.exporter import schedule_to_excel_bytes
from core.integrity import (
    append_audit_event,
    schedule_fingerprint,
    validate_history_unchanged,
    verify_audit_chain,
)
from core.models import ProjectSchedule
from core.package_export import build_final_recovery_package
from core.qa import schedule_quality
from core.recovery import apply_scenario, generate_recovery_scenarios, validate_scenario
from core.recovery_session import RecoverySession, new_session, process_decision, stage_question
from core.reporting import build_docx_bytes, build_pdf_bytes, build_report_data
from core.utils import clean_text, safe_filename, utc_now_iso
from core.version import BUILD_NAME, ENGINE_ID, ENGINE_NAME, VERSION
from core.xer import parse_xer_bytes
from core.xer_writer import build_recovered_xer_bytes, build_xer_integrity_manifest
from core.schedule_import import parse_csv_schedule_bytes, parse_xlsx_schedule_bytes, parse_xml_schedule_bytes
from core.document_intelligence import extract_document_pack, evidence_summary
from core.tender_builder import build_tender_schedule
from core.schedule_doctor import build_repair_plan, apply_repairs
from core.data_vault import build_schedule_data_vault
from core.report_studio import inspect_template, load_report_data, render_template


LOGGER = logging.getLogger("primavera_recovery_50x")
STARTED_AT = time.monotonic()
MAX_UPLOAD_BYTES = max(1_000_000, int(os.getenv("PRI_MAX_UPLOAD_BYTES", str(100 * 1024 * 1024))))
MAX_SCHEDULES = max(5, int(os.getenv("PRI_MAX_IN_MEMORY_SCHEDULES", "60")))
MAX_EVIDENCE_PACK_BYTES = max(MAX_UPLOAD_BYTES, int(os.getenv("PRI_MAX_EVIDENCE_PACK_BYTES", str(500 * 1024 * 1024))))
FRONTEND = Path(__file__).parent / "frontend" / "index.html"

app = FastAPI(
    title=ENGINE_NAME,
    version=VERSION,
    description="Deterministic Primavera schedule QA, CPM, recovery simulation, audit and conservative XER export.",
)

_LOCK = threading.RLock()
STORE: Dict[str, ProjectSchedule] = {}
STORE_CREATED_AT: Dict[str, str] = {}
LAST_RECOVERY: Dict[str, Dict[str, Any]] = {}
ACTION_LOG: Dict[str, List[Dict[str, Any]]] = {}
RECOVERY_SESSIONS: Dict[str, RecoverySession] = {}
REPORT_CONTEXT: Dict[str, Dict[str, Any]] = {}
MASTER_FINGERPRINTS: Dict[str, str] = {}
ACCEPTED_FINGERPRINTS: Dict[str, str] = {}
EVIDENCE_STORE: Dict[str, List[tuple[str, bytes]]] = {}


class StrictRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class RecoveryRequest(StrictRequest):
    schedule_id: str = Field(min_length=1, max_length=128)
    target_recovery_days: float = Field(default=0.0, ge=0.0, le=3650.0)
    near_critical_threshold: float = Field(default=5.0, ge=0.0, le=365.0)


class RecoveryStartRequest(StrictRequest):
    schedule_id: str = Field(min_length=1, max_length=128)
    target_recovery_days: float = Field(default=0.0, ge=0.0, le=3650.0)


class RecoveryDecisionRequest(StrictRequest):
    recovery_session_id: str = Field(min_length=1, max_length=128)
    decision: str = Field(min_length=1, max_length=100)
    payload: Dict[str, Any] = Field(default_factory=dict)
    expected_state_version: Optional[int] = Field(default=None, ge=1)


class ExplainRequest(StrictRequest):
    schedule_id: str = Field(min_length=1, max_length=128)
    question: str = Field(min_length=1, max_length=5000)


class ApplyScenarioRequest(StrictRequest):
    schedule_id: str = Field(min_length=1, max_length=128)
    scenario_id: str = Field(min_length=1, max_length=255)
    approved: bool = False
    approved_by: str = Field(default="", max_length=500)
    approval_reference: str = Field(default="", max_length=2000)


class AcceptResultRequest(StrictRequest):
    schedule_id: str = Field(min_length=1, max_length=128)
    accepted: bool = True
    reviewer: str = Field(default="", max_length=500)
    approval_reference: str = Field(default="", max_length=2000)


class RepairApplyRequest(StrictRequest):
    selected_fix_ids: List[str] = Field(default_factory=list)
    safe_only: bool = True
    approved_by: str = Field(default="", max_length=500)


@app.middleware("http")
async def security_headers(request: Request, call_next):
    request_id = request.headers.get("X-Request-ID") or uuid.uuid4().hex
    response = await call_next(request)
    response.headers["X-Request-ID"] = request_id
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Cache-Control"] = "no-store"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; "
        "script-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'"
    )
    return response


@app.exception_handler(ScheduleError)
async def schedule_error_handler(_request: Request, exc: ScheduleError):
    return JSONResponse(status_code=422, content={"detail": str(exc), "error_type": type(exc).__name__})


def _require_schedule(schedule_id: str) -> ProjectSchedule:
    with _LOCK:
        schedule = STORE.get(schedule_id)
        if schedule is None:
            raise HTTPException(404, "Schedule not found")
        return schedule


def _latest_session(schedule_id: str) -> Optional[RecoverySession]:
    with _LOCK:
        sessions = [session for session in RECOVERY_SESSIONS.values() if session.schedule_id == schedule_id]
        return sessions[-1] if sessions else None


def _evict_if_needed() -> None:
    with _LOCK:
        if len(STORE) <= MAX_SCHEDULES:
            return
        candidates = [sid for sid in STORE if sid not in ACCEPTED_FINGERPRINTS]
        candidates.sort(key=lambda sid: STORE_CREATED_AT.get(sid, ""))
        while len(STORE) > MAX_SCHEDULES and candidates:
            sid = candidates.pop(0)
            STORE.pop(sid, None)
            STORE_CREATED_AT.pop(sid, None)
            LAST_RECOVERY.pop(sid, None)
            ACTION_LOG.pop(sid, None)
            REPORT_CONTEXT.pop(sid, None)
            MASTER_FINGERPRINTS.pop(sid, None)
            EVIDENCE_STORE.pop(sid, None)
            for session_id in [key for key, value in RECOVERY_SESSIONS.items() if value.schedule_id == sid]:
                RECOVERY_SESSIONS.pop(session_id, None)


def _store_schedule(schedule: ProjectSchedule, *, schedule_id: Optional[str] = None) -> str:
    sid = schedule_id or uuid.uuid4().hex
    with _LOCK:
        STORE[sid] = schedule
        STORE_CREATED_AT[sid] = utc_now_iso()
        MASTER_FINGERPRINTS[sid] = schedule_fingerprint(schedule)
        ACTION_LOG.setdefault(sid, [])
    _evict_if_needed()
    return sid


def log_action(
    schedule_id: str,
    stage: str,
    message: str,
    requires_user_action: bool = False,
    options: Optional[List[str]] = None,
    *,
    actor: str = "ENGINE",
    details: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    event = {
        "time": utc_now_iso(),
        "stage": clean_text(stage, 100).upper(),
        "message": clean_text(message, 8000),
        "requires_user_action": bool(requires_user_action),
        "options": [clean_text(item, 100) for item in (options or [])],
        "actor": clean_text(actor or "ENGINE", 100),
    }
    if details:
        event["details"] = details
    with _LOCK:
        stored = append_audit_event(ACTION_LOG.setdefault(schedule_id, []), event)
    LOGGER.info("[%s] %s", stored["stage"], stored["message"])
    return stored


def _public_metadata(schedule: ProjectSchedule) -> Dict[str, Any]:
    allowed = {
        "import_format", "xer_encoding", "xer_line_ending", "source_xer_sha256", "source_xer_size_bytes",
        "source_xer_text_sha256", "default_hours_per_day", "available_projects", "selected_project_internal_id",
        "external_relationship_count", "selected_activity_count", "selected_relationship_count",
        "duplicate_task_code_count", "calendar_parity", "scheduling_mode", "required_finish_date",
        "source_master_fingerprint", "applied_scenario_id", "applied_scenario_fingerprint", "revision_basis",
    }
    return {key: value for key, value in schedule.metadata.items() if key in allowed}


def schedule_summary(schedule: ProjectSchedule, near_critical_threshold: float = 5.0) -> Dict[str, Any]:
    qa = schedule_quality(schedule)
    cpm_error = None
    try:
        result = calculate_cpm(schedule, compute_path_drag=True)
    except ScheduleError as exc:
        cpm_error = str(exc)
        result = {
            "project_finish_offset_days": None, "required_finish_offset_days": None,
            "activity_count": len(schedule.activities), "relationship_count": len(schedule.relationships),
            "active_relationship_count": len(schedule.relationships), "critical_paths": [],
            "longest_path_activity_ids": [], "driving_relationships": [], "constraint_violations": [],
            "calculation_runtime_ms": None,
        }
    critical = sorted([a for a in schedule.activities.values() if a.critical], key=lambda a: (a.es, a.id))
    near = sorted([a for a in schedule.activities.values() if not a.critical and a.total_float <= near_critical_threshold], key=lambda a: (a.total_float, a.es, a.id)) if not cpm_error else []
    forecast_finish = max((a.forecast_finish for a in schedule.activities.values() if a.forecast_finish), default=None)
    if forecast_finish is None and schedule.data_date and result.get("project_finish_offset_days") is not None:
        forecast_finish = add_workdays(schedule.data_date, result["project_finish_offset_days"], schedule.get_calendar())
    return {
        "engine": ENGINE_ID, "project_id": schedule.project_id, "project_name": schedule.project_name,
        "data_date": schedule.data_date.isoformat() if schedule.data_date else None,
        "finish_offset_days": round(result["project_finish_offset_days"],3) if result.get("project_finish_offset_days") is not None else None,
        "forecast_finish": forecast_finish.date().isoformat() if forecast_finish else None,
        "required_finish_offset_days": result.get("required_finish_offset_days"),
        "activity_count": result["activity_count"], "relationship_count": result["relationship_count"],
        "active_relationship_count": result.get("active_relationship_count"), "critical_count": len(critical),
        "near_critical_count": len(near), "driving_path_count": len(result.get("critical_paths", [])),
        "longest_path_activity_ids": result.get("longest_path_activity_ids", []),
        "critical_paths": result.get("critical_paths", [])[:20], "driving_relationships": result.get("driving_relationships", [])[:200],
        "constraint_violations": result.get("constraint_violations", [])[:100], "calculation_runtime_ms": result.get("calculation_runtime_ms"),
        "schedule_fingerprint": schedule_fingerprint(schedule), "cpm_error": cpm_error,
        "critical": [{"id":a.id,"name":a.name,"duration":round(a.duration,3),"es":round(a.es,3),"ef":round(a.ef,3),"tf":round(a.total_float,3),"ff":round(a.free_float,3),"path_drag":round(a.path_drag,3),"forecast_finish":a.forecast_finish.date().isoformat() if a.forecast_finish else None} for a in critical[:150]],
        "near_critical": [{"id":a.id,"name":a.name,"duration":round(a.duration,3),"es":round(a.es,3),"ef":round(a.ef,3),"tf":round(a.total_float,3),"forecast_finish":a.forecast_finish.date().isoformat() if a.forecast_finish else None} for a in near[:150]],
        "qa": qa, "metadata": _public_metadata(schedule),
    }


async def _read_upload_limited(file: UploadFile) -> bytes:
    chunks: List[bytes] = []
    total = 0
    try:
        while True:
            chunk = await file.read(1024 * 1024)
            if not chunk:
                break
            total += len(chunk)
            if total > MAX_UPLOAD_BYTES:
                raise HTTPException(413, f"Upload exceeds the {MAX_UPLOAD_BYTES // (1024 * 1024)} MB limit")
            chunks.append(chunk)
    finally:
        await file.close()
    if not chunks:
        raise HTTPException(400, "Uploaded file is empty")
    return b"".join(chunks)


def _assert_accepted_unchanged(schedule_id: str, schedule: ProjectSchedule) -> str:
    with _LOCK:
        accepted_fingerprint = ACCEPTED_FINGERPRINTS.get(schedule_id)
    if not accepted_fingerprint:
        raise HTTPException(409, "Accept the recovered result before generating final deliverables.")
    current = schedule_fingerprint(schedule)
    if current != accepted_fingerprint:
        with _LOCK:
            ACCEPTED_FINGERPRINTS.pop(schedule_id, None)
        raise HTTPException(409, "The accepted schedule changed after acceptance. Re-review and accept it again.")
    return accepted_fingerprint


def _download_response(content: bytes, media_type: str, filename: str) -> Response:
    return Response(
        content=content,
        media_type=media_type,
        headers={
            "Content-Disposition": f'attachment; filename="{safe_filename(filename, "download")}"',
            "Content-Length": str(len(content)),
        },
    )


@app.get("/", response_class=HTMLResponse)
def home():
    if not FRONTEND.exists():
        raise HTTPException(500, "Frontend file is missing")
    return FRONTEND.read_text(encoding="utf-8")


@app.get("/api/health")
def health():
    return {
        "ok": True,
        "engine": ENGINE_NAME,
        "version": VERSION,
        "build": BUILD_NAME,
        "uptime_seconds": round(time.monotonic() - STARTED_AT, 1),
        "deterministic_schedule_authority": True,
    }


@app.get("/api/diagnostics")
def diagnostics():
    with _LOCK:
        audit_valid = sum(1 for log in ACTION_LOG.values() if verify_audit_chain(log).get("valid"))
        return {
            "engine": ENGINE_ID,
            "stored_schedules": len(STORE),
            "accepted_schedules": len(ACCEPTED_FINGERPRINTS),
            "recovery_sessions": len(RECOVERY_SESSIONS),
            "audit_logs": len(ACTION_LOG),
            "valid_audit_chains": audit_valid,
            "max_upload_bytes": MAX_UPLOAD_BYTES,
            "max_in_memory_schedules": MAX_SCHEDULES,
            "evidence_packs": len(EVIDENCE_STORE),
            "evidence_bytes": sum(len(payload) for pack in EVIDENCE_STORE.values() for _name, payload in pack),
            "max_evidence_pack_bytes": MAX_EVIDENCE_PACK_BYTES,
            "persistence": "IN_MEMORY; export the final package before application shutdown",
        }


@app.post("/api/analyze")
async def analyze(
    file: UploadFile = File(...),
    hours_per_day: float = Form(8.0, gt=0.0, le=24.0),
    project_id: str = Form(""),
):
    content = await _read_upload_limited(file)
    filename = clean_text(file.filename or "", 500)
    suffix = Path(filename).suffix.lower()
    try:
        if suffix == ".xer":
            schedule = parse_xer_bytes(
                content,
                default_hours_per_day=hours_per_day,
                project_id=clean_text(project_id, 255) or None,
            )
        elif suffix == ".json":
            schedule = ProjectSchedule.from_dict(json.loads(content.decode("utf-8-sig")))
            schedule.metadata["import_format"] = "JSON"
            schedule.metadata["source_json_size_bytes"] = len(content)
        elif suffix in {".xlsx", ".xlsm"}:
            schedule = parse_xlsx_schedule_bytes(content, filename=filename)
        elif suffix in {".csv", ".tsv"}:
            schedule = parse_csv_schedule_bytes(content, filename=filename)
        elif suffix == ".xml":
            schedule = parse_xml_schedule_bytes(content, filename=filename)
        else:
            raise HTTPException(400, "Supported schedule imports: .xer, .json, .xlsx, .xlsm, .csv, .tsv and .xml.")
        try:
            calculate_cpm(schedule)
        except ScheduleError as exc:
            schedule.metadata["cpm_import_error"] = str(exc)
    except UnicodeDecodeError:
        raise HTTPException(400, "JSON must be valid UTF-8 text") from None
    except json.JSONDecodeError as exc:
        raise HTTPException(400, f"Invalid JSON at line {exc.lineno}, column {exc.colno}") from None
    except HTTPException:
        raise
    except ScheduleError:
        raise
    except Exception as exc:
        LOGGER.exception("Unexpected import failure")
        raise HTTPException(400, f"Import failed: {type(exc).__name__}") from None

    sid = _store_schedule(schedule)
    with _LOCK:
        EVIDENCE_STORE[sid] = [(safe_filename(filename, "schedule"), content)]
    log_action(
        sid,
        "IMPORT",
        f"Imported {schedule.project_name}: {len(schedule.activities)} activities and {len(schedule.relationships)} relationships.",
        details={"filename": safe_filename(filename, "schedule"), "bytes": len(content), "format": suffix.lstrip(".").upper()},
    )
    log_action(
        sid,
        "REVIEW_GATE",
        "Initial CPM, constraints, driving paths and schedule QA are ready. Verify the Data Date and imported working basis before recovery generation.",
        True,
        ["CONTINUE_TO_RECOVERY", "STOP_AND_REVIEW"],
    )
    with _LOCK:
        summary = schedule_summary(schedule)
        actions = list(ACTION_LOG.get(sid, []))
    return {
        "schedule_id": sid,
        "summary": summary,
        "action_log": actions,
        "next_gate": {
            "title": "Review imported schedule",
            "question": "Do you accept the imported schedule fingerprint and Data Date as the recovery-analysis basis?",
            "options": ["CONTINUE_TO_RECOVERY", "STOP_AND_REVIEW"],
            "schedule_fingerprint": MASTER_FINGERPRINTS[sid],
        },
    }


@app.get("/api/schedule/{schedule_id}")
def get_schedule(schedule_id: str):
    schedule = _require_schedule(schedule_id)
    with _LOCK:
        return {
            "schedule_id": schedule_id,
            "summary": schedule_summary(schedule),
            "schedule": schedule.to_dict(include_raw_tables=False),
            "accepted": schedule_id in ACCEPTED_FINGERPRINTS,
            "action_log_verification": verify_audit_chain(ACTION_LOG.get(schedule_id, [])),
        }


@app.get("/api/schedule/{schedule_id}/compare")
def compare_schedule(schedule_id: str):
    schedule = _require_schedule(schedule_id)
    context = REPORT_CONTEXT.get(schedule_id) or {}
    base = context.get("base_schedule")
    if not isinstance(base, ProjectSchedule):
        raise HTTPException(409, "No working-basis schedule is linked to this schedule")
    with _LOCK:
        base_summary = schedule_summary(base)
        final_summary = schedule_summary(schedule)
    return {
        "source_schedule_id": context.get("source_schedule_id"),
        "scenario_id": (context.get("scenario") or {}).get("id"),
        "base": base_summary,
        "final": final_summary,
        "finish_improvement_days": round(base_summary["finish_offset_days"] - final_summary["finish_offset_days"], 3),
        "critical_count_change": final_summary["critical_count"] - base_summary["critical_count"],
        "qa_score_change": round(final_summary["qa"]["score"] - base_summary["qa"]["score"], 3),
        "history_violations": validate_history_unchanged(base, schedule),
    }


@app.post("/api/recovery/start")
def recovery_start(req: RecoveryStartRequest):
    schedule = _require_schedule(req.schedule_id)
    with _LOCK:
        session = new_session(req.schedule_id, req.target_recovery_days, schedule)
        RECOVERY_SESSIONS[session.id] = session
        question = stage_question(session, schedule)
    log_action(
        req.schedule_id,
        "RECOVERY_GATE",
        "Recovery session started. The exact schedule fingerprint and target require planner approval before strategies are tested.",
        True,
        [option["id"] for option in question.get("options", [])],
    )
    return {
        "recovery_session_id": session.id,
        "stage": session.stage,
        "state_version": session.state_version,
        "question": question,
        "decisions": session.decisions,
        "results": session.results,
        "action_log": ACTION_LOG.get(req.schedule_id, []),
    }


@app.post("/api/recovery/decision")
def recovery_decision(req: RecoveryDecisionRequest):
    with _LOCK:
        session = RECOVERY_SESSIONS.get(req.recovery_session_id)
        if session is None:
            raise HTTPException(404, "Recovery session not found")
        schedule = STORE.get(session.schedule_id)
        if schedule is None:
            raise HTTPException(404, "Schedule not found")
        if req.expected_state_version is not None and req.expected_state_version != session.state_version:
            raise HTTPException(409, f"Recovery state changed. Current state_version is {session.state_version}.")
        previous_stage = session.stage
        process_decision(session, schedule, req.decision, req.payload)
        question = stage_question(session, schedule)
        recovery_result = session.results.get("final_recovery") or session.results.get("duration_recovery")
        if recovery_result:
            LAST_RECOVERY[session.schedule_id] = recovery_result

    log_action(
        session.schedule_id,
        "RECOVERY_DECISION",
        f"{previous_stage}: planner selected {clean_text(req.decision, 100).upper()}.",
        actor="USER",
        details={"state_version": session.state_version},
    )
    if session.stage != "FINAL":
        log_action(
            session.schedule_id,
            "RECOVERY_GATE",
            question["question"],
            True,
            [option["id"] for option in question.get("options", [])],
        )
    else:
        log_action(
            session.schedule_id,
            "RECOVERY_COMPLETE",
            "Interactive recovery analysis completed. All scenarios remain unapplied until selected and explicitly approved.",
        )
    return {
        "recovery_session_id": session.id,
        "stage": session.stage,
        "state_version": session.state_version,
        "question": question,
        "decisions": session.decisions,
        "decision_log": session.decision_log,
        "results": session.results,
        "action_log": ACTION_LOG.get(session.schedule_id, []),
    }


@app.post("/api/recovery")
def recovery(req: RecoveryRequest):
    schedule = _require_schedule(req.schedule_id)
    with _LOCK:
        expected = MASTER_FINGERPRINTS.get(req.schedule_id)
        if expected and schedule_fingerprint(schedule) != expected:
            raise HTTPException(409, "The working-basis schedule changed. Re-analyze before generating recovery scenarios.")
        result = generate_recovery_scenarios(
            schedule,
            target_recovery_days=req.target_recovery_days,
            near_critical_threshold=req.near_critical_threshold,
        )
        LAST_RECOVERY[req.schedule_id] = result
    log_action(
        req.schedule_id,
        "RECOVERY",
        f"Generated {len(result['scenarios'])} deterministic recovery scenarios. No scenario was applied.",
        details={"target_recovery_days": req.target_recovery_days, "near_critical_threshold": req.near_critical_threshold},
    )
    log_action(
        req.schedule_id,
        "SCENARIO_GATE",
        "Inspect a scenario and its complete change register, then provide explicit approval before applying it to a clone.",
        True,
        ["SELECT_SCENARIO", "REGENERATE", "STOP"],
    )
    return {
        **result,
        "action_log": ACTION_LOG.get(req.schedule_id, []),
        "next_gate": {
            "title": "Recovery scenario selection",
            "question": "Which scenario will be reviewed for approval?",
            "requires_explicit_approval": True,
        },
    }


@app.post("/api/scenario/apply")
def apply_recovery_scenario(req: ApplyScenarioRequest):
    schedule = _require_schedule(req.schedule_id)
    with _LOCK:
        recovery_result = LAST_RECOVERY.get(req.schedule_id)
        if not recovery_result:
            raise HTTPException(400, "Generate recovery scenarios first")
        scenario = next((item for item in recovery_result.get("scenarios", []) if item.get("id") == req.scenario_id), None)
        if scenario is None:
            raise HTTPException(404, "Scenario not found")
        validation = validate_scenario(schedule, scenario)
    if not validation["valid"]:
        raise HTTPException(409, {"message": "Scenario validation failed", "errors": validation["errors"]})

    if not req.approved:
        log_action(
            req.schedule_id,
            "SCENARIO_REVIEW",
            f"Scenario {req.scenario_id} selected but not applied. Explicit approval is required.",
            True,
            ["APPROVE_AND_APPLY", "REJECT"],
            actor="USER",
        )
        return {
            "approval_required": True,
            "scenario": scenario,
            "validation": validation,
            "question": f"Approve Scenario {req.scenario_id} and apply its {scenario.get('change_count', 0)} change(s) to a cloned schedule?",
            "warning": "The source/master schedule remains unchanged. A separate cloned schedule will be created.",
            "action_log": ACTION_LOG.get(req.schedule_id, []),
        }

    expected_fingerprint = MASTER_FINGERPRINTS.get(req.schedule_id)
    if expected_fingerprint and schedule_fingerprint(schedule) != expected_fingerprint:
        raise HTTPException(409, "Source/master schedule changed since recovery generation. Re-analyze before applying recovery.")

    revised = apply_scenario(schedule, scenario, approved_by=req.approved_by)
    if req.approval_reference:
        for change in revised.changes[-len(scenario.get("changes", [])) :]:
            change.evidence_ref = clean_text(req.approval_reference, 2000)
    history_violations = validate_history_unchanged(schedule, revised)
    if history_violations:
        raise HTTPException(409, {"message": "Recovery changed locked history", "violations": history_violations[:20]})

    new_id = _store_schedule(revised)
    with _LOCK:
        ACTION_LOG[new_id] = [dict(event) for event in ACTION_LOG.get(req.schedule_id, [])]
        session = _latest_session(req.schedule_id)
        REPORT_CONTEXT[new_id] = {
            "source_schedule_id": req.schedule_id,
            "base_schedule": schedule.clone(),
            "scenario": dict(scenario),
            "decisions": dict(session.decisions) if session else {},
            "recovery_session_id": session.id if session else None,
            "target_recovery_days": session.target_recovery_days if session else recovery_result.get("target_recovery_days", 0.0),
            "approved_by": clean_text(req.approved_by, 500),
            "approval_reference": clean_text(req.approval_reference, 2000),
        }
    log_action(
        new_id,
        "APPLY",
        f"Approved Scenario {req.scenario_id} was applied to a new cloned schedule. The master schedule remains unchanged.",
        actor=clean_text(req.approved_by, 500) or "USER",
        details={"source_schedule_id": req.schedule_id, "scenario_fingerprint": scenario.get("scenario_fingerprint")},
    )
    log_action(
        new_id,
        "ACCEPTANCE_GATE",
        "Review the recalculated finish, driving paths, constraints, QA and change register before accepting formal deliverables.",
        True,
        ["ACCEPT_RESULT", "REJECT_RESULT", "EXPORT_XLSX_FOR_REVIEW"],
    )
    with _LOCK:
        summary = schedule_summary(revised)
    return {
        "new_schedule_id": new_id,
        "source_schedule_id": req.schedule_id,
        "scenario_id": req.scenario_id,
        "summary": summary,
        "change_count": len(revised.changes),
        "history_integrity_pass": True,
    }


@app.post("/api/ai/explain")
async def explain(req: ExplainRequest):
    schedule = _require_schedule(req.schedule_id)
    with _LOCK:
        summary = schedule_summary(schedule)
    compact = {
        "engine": ENGINE_ID,
        "project": summary["project_name"],
        "data_date": summary["data_date"],
        "forecast_finish": summary["forecast_finish"],
        "finish_offset_days": summary["finish_offset_days"],
        "critical_count": summary["critical_count"],
        "near_critical_count": summary["near_critical_count"],
        "driving_paths": summary["critical_paths"][:5],
        "constraint_violations": summary["constraint_violations"][:20],
        "qa_score": summary["qa"]["score"],
        "qa_grade": summary["qa"].get("grade"),
        "qa_issues": summary["qa"]["issues"][:30],
        "critical": summary["critical"][:25],
    }
    prompt = (
        "Deterministic schedule-engine output follows. Use only these facts:\n"
        + json.dumps(compact, indent=2, ensure_ascii=False, default=str)
        + "\n\nUser question:\n"
        + req.question
        + "\n\nLabel interventions as proposals requiring planner, constructability, safety and contractual review."
    )
    result = await ask_with_fallback(prompt)
    log_action(req.schedule_id, "AI_EXPLANATION", f"Planning explanation requested using provider {result.get('provider')}.", actor="USER")
    return result


@app.post("/api/result/accept")
def accept_result(req: AcceptResultRequest):
    schedule = _require_schedule(req.schedule_id)
    current_fingerprint = schedule_fingerprint(schedule)
    if req.accepted:
        context = REPORT_CONTEXT.setdefault(req.schedule_id, {})
        context["accepted_fingerprint"] = current_fingerprint
        context["accepted_by"] = clean_text(req.reviewer, 500)
        context["acceptance_reference"] = clean_text(req.approval_reference, 2000)
        context["accepted_at"] = utc_now_iso()
        with _LOCK:
            ACCEPTED_FINGERPRINTS[req.schedule_id] = current_fingerprint
        log_action(
            req.schedule_id,
            "ACCEPT",
            "Reviewer accepted the current schedule fingerprint. Formal deliverables are unlocked while that fingerprint remains unchanged.",
            actor=clean_text(req.reviewer, 500) or "USER",
            details={"acceptance_reference": clean_text(req.approval_reference, 2000), "fingerprint": current_fingerprint},
        )
    else:
        with _LOCK:
            ACCEPTED_FINGERPRINTS.pop(req.schedule_id, None)
        log_action(
            req.schedule_id,
            "REJECT",
            "Reviewer rejected the schedule clone. Formal accepted-report status was removed.",
            actor=clean_text(req.reviewer, 500) or "USER",
        )

    accepted = req.schedule_id in ACCEPTED_FINGERPRINTS
    report_urls = {}
    if accepted:
        report_urls = {
            "docx": f"/api/report/{req.schedule_id}.docx",
            "pdf": f"/api/report/{req.schedule_id}.pdf",
            "xlsx": f"/api/export/{req.schedule_id}.xlsx",
            "package": f"/api/export/{req.schedule_id}/package.zip",
        }
        if schedule.metadata.get("import_format") == "XER":
            report_urls["xer"] = f"/api/export/{req.schedule_id}.xer"
    return {
        "schedule_id": req.schedule_id,
        "accepted": accepted,
        "accepted_fingerprint": ACCEPTED_FINGERPRINTS.get(req.schedule_id),
        "report_urls": report_urls,
    }


def _report_data_for_accepted(schedule_id: str, schedule: ProjectSchedule, export_type: str) -> Dict[str, Any]:
    fingerprint = _assert_accepted_unchanged(schedule_id, schedule)
    log_action(schedule_id, "EXPORT", f"Generating accepted {export_type} deliverable.")
    context = dict(REPORT_CONTEXT.get(schedule_id, {}))
    context["accepted_fingerprint"] = fingerprint
    return build_report_data(schedule, context, ACTION_LOG.get(schedule_id, []), accepted=True)


@app.post("/api/tender/build")
async def tender_build(
    files: List[UploadFile] = File(...),
    project_name: str = Form("Tender / Detailed Schedule"),
    data_date: str = Form(""),
    mode: str = Form("TENDER"),
    default_duration_days: float = Form(5.0, gt=0.0, le=365.0),
):
    if len(files) > 100:
        raise HTTPException(400, "A maximum of 100 top-level files can be uploaded in one tender build.")
    packed=[]
    total_bytes=0
    for f in files:
        payload=await _read_upload_limited(f)
        total_bytes += len(payload)
        if total_bytes > MAX_EVIDENCE_PACK_BYTES:
            raise HTTPException(413, f"Evidence pack exceeds the {MAX_EVIDENCE_PACK_BYTES // (1024 * 1024)} MB total limit")
        packed.append((f.filename or "document", payload))
    docs=extract_document_pack(packed)
    schedule, build=build_tender_schedule(docs, project_name=clean_text(project_name,4000), data_date=data_date or None, mode=mode, default_duration_days=default_duration_days)
    try:
        calculate_cpm(schedule)
    except ScheduleError as exc:
        schedule.metadata["cpm_import_error"] = str(exc)
    sid=_store_schedule(schedule)
    with _LOCK:
        EVIDENCE_STORE[sid]=[(safe_filename(name,"document"),payload) for name,payload in packed]
    log_action(sid,"TENDER_BUILD",f"Built {mode.upper()} schedule from {len(docs)} evidence document(s).",details={"evidence":evidence_summary(docs),"build":build})
    return {"schedule_id":sid,"summary":schedule_summary(schedule),"evidence":evidence_summary(docs),"build":build,"downloads":{"xlsx":f"/api/export/{sid}.xlsx","data_vault":f"/api/export/{sid}/data-vault.zip"}}


@app.get("/api/schedule/{schedule_id}/doctor")
def schedule_doctor(schedule_id: str):
    schedule=_require_schedule(schedule_id)
    return {"schedule_id":schedule_id, **build_repair_plan(schedule)}


@app.post("/api/schedule/{schedule_id}/doctor/apply")
def schedule_doctor_apply(schedule_id: str, payload: RepairApplyRequest):
    schedule=_require_schedule(schedule_id)
    clone,result=apply_repairs(schedule,payload.selected_fix_ids,payload.safe_only,payload.approved_by)
    new_id=_store_schedule(clone)
    with _LOCK:
        if schedule_id in EVIDENCE_STORE:
            EVIDENCE_STORE[new_id]=list(EVIDENCE_STORE[schedule_id])
    log_action(new_id,"SCHEDULE_DOCTOR",f"Applied {result['applied_count']} deterministic schedule repair(s) to a clone.",details={"source_schedule_id":schedule_id})
    return {"source_schedule_id":schedule_id,"new_schedule_id":new_id,"summary":schedule_summary(clone),"repair":result}


@app.get("/api/export/{schedule_id}/data-vault.zip")
def export_data_vault(schedule_id: str):
    schedule=_require_schedule(schedule_id)
    with _LOCK:
        audit=list(ACTION_LOG.get(schedule_id,[]))
    content=build_schedule_data_vault(schedule,summary=schedule_summary(schedule),audit_log=audit,source_files=list(EVIDENCE_STORE.get(schedule_id,[])))
    return _download_response(content,"application/zip",f"{safe_filename(schedule.project_name,'Schedule')}_Data_Vault.zip")


@app.post("/api/report-studio/inspect")
async def report_studio_inspect(template: UploadFile = File(...)):
    payload=await _read_upload_limited(template)
    return inspect_template(template.filename or "template",payload)


@app.post("/api/report-studio/render")
async def report_studio_render(
    template: UploadFile = File(...),
    data_file: Optional[UploadFile] = File(None),
    schedule_id: str = Form(""),
):
    template_bytes=await _read_upload_limited(template)
    data: Dict[str,Any]={}
    if data_file is not None:
        data_bytes=await _read_upload_limited(data_file)
        data=load_report_data(data_file.filename or "data.json",data_bytes)
    if schedule_id:
        schedule=_require_schedule(schedule_id)
        schedule_data=schedule.to_dict(include_raw_tables=False)
        data={**schedule_data, **data, "schedule":schedule_data, "summary":schedule_summary(schedule)}
    try:
        content,media,ext=render_template(template.filename or "template.docx",template_bytes,data)
    except ValueError as exc:
        raise HTTPException(400,str(exc)) from None
    stem=safe_filename(Path(template.filename or "report").stem,"report")
    return _download_response(content,media,f"{stem}_POPULATED{ext}")


@app.get("/api/report/{schedule_id}.docx")
def report_docx(schedule_id: str):
    schedule = _require_schedule(schedule_id)
    data = _report_data_for_accepted(schedule_id, schedule, "DOCX report")
    content = build_docx_bytes(data)
    return _download_response(
        content,
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        f"{schedule.project_id}_Recovery_Schedule_Report.docx",
    )


@app.get("/api/report/{schedule_id}.pdf")
def report_pdf(schedule_id: str):
    schedule = _require_schedule(schedule_id)
    data = _report_data_for_accepted(schedule_id, schedule, "PDF report")
    content = build_pdf_bytes(data)
    return _download_response(content, "application/pdf", f"{schedule.project_id}_Recovery_Schedule_Report.pdf")


@app.get("/api/actions/{schedule_id}")
def get_actions(schedule_id: str):
    _require_schedule(schedule_id)
    with _LOCK:
        actions = list(ACTION_LOG.get(schedule_id, []))
    return {
        "schedule_id": schedule_id,
        "actions": actions,
        "verification": verify_audit_chain(actions),
    }


@app.get("/api/export/{schedule_id}.xer")
def export_recovered_xer(schedule_id: str):
    schedule = _require_schedule(schedule_id)
    _assert_accepted_unchanged(schedule_id, schedule)
    if schedule.metadata.get("import_format") != "XER":
        raise HTTPException(409, "Recovered XER export requires an XER source so unsupported source tables are not invented.")
    log_action(schedule_id, "EXPORT", "Generating accepted recovered XER with conservative changed-cell updates.")
    data = build_recovered_xer_bytes(schedule)
    manifest = build_xer_integrity_manifest(schedule)
    if not manifest.get("history_integrity_pass", False):
        raise HTTPException(409, "Recovered XER failed locked-history integrity verification")
    return _download_response(data, "application/octet-stream", f"{schedule.project_id}_RECOVERED.xer")


@app.get("/api/export/{schedule_id}.xlsx")
def export_xlsx(schedule_id: str):
    schedule = _require_schedule(schedule_id)
    accepted = schedule_id in ACCEPTED_FINGERPRINTS
    if accepted:
        _assert_accepted_unchanged(schedule_id, schedule)
    log_action(schedule_id, "EXPORT", "Generating schedule analysis workbook.")
    data = schedule_to_excel_bytes(schedule, REPORT_CONTEXT.get(schedule_id, {}), ACTION_LOG.get(schedule_id, []))
    return _download_response(
        data,
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        f"{schedule.project_id}_Schedule_Analysis.xlsx",
    )


@app.get("/api/export/{schedule_id}/package.zip")
def export_complete_package(schedule_id: str):
    schedule = _require_schedule(schedule_id)
    accepted_fingerprint = _assert_accepted_unchanged(schedule_id, schedule)
    log_action(schedule_id, "EXPORT", "Generating complete accepted recovery package with checksums and audit manifests.")
    context = dict(REPORT_CONTEXT.get(schedule_id, {}))
    context["accepted_fingerprint"] = accepted_fingerprint
    package = build_final_recovery_package(schedule, context, ACTION_LOG.get(schedule_id, []), accepted=True)
    return _download_response(package, "application/zip", f"{schedule.project_id}_Recovery_10X_Package.zip")
