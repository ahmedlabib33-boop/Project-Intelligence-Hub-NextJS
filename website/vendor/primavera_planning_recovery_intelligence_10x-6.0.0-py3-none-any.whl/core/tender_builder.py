from __future__ import annotations

from datetime import datetime
import re
from typing import Any, Dict, List, Optional, Tuple

from .document_intelligence import DocumentEvidence
from .models import Activity, Calendar, ProjectSchedule, Relationship, parse_dt
from .utils import clean_text, finite_float


_NAME_KEYS = {"description", "activity", "activity name", "task", "task name", "item description", "work description", "scope", "boq description"}
_ID_KEYS = {"id", "activity id", "activity code", "task id", "item", "item no", "item number", "boq item"}
_DUR_KEYS = {"duration", "duration days", "days", "planned duration", "original duration", "od"}
_PRED_KEYS = {"predecessor", "predecessors", "pred", "logic"}
_WBS_KEYS = {"wbs", "section", "phase", "package", "work package", "discipline"}


def _n(s: Any) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9%]+", " ", str(s or "").lower())).strip()


def _find_col(headers: List[str], aliases: set[str]) -> Optional[int]:
    norm = [_n(h) for h in headers]
    for i, h in enumerate(norm):
        if h in {_n(a) for a in aliases}:
            return i
    return None


def _duration(value: Any) -> Optional[float]:
    if value in (None, ""):
        return None
    if isinstance(value, (int, float)):
        return max(0.0, float(value))
    text = str(value).lower()
    m = re.search(r"(\d+(?:\.\d+)?)\s*(day|week|month|hour|hr)s?", text)
    if m:
        n = float(m.group(1)); unit = m.group(2)
        return n / 8.0 if unit in {"hour","hr"} else n*5.0 if unit=="week" else n*21.0 if unit=="month" else n
    try:
        return max(0.0, float(text.strip()))
    except Exception:
        return None


def _phase_from_name(name: str) -> str:
    t = name.lower()
    mapping = [
        ("mobil", "MOBILIZATION"),("design", "DESIGN"),("engineer", "ENGINEERING"),("submitt", "SUBMITTALS"),
        ("approv", "APPROVALS"),("procure", "PROCUREMENT"),("purchase", "PROCUREMENT"),("fabricat", "FABRICATION"),
        ("civil", "CIVIL"),("struct", "STRUCTURAL"),("architect", "ARCHITECTURAL"),("mechan", "MECHANICAL"),
        ("elect", "ELECTRICAL"),("instrument", "INSTRUMENTATION"),("install", "INSTALLATION"),("test", "TESTING"),
        ("commission", "COMMISSIONING"),("handover", "HANDOVER"),("closeout", "CLOSEOUT")]
    for key, phase in mapping:
        if key in t: return phase
    return "EXECUTION"


def _work_items(documents: List[DocumentEvidence], mode: str) -> List[Dict[str, Any]]:
    items: List[Dict[str, Any]] = []
    for doc in documents:
        for table in doc.tables:
            hi = [_n(h) for h in table.headers]
            name_i = _find_col(table.headers, _NAME_KEYS)
            if name_i is None: continue
            id_i = _find_col(table.headers, _ID_KEYS)
            dur_i = _find_col(table.headers, _DUR_KEYS)
            pred_i = _find_col(table.headers, _PRED_KEYS)
            wbs_i = _find_col(table.headers, _WBS_KEYS)
            for rno, row in enumerate(table.rows, start=2):
                if name_i >= len(row): continue
                name = clean_text(row[name_i], 1000)
                if not name or len(name) < 3: continue
                items.append({
                    "source": doc.filename, "source_table": table.name, "source_row": rno,
                    "source_id": clean_text(row[id_i], 255) if id_i is not None and id_i < len(row) else "",
                    "name": name,
                    "duration": _duration(row[dur_i]) if dur_i is not None and dur_i < len(row) else None,
                    "pred": clean_text(row[pred_i], 1000) if pred_i is not None and pred_i < len(row) else "",
                    "wbs": clean_text(row[wbs_i], 255) if wbs_i is not None and wbs_i < len(row) else _phase_from_name(name),
                    "confidence": 0.95 if dur_i is not None else 0.78,
                })
    if items:
        if mode == "TENDER" and len(items) > 120:
            # Collapse into phase-level work packages.
            grouped: Dict[str, Dict[str, Any]] = {}
            for item in items:
                phase = item["wbs"] or _phase_from_name(item["name"])
                g = grouped.setdefault(phase, {"name": phase.title(), "wbs": phase, "duration": 0.0, "count": 0, "source": "Multiple tender documents", "confidence": 0.75})
                g["count"] += 1
                g["duration"] += item["duration"] or 5.0
            return list(grouped.values())
        return items[:2500]

    # Text fallback: extract likely scope/headings, never fail.
    seen=set()
    for doc in documents:
        for line in doc.text.splitlines():
            s=clean_text(line,500).strip(" -•\t")
            if not (5 <= len(s) <= 160): continue
            low=s.lower()
            if any(k in low for k in ["scope", "work", "mobil", "design", "procure", "install", "test", "commission", "handover", "construction", "excavat", "concrete", "cable", "pipe", "equipment"]):
                key=_n(s)
                if key in seen: continue
                seen.add(key)
                items.append({"name":s,"wbs":_phase_from_name(s),"duration":None,"pred":"","source":doc.filename,"confidence":0.55})
                if len(items)>= (80 if mode=="TENDER" else 600): return items
    return items


def _extract_dates(documents: List[DocumentEvidence]) -> List[Tuple[str, datetime, str]]:
    out=[]
    patterns=[r"\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b",r"\b\d{4}-\d{1,2}-\d{1,2}\b",r"\b\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{4}\b"]
    for doc in documents:
        for line in doc.text.splitlines():
            low=line.lower()
            if not any(k in low for k in ["completion","handover","start","commencement","award","ntp","notice to proceed","submission","milestone"]): continue
            for pat in patterns:
                m=re.search(pat,line,re.I)
                if m:
                    dt=parse_dt(m.group(0))
                    if dt: out.append((clean_text(line,500),dt,doc.filename))
    return out[:100]


def build_tender_schedule(documents: List[DocumentEvidence], *, project_name: str, data_date: Any = None, mode: str = "TENDER", default_duration_days: float = 5.0) -> Tuple[ProjectSchedule, Dict[str, Any]]:
    mode=(mode or "TENDER").upper()
    if mode not in {"TENDER","DETAILED"}: mode="TENDER"
    dd=parse_dt(data_date) or datetime.now().replace(hour=0,minute=0,second=0,microsecond=0)
    schedule=ProjectSchedule(project_id="TENDER-AUTO",project_name=project_name or "Tender Schedule",data_date=dd,calendars={"DEFAULT":Calendar(id="DEFAULT",name="Tender Default 5D")},metadata={"import_format":"DOCUMENT_SYNTHESIS","build_mode":mode})
    # Preserve every extracted source table so the Data Vault can expose the evidence used to synthesize the schedule.
    for doc in documents:
        for table in doc.tables:
            headers=[str(h or "") for h in table.headers]
            key=f"DOC::{doc.filename}::{table.name}"
            schedule.raw_tables[key]=[{headers[i] if i<len(headers) and headers[i] else f"COL_{i+1}": (row[i] if i<len(row) else "") for i in range(max(len(headers),len(row)))} for row in table.rows]
    assumptions=[]
    items=_work_items(documents,mode)
    start=Activity(id="MS-START",name="Project Start / Notice to Proceed",activity_type="START_MILESTONE",remaining_duration=0,original_duration=0,constraint_type="START_ON",constraint_date=dd,source={"generated":True})
    schedule.activities[start.id]=start
    previous=start.id
    source_map={}
    assumed_count=0
    for idx,item in enumerate(items,start=1):
        aid=f"{'T' if mode=='TENDER' else 'D'}{idx:05d}"
        dur=item.get("duration")
        if dur is None:
            dur=float(default_duration_days)
            assumed_count+=1
        wbs=clean_text(item.get("wbs") or _phase_from_name(item.get("name","")),255)
        schedule.wbs.setdefault(wbs,wbs.title())
        a=Activity(id=aid,name=item.get("name") or aid,wbs_id=wbs,original_duration=dur,remaining_duration=dur,source={"evidence_file":item.get("source",""),"evidence_table":item.get("source_table",""),"evidence_row":item.get("source_row"),"confidence":item.get("confidence",0.5),"duration_assumed":item.get("duration") is None})
        schedule.activities[aid]=a
        sid=item.get("source_id")
        if sid: source_map[sid]=aid
        schedule.relationships.append(Relationship(previous,aid,"FS",0,source={"generated":True,"reason":"Deterministic tender sequencing"}))
        previous=aid
    if not items:
        assumptions.append("No structured work items were recognized; a minimum tender control skeleton was generated.")
        for name,wbs,dur in [("Mobilization and planning","MOBILIZATION",10),("Submittals and approvals","SUBMITTALS",15),("Procurement and logistics","PROCUREMENT",20),("Construction / execution","EXECUTION",30),("Testing and commissioning","TESTING",10)]:
            idx=len(schedule.activities)
            aid=f"T{idx:05d}"; schedule.wbs.setdefault(wbs,wbs.title())
            schedule.activities[aid]=Activity(id=aid,name=name,wbs_id=wbs,original_duration=dur,remaining_duration=dur,source={"generated":True,"assumption":True})
            schedule.relationships.append(Relationship(previous,aid)); previous=aid
            assumed_count+=1
    finish=Activity(id="MS-FINISH",name="Contract Completion / Handover",activity_type="FINISH_MILESTONE",remaining_duration=0,original_duration=0,source={"generated":True})
    dates=_extract_dates(documents)
    completion=[d for d in dates if any(k in d[0].lower() for k in ["completion","handover"])]
    if completion:
        finish.constraint_type="FINISH_ON_OR_BEFORE"; finish.constraint_date=completion[0][1]; finish.source.update({"evidence":completion[0][0],"evidence_file":completion[0][2]})
    schedule.activities[finish.id]=finish
    schedule.relationships.append(Relationship(previous,finish.id))
    assumptions.append(f"{assumed_count} activity duration(s) use the configurable default of {default_duration_days:g} working days because source durations were not explicit.") if assumed_count else None
    assumptions.append("Generated logic is a planning baseline and must be reviewed against method statements, quantities, resources, calendars, contract milestones and procurement constraints before contractual use.")
    schedule.metadata.update({"document_count":len(documents),"evidence_sha256":[d.sha256 for d in documents],"assumptions":assumptions,"assumed_duration_count":assumed_count,"explicit_milestone_dates":[{"text":t,"date":d.date().isoformat(),"source":s} for t,d,s in dates]})
    return schedule,{"mode":mode,"work_item_count":len(items),"activity_count":len(schedule.activities),"assumed_duration_count":assumed_count,"assumptions":assumptions,"milestone_dates":schedule.metadata["explicit_milestone_dates"]}
