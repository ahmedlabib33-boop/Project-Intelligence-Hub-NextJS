from __future__ import annotations
from io import BytesIO, StringIO
import csv, hashlib, json, zipfile
from typing import Any, Dict, Iterable, List
from .models import ProjectSchedule
from .qa import schedule_quality
from .exporter import schedule_to_excel_bytes
from .utils import safe_filename
from openpyxl import Workbook


def _csv_bytes(headers: List[str], rows: Iterable[Iterable[Any]]) -> bytes:
    out=StringIO(); w=csv.writer(out,lineterminator='\n'); w.writerow(headers)
    for row in rows: w.writerow(["" if v is None else v for v in row])
    return out.getvalue().encode('utf-8-sig')

def build_schedule_data_vault(schedule: ProjectSchedule, *, summary: Dict[str,Any]|None=None, audit_log: List[Dict[str,Any]]|None=None, source_files: List[tuple[str,bytes]]|None=None) -> bytes:
    files: Dict[str,bytes]={}
    for idx,(name,payload) in enumerate(source_files or [],start=1):
        safe=safe_filename(name or f'source-{idx}','source')
        files[f'00_SOURCE_EVIDENCE/{idx:03d}_{safe}']=payload
    files['01_NORMALIZED/schedule.json']=json.dumps(schedule.to_dict(include_raw_tables=False),indent=2,ensure_ascii=False,default=str).encode()
    files['01_NORMALIZED/qa.json']=json.dumps(schedule_quality(schedule),indent=2,ensure_ascii=False,default=str).encode()
    files['01_NORMALIZED/summary.json']=json.dumps(summary or {},indent=2,ensure_ascii=False,default=str).encode()
    files['01_NORMALIZED/metadata.json']=json.dumps(schedule.metadata,indent=2,ensure_ascii=False,default=str).encode()
    files['02_TABLES/activities.csv']=_csv_bytes(
        ['id','name','wbs_id','status','activity_type','calendar_id','original_duration','remaining_duration','percent_complete','planned_start','planned_finish','actual_start','actual_finish','constraint_type','constraint_date','es','ef','ls','lf','total_float','free_float','critical','longest_path','path_drag','primary_resource_id'],
        ([a.id,a.name,a.wbs_id,a.status,a.activity_type,a.calendar_id,a.original_duration,a.remaining_duration,a.percent_complete,a.planned_start,a.planned_finish,a.actual_start,a.actual_finish,a.constraint_type,a.constraint_date,a.es,a.ef,a.ls,a.lf,a.total_float,a.free_float,a.critical,a.longest_path,a.path_drag,a.primary_resource_id] for a in schedule.activities.values()))
    files['02_TABLES/relationships.csv']=_csv_bytes(['id','predecessor_id','successor_id','type','lag','lag_calendar_id'],([r.id,r.predecessor_id,r.successor_id,r.rel_type,r.lag,r.lag_calendar_id] for r in schedule.relationships))
    files['02_TABLES/calendars.csv']=_csv_bytes(['id','name','working_weekdays','hours_per_day','hours_by_weekday','non_working_dates','working_dates'],([c.id,c.name,'|'.join(map(str,c.working_weekdays)),c.hours_per_day,json.dumps(c.hours_by_weekday), '|'.join(c.non_working_dates),'|'.join(c.working_dates)] for c in schedule.calendars.values()))
    files['02_TABLES/wbs.csv']=_csv_bytes(['wbs_id','name'],schedule.wbs.items())
    files['02_TABLES/changes.csv']=_csv_bytes(['kind','activity_id','field','before','after','reason','risk','requires_approval','scenario_id','evidence_ref','approved_by','approved_at'],([c.kind,c.activity_id,c.field,json.dumps(c.before,default=str),json.dumps(c.after,default=str),c.reason,c.risk,c.requires_approval,c.scenario_id,c.evidence_ref,c.approved_by,c.approved_at] for c in schedule.changes))
    # Every preserved raw source table becomes a CSV so users can recover all available schedule data.
    for table_name, rows in sorted(schedule.raw_tables.items()):
        if not rows: continue
        headers=[]
        for row in rows:
            for key in row:
                if key not in headers: headers.append(key)
        safe=safe_filename(table_name,'table').replace('.','_')
        files[f'03_RAW_TABLES/{safe}.csv']=_csv_bytes(headers,([row.get(h,'') for h in headers] for row in rows))
    try:
        files['04_ANALYSIS/Schedule_Analysis.xlsx']=schedule_to_excel_bytes(schedule,action_log=audit_log or [])
    except Exception as exc:
        # A Data Vault must remain exportable even when the network is CPM-invalid (for example, a cycle).
        wb=Workbook(); ws=wb.active; ws.title='Activities_Raw'
        ws.append(['Activity ID','Activity Name','Status','WBS','OD','RD','Calendar','Planned Start','Planned Finish','Actual Start','Actual Finish'])
        for a in schedule.activities.values():
            ws.append([a.id,a.name,a.status,a.wbs_id,a.original_duration,a.remaining_duration,a.calendar_id,a.planned_start,a.planned_finish,a.actual_start,a.actual_finish])
        rel=wb.create_sheet('Relationships_Raw'); rel.append(['Pred','Succ','Type','Lag'])
        for r in schedule.relationships: rel.append([r.predecessor_id,r.successor_id,r.rel_type,r.lag])
        notes=wb.create_sheet('Export_Notice'); notes['A1']='CPM workbook fallback'; notes['A2']=f'{type(exc).__name__}: {exc}'
        bio=BytesIO(); wb.save(bio); files['04_ANALYSIS/Schedule_Analysis.xlsx']=bio.getvalue()
    files['04_ANALYSIS/audit_log.json']=json.dumps(audit_log or [],indent=2,ensure_ascii=False,default=str).encode()
    # Portable graph representation.
    graph=['<?xml version="1.0" encoding="UTF-8"?>','<graphml xmlns="http://graphml.graphdrawing.org/xmlns"><graph edgedefault="directed">']
    for a in schedule.activities.values(): graph.append(f'<node id="{a.id}"/>')
    for i,r in enumerate(schedule.relationships): graph.append(f'<edge id="e{i}" source="{r.predecessor_id}" target="{r.successor_id}"/>')
    graph.append('</graph></graphml>'); files['04_ANALYSIS/network.graphml']='\n'.join(graph).encode()
    manifest=[]
    for name,data in sorted(files.items()): manifest.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    files['PACKAGE_MANIFEST.json']=json.dumps({'project':schedule.project_name,'file_count':len(manifest),'files':manifest},indent=2).encode()
    files['CHECKSUMS.sha256']=''.join(f"{m['sha256']}  {m['path']}\n" for m in manifest).encode()
    out=BytesIO()
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as zf:
        for name,data in sorted(files.items()): zf.writestr(name,data)
    return out.getvalue()
