from __future__ import annotations

from dataclasses import asdict
from datetime import datetime
import math
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from .calendar_engine import add_workdays
from .cpm import calculate_cpm
from .errors import ScenarioValidationError, ScheduleCycleError, ScheduleDataError
from .integrity import schedule_fingerprint, scenario_fingerprint, validate_history_unchanged
from .models import Calendar, Change, ProjectSchedule, Relationship
from .utils import canonical_sha256, finite_float, utc_now_iso

_EPS = 1e-7
_VALID_REL_TYPES = {"FS", "SS", "FF", "SF"}
_RISK_ORDER = {"LOW": 0, "MEDIUM": 1, "HIGH": 2, "CRITICAL": 3}


def _eligible(activity, near_critical_threshold: float = 5.0) -> bool:
    return not activity.is_complete and activity.duration > _EPS and activity.total_float <= near_critical_threshold


def _risk_penalty(risk: str) -> float:
    return {"LOW": 0.10, "MEDIUM": 0.28, "HIGH": 0.65, "CRITICAL": 1.0}.get(str(risk).upper(), 0.40)


def _aggregate_risk(changes: Sequence[Dict[str, Any]]) -> str:
    if not changes:
        return "LOW"
    return max((str(change.get("risk", "MEDIUM")).upper() for change in changes), key=lambda value: _RISK_ORDER.get(value, 1))


def _score(recovery: float, risk: str, change_count: int = 1, confidence: float = 0.75) -> float:
    benefit = max(0.0, float(recovery))
    count = max(1, int(change_count))
    confidence = max(0.05, min(1.0, float(confidence)))
    return round(benefit * confidence / count / (1.0 + _risk_penalty(risk)), 4)


def _change_conflict_key(change: Dict[str, Any]) -> Tuple:
    if change.get("field") == "relationship":
        return (
            "relationship",
            change.get("relationship_id") or "",
            change.get("predecessor_id") or "",
            change.get("successor_id") or "",
        )
    return (change.get("field"), change.get("activity_id"))


def _stable_scenario_id(prefix: str, changes: Sequence[Dict[str, Any]]) -> str:
    return f"{prefix}-{canonical_sha256(list(changes))[:12].upper()}"


def _find_relationship(schedule: ProjectSchedule, change: Dict[str, Any]) -> Optional[Relationship]:
    relationship_id = str(change.get("relationship_id") or "")
    pred = str(change.get("predecessor_id") or "")
    succ = str(change.get("successor_id") or "")
    before = change.get("before") or {}
    before_type = str(before.get("type") or "").upper()
    before_lag = before.get("lag")

    candidates = [
        rel for rel in schedule.relationships
        if rel.predecessor_id == pred and rel.successor_id == succ
    ]
    if relationship_id:
        exact = [rel for rel in candidates if rel.id == relationship_id]
        if exact:
            return exact[0]
    if before_type:
        candidates = [rel for rel in candidates if rel.rel_type == before_type]
    if before_lag is not None:
        try:
            lag = float(before_lag)
            lag_matches = [rel for rel in candidates if abs(rel.lag - lag) <= 1e-6]
            if lag_matches:
                candidates = lag_matches
        except (TypeError, ValueError):
            pass
    return sorted(candidates, key=lambda rel: rel.key)[0] if candidates else None


def _apply_changes_unchecked(schedule: ProjectSchedule, changes: Sequence[Dict[str, Any]]) -> ProjectSchedule:
    out = schedule.clone()
    for change in changes:
        field = change.get("field")
        activity_id = str(change.get("activity_id") or "")
        if field == "remaining_duration":
            if activity_id not in out.activities:
                raise ScenarioValidationError(f"Unknown activity: {activity_id}")
            out.activities[activity_id].remaining_duration = finite_float(change.get("after"), field="remaining duration")
        elif field == "relationship":
            relationship = _find_relationship(out, change)
            if relationship is None:
                raise ScenarioValidationError(
                    f"Relationship not found: {change.get('predecessor_id')} -> {change.get('successor_id')}"
                )
            after = change.get("after") or {}
            relationship.rel_type = str(after.get("type") or relationship.rel_type).upper()
            relationship.lag = finite_float(after.get("lag", relationship.lag), field="relationship lag")
        else:
            raise ScenarioValidationError(f"Unsupported recovery change field: {field}")
    calculate_cpm(out)
    return out


def _build_scenario(
    master: ProjectSchedule,
    base_finish: float,
    changes: Sequence[Dict[str, Any]],
    *,
    scenario_type: str,
    strategy: str,
    risk: str,
    target_recovery_days: float,
    prefix: str,
    confidence: float = 0.75,
    implementation_effort: str = "MEDIUM",
    extra: Optional[Dict[str, Any]] = None,
) -> Optional[Dict[str, Any]]:
    try:
        test = _apply_changes_unchecked(master, changes)
    except (ScheduleCycleError, ScheduleDataError, ScenarioValidationError):
        return None
    finish = float(calculate_cpm(test)["project_finish_offset_days"])
    recovery = base_finish - finish
    if recovery <= _EPS:
        return None

    scenario_id = _stable_scenario_id(prefix, changes)
    base_hash = schedule_fingerprint(master)
    scenario: Dict[str, Any] = {
        "id": scenario_id,
        "type": scenario_type,
        "strategy": strategy,
        "base_fingerprint": base_hash,
        "finish_offset_days": round(finish, 6),
        "recovery_days": round(recovery, 6),
        "residual_gap_days": round(max(0.0, target_recovery_days - recovery), 6) if target_recovery_days else 0.0,
        "change_count": len(changes),
        "risk": risk,
        "confidence": round(max(0.0, min(1.0, confidence)), 3),
        "implementation_effort": implementation_effort,
        "score": _score(recovery, risk, len(changes), confidence),
        "changes": [dict(change) for change in changes],
        "meets_target": bool(target_recovery_days and recovery + _EPS >= target_recovery_days),
        "requires_constructability_review": risk in {"HIGH", "CRITICAL"} or strategy in {"LOGIC", "CALENDAR"},
    }
    if extra:
        scenario.update(extra)
    scenario["scenario_fingerprint"] = scenario_fingerprint(base_hash, scenario)
    validation = validate_scenario(master, scenario)
    scenario["validation"] = {"valid": validation["valid"], "errors": validation["errors"]}
    return scenario if validation["valid"] else None


def _duration_change(
    activity_id: str,
    before: float,
    after: float,
    *,
    kind: str,
    reason: str,
    risk: str,
) -> Dict[str, Any]:
    return asdict(Change(
        kind=kind,
        activity_id=activity_id,
        field="remaining_duration",
        before=round(before, 6),
        after=round(after, 6),
        reason=reason,
        risk=risk,
        requires_approval=True,
    ))


def _beam_optimize(
    master: ProjectSchedule,
    atomic_scenarios: Sequence[Dict[str, Any]],
    target_recovery_days: float,
    *,
    max_changes: int = 10,
    beam_width: int = 24,
    pool_limit: int = 32,
) -> Optional[Dict[str, Any]]:
    base = master.clone()
    base_finish = float(calculate_cpm(base)["project_finish_offset_days"])
    options = [scenario for scenario in atomic_scenarios if scenario.get("change_count") == 1 and scenario.get("changes")]
    options.sort(
        key=lambda scenario: (
            float(scenario.get("score", 0)),
            float(scenario.get("recovery_days", 0)),
            str(scenario.get("id", "")),
        ),
        reverse=True,
    )
    options = options[:pool_limit]
    if not options:
        return None

    initial = {
        "schedule": base,
        "finish": base_finish,
        "changes": [],
        "used": frozenset(),
        "option_ids": tuple(),
        "strategies": tuple(),
        "confidence": 1.0,
    }
    beam = [initial]
    completed = []

    def rank(state):
        recovery = base_finish - state["finish"]
        count = len(state["changes"])
        risk = _aggregate_risk(state["changes"])
        met = bool(target_recovery_days and recovery + _EPS >= target_recovery_days)
        if met:
            return (2, -count, -_RISK_ORDER.get(risk, 1), -abs(recovery - target_recovery_days), recovery)
        return (1, recovery, recovery / max(1, count), -_RISK_ORDER.get(risk, 1), -count)

    for _depth in range(1, max_changes + 1):
        expanded = []
        for state in beam:
            for option in options:
                change = option["changes"][0]
                conflict = _change_conflict_key(change)
                if conflict in state["used"]:
                    continue
                try:
                    test = _apply_changes_unchecked(state["schedule"], [change])
                except (ScenarioValidationError, ScheduleDataError, ScheduleCycleError):
                    continue
                finish = float(calculate_cpm(test)["project_finish_offset_days"])
                marginal = state["finish"] - finish
                if marginal <= _EPS:
                    continue
                change_copy = dict(change)
                change_copy["calculated_recovery_days"] = round(marginal, 6)
                strategies = tuple(sorted(set(state["strategies"]) | {str(option.get("strategy", ""))}))
                candidate = {
                    "schedule": test,
                    "finish": finish,
                    "changes": state["changes"] + [change_copy],
                    "used": state["used"] | {conflict},
                    "option_ids": state["option_ids"] + (option.get("id"),),
                    "strategies": strategies,
                    "confidence": min(state["confidence"], float(option.get("confidence", 0.7))),
                }
                expanded.append(candidate)
                if target_recovery_days and base_finish - finish + _EPS >= target_recovery_days:
                    completed.append(candidate)
        if not expanded:
            break
        # Deduplicate equivalent change sets and retain the strongest state.
        best_by_key: Dict[Tuple, Dict[str, Any]] = {}
        for state in expanded:
            key = tuple(sorted(state["used"]))
            previous = best_by_key.get(key)
            if previous is None or rank(state) > rank(previous):
                best_by_key[key] = state
        beam = sorted(best_by_key.values(), key=rank, reverse=True)[:beam_width]
        completed.extend(beam)

    if not completed:
        return None
    target_met_states = [
        state for state in completed
        if target_recovery_days and base_finish - state["finish"] + _EPS >= target_recovery_days
    ]
    if target_met_states:
        best = max(target_met_states, key=rank)
    else:
        best = max(completed, key=rank)

    changes = best["changes"]
    risk = _aggregate_risk(changes)
    return _build_scenario(
        master,
        base_finish,
        changes,
        scenario_type="COMBINED_BEAM_OPTIMIZED",
        strategy=" + ".join(filter(None, best["strategies"])),
        risk=risk,
        target_recovery_days=target_recovery_days,
        prefix="O",
        confidence=best["confidence"],
        implementation_effort="HIGH" if len(changes) > 5 else "MEDIUM",
        extra={"optimizer": "DETERMINISTIC_BEAM_SEARCH", "source_scenario_ids": list(best["option_ids"])},
    )


def _greedy_combine(
    master: ProjectSchedule,
    atomic_scenarios: Sequence[Dict[str, Any]],
    target_recovery_days: float,
    strategy: str,
) -> Optional[Dict[str, Any]]:
    base = master.clone()
    base_finish = float(calculate_cpm(base)["project_finish_offset_days"])
    current = base
    current_finish = base_finish
    changes: List[Dict[str, Any]] = []
    used = set()
    confidence = 1.0

    for scenario in sorted(
        atomic_scenarios,
        key=lambda item: (float(item.get("score", 0)), float(item.get("recovery_days", 0)), str(item.get("id", ""))),
        reverse=True,
    ):
        if scenario.get("change_count") != 1 or not scenario.get("changes"):
            continue
        change = scenario["changes"][0]
        conflict = _change_conflict_key(change)
        if conflict in used:
            continue
        try:
            test = _apply_changes_unchecked(current, [change])
        except (ScenarioValidationError, ScheduleDataError, ScheduleCycleError):
            continue
        finish = float(calculate_cpm(test)["project_finish_offset_days"])
        marginal = current_finish - finish
        if marginal <= _EPS:
            continue
        copied = dict(change)
        copied["calculated_recovery_days"] = round(marginal, 6)
        changes.append(copied)
        used.add(conflict)
        current = test
        current_finish = finish
        confidence = min(confidence, float(scenario.get("confidence", 0.7)))
        if target_recovery_days and base_finish - current_finish + _EPS >= target_recovery_days:
            break

    if not changes:
        return None
    return _build_scenario(
        master,
        base_finish,
        changes,
        scenario_type="COMBINED_GREEDY",
        strategy=strategy,
        risk=_aggregate_risk(changes),
        target_recovery_days=target_recovery_days,
        prefix="G",
        confidence=confidence,
        implementation_effort="MEDIUM",
        extra={"optimizer": "MARGINAL_BENEFIT_GREEDY"},
    )


def generate_recovery_scenarios(
    master: ProjectSchedule,
    target_recovery_days: float = 0.0,
    near_critical_threshold: float = 5.0,
    compression_steps: Sequence[float] = (0.10, 0.20, 0.30),
    max_individual: int = 40,
    change_kind: str = "DURATION_COMPRESSION",
    reason_prefix: str = "Duration compression",
    strategy: str = "DURATION",
    max_compression_fraction: float = 0.50,
) -> Dict[str, Any]:
    target = max(0.0, finite_float(target_recovery_days, 0.0))
    threshold = max(0.0, finite_float(near_critical_threshold, 5.0))
    steps = sorted({
        round(finite_float(step), 6)
        for step in compression_steps
        if 0 < finite_float(step) <= max_compression_fraction
    })

    base = master.clone()
    base_result = calculate_cpm(base, compute_path_drag=True)
    base_finish = float(base_result["project_finish_offset_days"])
    eligible = sorted(
        [activity for activity in base.activities.values() if _eligible(activity, threshold)],
        key=lambda activity: (
            0 if activity.longest_path else 1,
            activity.total_float,
            -activity.path_drag,
            -activity.duration,
            activity.id,
        ),
    )[:max(1, int(max_individual))]

    atomic: List[Dict[str, Any]] = []
    for activity in eligible:
        before = float(activity.remaining_duration)
        for fraction in steps:
            after = max(0.0, before * (1.0 - fraction))
            risk = "LOW" if fraction <= 0.10 else ("MEDIUM" if fraction <= 0.20 else "HIGH")
            confidence = 0.82 if fraction <= 0.10 else (0.70 if fraction <= 0.20 else 0.55)
            change = _duration_change(
                activity.id,
                before,
                after,
                kind=change_kind,
                reason=(
                    f"{reason_prefix}: reduce remaining duration by {fraction * 100:.0f}%. "
                    "Requires documented productivity, quantities, crew/equipment and constructability justification."
                ),
                risk=risk,
            )
            scenario = _build_scenario(
                base,
                base_finish,
                [change],
                scenario_type="INDIVIDUAL",
                strategy=strategy,
                risk=risk,
                target_recovery_days=target,
                prefix="D" if strategy == "DURATION" else "R",
                confidence=confidence,
                implementation_effort="LOW" if fraction <= 0.10 else ("MEDIUM" if fraction <= 0.20 else "HIGH"),
                extra={
                    "activity_total_float_days": round(activity.total_float, 6),
                    "activity_path_drag_days": round(activity.path_drag, 6),
                    "compression_fraction": fraction,
                },
            )
            if scenario:
                atomic.append(scenario)

    # Deduplicate any mathematically identical scenarios.
    dedup: Dict[str, Dict[str, Any]] = {}
    for scenario in atomic:
        key = scenario["scenario_fingerprint"]
        existing = dedup.get(key)
        if existing is None or scenario["score"] > existing["score"]:
            dedup[key] = scenario
    atomic = sorted(
        dedup.values(),
        key=lambda item: (
            bool(item.get("meets_target")),
            float(item.get("score", 0)),
            float(item.get("recovery_days", 0)),
            str(item.get("id", "")),
        ),
        reverse=True,
    )

    combined: List[Dict[str, Any]] = []
    optimized = _beam_optimize(base, atomic, target, max_changes=10, beam_width=24, pool_limit=32)
    if optimized:
        combined.append(optimized)
    greedy = _greedy_combine(base, atomic, target, strategy)
    if greedy and (not optimized or greedy["scenario_fingerprint"] != optimized["scenario_fingerprint"]):
        combined.append(greedy)

    scenarios = combined + atomic
    logic_proposals = identify_logic_overlap_candidates(base)
    return {
        "base_fingerprint": schedule_fingerprint(base),
        "base_finish_offset_days": round(base_finish, 6),
        "target_recovery_days": round(target, 6),
        "near_critical_threshold_days": round(threshold, 6),
        "eligible_activity_count": len(eligible),
        "scenario_count": len(scenarios),
        "scenarios": scenarios[:120],
        "logic_overlap_proposals": logic_proposals,
        "optimizer": {
            "method": "DETERMINISTIC_BEAM_SEARCH_PLUS_GREEDY_BENCHMARK",
            "beam_width": 24,
            "max_changes": 10,
            "atomic_pool_used": min(32, len(atomic)),
        },
    }


def identify_logic_overlap_candidates(master: ProjectSchedule, max_candidates: int = 24) -> List[Dict[str, Any]]:
    base = master.clone()
    result = calculate_cpm(base)
    driving = {
        (item["predecessor_id"], item["successor_id"], item["rel_type"], round(float(item["lag"]), 6))
        for item in result.get("driving_relationships", [])
    }
    proposals: List[Dict[str, Any]] = []
    for rel in sorted(base.relationships, key=lambda item: item.key):
        relation_key = (rel.predecessor_id, rel.successor_id, rel.rel_type, round(float(rel.lag), 6))
        if rel.rel_type != "FS" or relation_key not in driving:
            continue
        pred = base.activities.get(rel.predecessor_id)
        succ = base.activities.get(rel.successor_id)
        if not pred or not succ or pred.is_complete or succ.is_complete or succ.is_in_progress:
            continue
        if pred.duration < 3.0 or succ.duration < 2.0:
            continue
        for overlap_fraction in (0.25, 0.50):
            candidate_lag = round(max(0.0, pred.duration * (1.0 - overlap_fraction)), 6)
            proposal = {
                "kind": "LOGIC_OVERLAP_PROPOSAL",
                "relationship_id": rel.id,
                "predecessor_id": pred.id,
                "successor_id": succ.id,
                "before": {"type": "FS", "lag": round(rel.lag, 6)},
                "candidate": {"type": "SS", "lag": candidate_lag},
                "overlap_fraction": overlap_fraction,
                "reason": (
                    f"Simulate approximately {overlap_fraction * 100:.0f}% overlap on a driving FS relationship. "
                    "Requires method statement, interface, access, safety and resource review."
                ),
                "risk": "HIGH",
                "auto_apply": False,
            }
            proposal["proposal_id"] = _stable_scenario_id("LP", [proposal])
            proposals.append(proposal)
            if len(proposals) >= max_candidates:
                return proposals
    return proposals


def simulate_logic_overlap_scenarios(master: ProjectSchedule, max_candidates: int = 24) -> Dict[str, Any]:
    base = master.clone()
    base_finish = float(calculate_cpm(base)["project_finish_offset_days"])
    scenarios: List[Dict[str, Any]] = []
    for proposal in identify_logic_overlap_candidates(base, max_candidates):
        change = asdict(Change(
            kind="LOGIC_OVERLAP",
            activity_id=proposal["successor_id"],
            field="relationship",
            before=proposal["before"],
            after=proposal["candidate"],
            reason=proposal["reason"],
            risk="HIGH",
            requires_approval=True,
            predecessor_id=proposal["predecessor_id"],
            successor_id=proposal["successor_id"],
            relationship_id=proposal.get("relationship_id", ""),
        ))
        scenario = _build_scenario(
            base,
            base_finish,
            [change],
            scenario_type="LOGIC_SIMULATION",
            strategy="LOGIC",
            risk="HIGH",
            target_recovery_days=0.0,
            prefix="L",
            confidence=0.45,
            implementation_effort="HIGH",
            extra={
                "proposal_id": proposal["proposal_id"],
                "overlap_fraction": proposal["overlap_fraction"],
            },
        )
        if scenario:
            scenarios.append(scenario)
    scenarios.sort(key=lambda item: (item["score"], item["recovery_days"], item["id"]), reverse=True)
    return {
        "base_fingerprint": schedule_fingerprint(base),
        "base_finish_offset_days": round(base_finish, 6),
        "scenarios": scenarios,
        "logic_overlap_proposals": identify_logic_overlap_candidates(base, max_candidates),
    }


def generate_resource_scenarios(master: ProjectSchedule, target_recovery_days: float = 0.0) -> Dict[str, Any]:
    return generate_recovery_scenarios(
        master,
        target_recovery_days=target_recovery_days,
        compression_steps=(0.05, 0.10, 0.15, 0.20),
        change_kind="RESOURCE_ACCELERATION",
        reason_prefix="Resource/productivity acceleration assumption",
        strategy="RESOURCE",
        max_compression_fraction=0.25,
    )


def calendar_acceleration_options(master: ProjectSchedule) -> Dict[str, Any]:
    base = master.clone()
    finish_workdays = float(calculate_cpm(base)["project_finish_offset_days"])
    anchor = base.data_date or datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    base_calendar = base.get_calendar()
    current = add_workdays(anchor, finish_workdays, base_calendar)
    options = []
    for label, weekdays, risk in (
        ("6_DAY_WEEK", [0, 1, 2, 3, 4, 5], "HIGH"),
        ("7_DAY_WEEK", [0, 1, 2, 3, 4, 5, 6], "CRITICAL"),
    ):
        calendar = Calendar(
            id=label,
            name=label,
            working_weekdays=weekdays,
            hours_per_day=base_calendar.hours_per_day,
        )
        finish = add_workdays(anchor, finish_workdays, calendar)
        recovery = max(0, (current.date() - finish.date()).days)
        option = {
            "strategy": "CALENDAR",
            "option": label,
            "forecast_finish": finish.date().isoformat(),
            "calendar_days_recovered": recovery,
            "risk": risk,
            "applyable": False,
            "reason": (
                "Calendar-date sensitivity only. Native XER calendar work patterns, shifts and exceptions "
                "are not automatically rewritten; planner approval and P6-native rescheduling are required."
            ),
        }
        option["id"] = _stable_scenario_id("C", [option])
        options.append(option)
    return {
        "base_fingerprint": schedule_fingerprint(base),
        "current_forecast_finish": current.date().isoformat(),
        "options": options,
    }


def validate_scenario(master: ProjectSchedule, scenario: Dict[str, Any], tolerance: float = 1e-4) -> Dict[str, Any]:
    errors: List[str] = []
    changes = scenario.get("changes") or []
    if not isinstance(changes, list) or not changes:
        errors.append("Scenario contains no changes")
        return {"valid": False, "errors": errors}
    if len(changes) > 100:
        errors.append("Scenario exceeds the 100-change safety limit")
    if scenario.get("change_count") is not None and int(scenario.get("change_count")) != len(changes):
        errors.append("change_count does not match the change register")

    master_hash = schedule_fingerprint(master)
    if scenario.get("base_fingerprint") and scenario.get("base_fingerprint") != master_hash:
        errors.append("Scenario is bound to a different master schedule fingerprint")

    conflicts = set()
    for index, change in enumerate(changes, start=1):
        if not isinstance(change, dict):
            errors.append(f"Change {index} is not an object")
            continue
        conflict = _change_conflict_key(change)
        if conflict in conflicts:
            errors.append(f"Change {index} conflicts with another change on {conflict}")
        conflicts.add(conflict)
        field = change.get("field")
        activity_id = str(change.get("activity_id") or "")
        if field == "remaining_duration":
            activity = master.activities.get(activity_id)
            if not activity:
                errors.append(f"Unknown activity {activity_id}")
                continue
            if activity.is_complete:
                errors.append(f"Completed activity {activity_id} is locked")
                continue
            try:
                before = finite_float(change.get("before"), field="before duration")
                after = finite_float(change.get("after"), field="after duration")
            except ValueError as exc:
                errors.append(str(exc))
                continue
            if abs(before - activity.remaining_duration) > tolerance:
                errors.append(f"Change {index} before-duration does not match the master")
            if after < -tolerance:
                errors.append(f"Change {index} has negative remaining duration")
            if after >= before - tolerance:
                errors.append(f"Change {index} does not reduce remaining duration")
            if before > _EPS and (before - after) / before > 0.60 + tolerance:
                errors.append(f"Change {index} exceeds the 60% compression safety cap")
        elif field == "relationship":
            relationship = _find_relationship(master, change)
            if relationship is None:
                errors.append(f"Change {index} relationship was not found or is ambiguous")
                continue
            successor = master.activities.get(relationship.successor_id)
            if successor and successor.is_complete:
                errors.append(f"Change {index} modifies logic into completed activity {successor.id}")
            after = change.get("after") or {}
            rel_type = str(after.get("type") or "").upper()
            if rel_type not in _VALID_REL_TYPES:
                errors.append(f"Change {index} has invalid relationship type {rel_type}")
            try:
                lag = finite_float(after.get("lag", 0), field="relationship lag")
                if abs(lag) > 365:
                    errors.append(f"Change {index} lag exceeds 365 days")
            except ValueError as exc:
                errors.append(str(exc))
        else:
            errors.append(f"Change {index} uses unsupported field {field}")

    recalculated = None
    if not errors:
        try:
            test = _apply_changes_unchecked(master, changes)
            history_violations = validate_history_unchanged(master, test)
            if history_violations:
                errors.append(f"Locked history changed: {history_violations[:3]}")
            base_finish = float(calculate_cpm(master.clone())["project_finish_offset_days"])
            finish = float(calculate_cpm(test)["project_finish_offset_days"])
            recovery = base_finish - finish
            recalculated = {
                "finish_offset_days": round(finish, 6),
                "recovery_days": round(recovery, 6),
            }
            if scenario.get("finish_offset_days") is not None and abs(float(scenario["finish_offset_days"]) - finish) > tolerance:
                errors.append("Stored finish_offset_days does not match recalculation")
            if scenario.get("recovery_days") is not None and abs(float(scenario["recovery_days"]) - recovery) > tolerance:
                errors.append("Stored recovery_days does not match recalculation")
            if recovery <= _EPS:
                errors.append("Scenario does not improve the project finish")
        except (ScenarioValidationError, ScheduleDataError, ScheduleCycleError, ValueError) as exc:
            errors.append(f"Scenario recalculation failed: {exc}")

    if scenario.get("scenario_fingerprint"):
        expected = scenario_fingerprint(master_hash, scenario)
        if scenario["scenario_fingerprint"] != expected:
            errors.append("Scenario fingerprint is invalid")

    return {"valid": not errors, "errors": errors, "recalculated": recalculated, "base_fingerprint": master_hash}


def apply_scenario(
    master: ProjectSchedule,
    scenario: Dict[str, Any],
    *,
    validate: bool = True,
    approved_by: str = "",
) -> ProjectSchedule:
    if validate:
        result = validate_scenario(master, scenario)
        if not result["valid"]:
            raise ScenarioValidationError("; ".join(result["errors"]))

    out = _apply_changes_unchecked(master, scenario.get("changes", []))
    scenario_id = str(scenario.get("id") or _stable_scenario_id("MANUAL", scenario.get("changes", [])))
    provenance = scenario.get("scenario_fingerprint") or scenario_fingerprint(master, scenario)
    approved_at = utc_now_iso()
    for change_data in scenario.get("changes", []):
        allowed = {key: value for key, value in change_data.items() if key in Change.__dataclass_fields__}
        allowed.setdefault("kind", "RECOVERY_CHANGE")
        allowed.setdefault("activity_id", "")
        allowed.setdefault("field", "")
        allowed.setdefault("before", None)
        allowed.setdefault("after", None)
        allowed.setdefault("reason", "Approved recovery scenario")
        allowed["scenario_id"] = scenario_id
        allowed["approved_by"] = approved_by
        allowed["approved_at"] = approved_at
        allowed["provenance_hash"] = provenance
        out.changes.append(Change(**allowed))
    out.metadata["source_master_fingerprint"] = schedule_fingerprint(master)
    out.metadata["applied_scenario_id"] = scenario_id
    out.metadata["applied_scenario_fingerprint"] = provenance
    calculate_cpm(out)
    return out


def combine_scenarios(
    master: ProjectSchedule,
    scenario_groups: Iterable[Dict[str, Any]],
    target_recovery_days: float = 0.0,
) -> Optional[Dict[str, Any]]:
    atomic: List[Dict[str, Any]] = []
    seen = set()
    for group in scenario_groups:
        for scenario in (group or {}).get("scenarios", []):
            if scenario.get("change_count") != 1 or not scenario.get("changes"):
                continue
            key = scenario.get("scenario_fingerprint") or canonical_sha256(scenario.get("changes"))
            if key in seen:
                continue
            seen.add(key)
            atomic.append(scenario)
    return _beam_optimize(master, atomic, max(0.0, float(target_recovery_days)))
