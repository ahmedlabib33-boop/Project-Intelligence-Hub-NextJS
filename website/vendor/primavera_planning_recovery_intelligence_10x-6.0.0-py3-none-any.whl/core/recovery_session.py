from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional
import uuid

from .cpm import calculate_cpm
from .errors import InvalidDecisionError
from .integrity import schedule_fingerprint
from .recovery import (
    calendar_acceleration_options,
    combine_scenarios,
    generate_recovery_scenarios,
    generate_resource_scenarios,
    simulate_logic_overlap_scenarios,
)
from .utils import finite_float, utc_now_iso


RECOVERY_STAGES = ["BASIS", "DURATION", "LOGIC", "CALENDAR", "RESOURCE", "COMBINED", "FINAL"]
_ALLOWED_DECISIONS = {
    "BASIS": {"APPROVE", "CHANGE_TARGET", "STOP"},
    "DURATION": {"YES_10_20", "YES_UP_TO_30", "SKIP"},
    "LOGIC": {"IDENTIFY_ONLY", "SIMULATE_CANDIDATES", "SKIP"},
    "CALENDAR": {"CONSIDER", "SKIP"},
    "RESOURCE": {"CONSIDER", "SKIP"},
    "COMBINED": {"OPTIMIZE", "INDIVIDUAL_ONLY", "STOP"},
    "FINAL": {"REVIEW_RESULTS"},
}


@dataclass
class RecoverySession:
    id: str
    schedule_id: str
    target_recovery_days: float
    base_fingerprint: str = ""
    stage_index: int = 0
    decisions: Dict[str, Any] = field(default_factory=dict)
    decision_log: List[Dict[str, Any]] = field(default_factory=list)
    results: Dict[str, Any] = field(default_factory=dict)
    started_at: str = field(default_factory=utc_now_iso)
    updated_at: str = field(default_factory=utc_now_iso)
    state_version: int = 1

    @property
    def stage(self) -> str:
        return RECOVERY_STAGES[min(self.stage_index, len(RECOVERY_STAGES) - 1)]

    def next_stage(self) -> str:
        self.stage_index = min(self.stage_index + 1, len(RECOVERY_STAGES) - 1)
        self.state_version += 1
        self.updated_at = utc_now_iso()
        return self.stage

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def new_session(schedule_id: str, target_recovery_days: float, schedule=None) -> RecoverySession:
    return RecoverySession(
        id="RS-" + uuid.uuid4().hex[:12].upper(),
        schedule_id=str(schedule_id),
        target_recovery_days=max(0.0, finite_float(target_recovery_days, 0.0)),
        base_fingerprint=schedule_fingerprint(schedule) if schedule is not None else "",
    )


def _record(session: RecoverySession, stage: str, decision: str, payload: Dict[str, Any]) -> None:
    session.decision_log.append({
        "sequence": len(session.decision_log) + 1,
        "time": utc_now_iso(),
        "stage": stage,
        "decision": decision,
        "payload": dict(payload),
    })
    session.decisions[stage] = decision
    session.updated_at = utc_now_iso()
    session.state_version += 1


def stage_question(session: RecoverySession, schedule) -> Dict[str, Any]:
    result = calculate_cpm(schedule)
    critical = [activity for activity in schedule.activities.values() if activity.critical and not activity.is_complete]
    near = [
        activity for activity in schedule.activities.values()
        if not activity.critical and activity.total_float <= 5 and not activity.is_complete
    ]
    common = {
        "stage": session.stage,
        "requires_input": session.stage != "FINAL",
        "state_version": session.state_version,
        "base_fingerprint": session.base_fingerprint or schedule_fingerprint(schedule),
    }

    if session.stage == "BASIS":
        return {
            **common,
            "title": "Recovery Basis",
            "question": (
                f"The deterministic engine reports {len(critical)} critical and {len(near)} near-critical activities, "
                f"a finish offset of {result['project_finish_offset_days']:.2f} working days, and a recovery target of "
                f"{session.target_recovery_days:.1f} working days. Approve this exact fingerprint and target?"
            ),
            "options": [
                {"id": "APPROVE", "label": "Approve Basis"},
                {"id": "CHANGE_TARGET", "label": "Change Target"},
                {"id": "STOP", "label": "Stop Recovery"},
            ],
        }
    if session.stage == "DURATION":
        return {
            **common,
            "title": "Duration Compression",
            "question": (
                "Test shorter remaining durations only on critical/near-critical incomplete work? Every option is "
                "simulated on a clone and requires productivity/resource evidence before approval."
            ),
            "options": [
                {"id": "YES_10_20", "label": "Test 10% and 20%"},
                {"id": "YES_UP_TO_30", "label": "Test up to 30%"},
                {"id": "SKIP", "label": "Skip Duration Compression"},
            ],
        }
    if session.stage == "LOGIC":
        return {
            **common,
            "title": "Logic / Resequencing",
            "question": (
                "Identify driving FS links that could be overlapped? Simulated changes are high-risk proposals and "
                "require method, interface, access and safety review."
            ),
            "options": [
                {"id": "IDENTIFY_ONLY", "label": "Identify Only"},
                {"id": "SIMULATE_CANDIDATES", "label": "Identify and Simulate"},
                {"id": "SKIP", "label": "Skip Logic Changes"},
            ],
        }
    if session.stage == "CALENDAR":
        return {
            **common,
            "title": "Calendar Acceleration",
            "question": (
                "Calculate 6-day and 7-day calendar-date sensitivity? This edition does not silently rewrite native "
                "P6 shifts, holidays or exceptions."
            ),
            "options": [
                {"id": "CONSIDER", "label": "Calculate Sensitivity"},
                {"id": "SKIP", "label": "Keep Existing Calendars"},
            ],
        }
    if session.stage == "RESOURCE":
        return {
            **common,
            "title": "Resource Acceleration",
            "question": (
                "Simulate resource/productivity assumptions on incomplete driving work? Quantity, crew and equipment "
                "evidence will still be mandatory before implementation."
            ),
            "options": [
                {"id": "CONSIDER", "label": "Consider Resources"},
                {"id": "SKIP", "label": "Keep Existing Resources"},
            ],
        }
    if session.stage == "COMBINED":
        return {
            **common,
            "title": "Combined Optimization",
            "question": (
                "Combine only approved strategy families using deterministic beam search and marginal recalculation, "
                "seeking the smallest practical change set that reaches the target?"
            ),
            "options": [
                {"id": "OPTIMIZE", "label": "Optimize Combined Scenario"},
                {"id": "INDIVIDUAL_ONLY", "label": "Keep Individual Scenarios"},
                {"id": "STOP", "label": "Stop Here"},
            ],
        }
    return {
        **common,
        "title": "Recovery Review",
        "question": (
            "Recovery analysis is complete. Every scenario remains unapplied until reviewed and explicitly approved."
        ),
        "options": [{"id": "REVIEW_RESULTS", "label": "Review Results"}],
        "requires_input": False,
    }


def _merge_results(session: RecoverySession, schedule, optimize: bool) -> Dict[str, Any]:
    groups = []
    if session.results.get("duration_recovery"):
        groups.append(session.results["duration_recovery"])
    if session.results.get("resource_recovery"):
        groups.append(session.results["resource_recovery"])
    if session.decisions.get("LOGIC") == "SIMULATE_CANDIDATES" and session.results.get("logic_recovery"):
        groups.append(session.results["logic_recovery"])

    scenarios = []
    seen = set()
    for group in groups:
        for scenario in group.get("scenarios", []):
            key = scenario.get("scenario_fingerprint") or scenario.get("id")
            if key in seen:
                continue
            seen.add(key)
            scenarios.append(scenario)

    if optimize:
        combined = combine_scenarios(schedule, groups, session.target_recovery_days)
        if combined:
            scenarios.insert(0, combined)

    scenarios.sort(
        key=lambda item: (
            bool(item.get("type") == "COMBINED_BEAM_OPTIMIZED"),
            bool(item.get("meets_target")),
            float(item.get("score", 0)),
            float(item.get("recovery_days", 0)),
        ),
        reverse=True,
    )
    base_finish = None
    for group in groups:
        if group.get("base_finish_offset_days") is not None:
            base_finish = group["base_finish_offset_days"]
            break
    if base_finish is None:
        base_finish = calculate_cpm(schedule)["project_finish_offset_days"]

    return {
        "base_fingerprint": session.base_fingerprint or schedule_fingerprint(schedule),
        "base_finish_offset_days": base_finish,
        "target_recovery_days": session.target_recovery_days,
        "scenarios": scenarios[:160],
        "logic_overlap_proposals": session.results.get("logic_proposals", []),
        "calendar_options": (session.results.get("calendar_recovery") or {}).get("options", []),
        "approved_strategy_decisions": dict(session.decisions),
        "optimizer_used": optimize,
    }


def process_decision(
    session: RecoverySession,
    schedule,
    decision: str,
    payload: Optional[Dict[str, Any]] = None,
) -> None:
    payload = dict(payload or {})
    decision = str(decision).upper().strip()
    stage = session.stage
    allowed = _ALLOWED_DECISIONS[stage]
    if decision not in allowed:
        raise InvalidDecisionError(f"Decision {decision!r} is invalid at stage {stage}. Allowed: {sorted(allowed)}")

    current_fingerprint = schedule_fingerprint(schedule)
    if session.base_fingerprint and current_fingerprint != session.base_fingerprint:
        raise InvalidDecisionError("The source schedule changed after this recovery session started; start a new session.")
    if not session.base_fingerprint:
        session.base_fingerprint = current_fingerprint

    _record(session, stage, decision, payload)

    if stage == "BASIS":
        if decision == "STOP":
            session.results["stopped"] = True
            session.stage_index = len(RECOVERY_STAGES) - 1
            return
        if decision == "CHANGE_TARGET":
            session.target_recovery_days = max(
                0.0,
                finite_float(payload.get("target_recovery_days", session.target_recovery_days), session.target_recovery_days),
            )
            # Remain at BASIS so the revised target must be explicitly approved.
            return
        session.next_stage()
        return

    if stage == "DURATION":
        if decision == "YES_UP_TO_30":
            steps = (0.10, 0.20, 0.30)
        elif decision == "YES_10_20":
            steps = (0.10, 0.20)
        else:
            steps = ()
        if steps:
            session.results["duration_recovery"] = generate_recovery_scenarios(
                schedule,
                target_recovery_days=session.target_recovery_days,
                compression_steps=steps,
            )
        session.next_stage()
        return

    if stage == "LOGIC":
        if decision in {"IDENTIFY_ONLY", "SIMULATE_CANDIDATES"}:
            logic = simulate_logic_overlap_scenarios(schedule)
            session.results["logic_proposals"] = logic.get("logic_overlap_proposals", [])
            session.results["logic_mode"] = decision
            if decision == "SIMULATE_CANDIDATES":
                session.results["logic_recovery"] = logic
        session.next_stage()
        return

    if stage == "CALENDAR":
        if decision == "CONSIDER":
            session.results["calendar_recovery"] = calendar_acceleration_options(schedule)
        session.next_stage()
        return

    if stage == "RESOURCE":
        if decision == "CONSIDER":
            session.results["resource_recovery"] = generate_resource_scenarios(
                schedule, session.target_recovery_days
            )
        session.next_stage()
        return

    if stage == "COMBINED":
        if decision == "STOP":
            session.results["stopped_before_combination"] = True
            session.stage_index = len(RECOVERY_STAGES) - 1
            return
        if not session.results.get("duration_recovery") and session.decisions.get("DURATION") != "SKIP":
            session.results["duration_recovery"] = generate_recovery_scenarios(
                schedule,
                target_recovery_days=session.target_recovery_days,
                compression_steps=(0.10, 0.20),
            )
        session.results["combined_mode"] = decision
        session.results["final_recovery"] = _merge_results(session, schedule, optimize=decision == "OPTIMIZE")
        session.next_stage()
        return

    # FINAL / REVIEW_RESULTS is intentionally read-only.
    session.updated_at = utc_now_iso()
