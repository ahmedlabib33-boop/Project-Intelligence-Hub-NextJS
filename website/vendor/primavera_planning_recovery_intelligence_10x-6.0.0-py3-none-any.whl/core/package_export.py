from __future__ import annotations

from datetime import datetime, timezone
from io import BytesIO
import json
import zipfile
from typing import Any, Dict, List, Tuple

from .exporter import schedule_to_excel_bytes
from .integrity import audit_log_fingerprint, schedule_fingerprint, verify_audit_chain
from .models import ProjectSchedule
from .reporting import build_docx_bytes, build_pdf_bytes, build_report_data
from .utils import safe_filename, sha256_hex, utc_now_iso
from .version import ENGINE_ID, VERSION
from .xer_writer import build_recovered_xer_bytes, build_xer_integrity_manifest


def _json_bytes(value: Any) -> bytes:
    return json.dumps(value, indent=2, ensure_ascii=False, sort_keys=True, default=str).encode("utf-8")


def _zip_info(name: str) -> zipfile.ZipInfo:
    # Stable metadata improves reproducibility and avoids leaking local file-system data.
    info = zipfile.ZipInfo(filename=name, date_time=(2026, 1, 1, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o644 << 16
    return info


def build_final_recovery_package(
    schedule: ProjectSchedule,
    context: Dict[str, Any] | None,
    action_log: List[Dict[str, Any]] | None,
    accepted: bool = True,
) -> bytes:
    """Build a self-checking final recovery deliverable ZIP.

    The checksum manifest is calculated over every substantive deliverable. The
    package never includes raw secrets, environment variables or application state.
    """
    context = dict(context or {})
    action_log = list(action_log or [])
    report_data = build_report_data(schedule, context, action_log, accepted=accepted)
    safe = safe_filename(schedule.project_id or "PROJECT")

    if schedule.metadata.get("import_format") == "XER":
        xer_manifest: Dict[str, Any] = build_xer_integrity_manifest(schedule)
    else:
        xer_manifest = {
            "source_format": schedule.metadata.get("import_format", "UNKNOWN"),
            "xer_available": False,
            "reason": "Recovered XER is generated only from an XER source so unsupported source tables are not invented.",
        }

    audit_verification = verify_audit_chain(action_log)
    recovery_audit = {
        "engine": ENGINE_ID,
        "generated_at": report_data["generated_at"],
        "accepted": bool(accepted),
        "project": report_data.get("project"),
        "baseline": report_data.get("baseline"),
        "final": report_data.get("final"),
        "target_recovery_days": report_data.get("target_recovery_days"),
        "recovery_days": report_data.get("recovery_days"),
        "residual_gap_days": report_data.get("residual_gap_days"),
        "target_met": report_data.get("target_met"),
        "scenario": report_data.get("scenario"),
        "decisions": report_data.get("decisions"),
        "changes": report_data.get("changes"),
        "schedule_fingerprint": schedule_fingerprint(schedule),
        "acceptance_fingerprint": report_data.get("acceptance_fingerprint"),
        "audit_verification": audit_verification,
        "audit_log_fingerprint": audit_log_fingerprint(action_log),
        "action_log": report_data.get("action_log"),
    }

    files: List[Tuple[str, bytes, str]] = []
    if schedule.metadata.get("import_format") == "XER":
        files.append((f"01_SCHEDULE/{safe}_RECOVERED.xer", build_recovered_xer_bytes(schedule), "Recovered XER with conservative changed-cell updates"))
    files.extend([
        (f"02_REPORTS/{safe}_Recovery_Schedule_Report.docx", build_docx_bytes(report_data), "Formal editable recovery report"),
        (f"02_REPORTS/{safe}_Recovery_Schedule_Report.pdf", build_pdf_bytes(report_data), "Formal fixed-layout recovery report"),
        (f"03_ANALYSIS/{safe}_Schedule_Analysis.xlsx", schedule_to_excel_bytes(schedule, context, action_log), "Detailed schedule analysis workbook"),
        ("04_AUDIT/XER_INTEGRITY_MANIFEST.json", _json_bytes(xer_manifest), "XER source/output integrity checks"),
        ("04_AUDIT/RECOVERY_AUDIT.json", _json_bytes(recovery_audit), "Machine-readable recovery and approval audit"),
        # Root aliases preserve compatibility with the 10X package layout.
        ("XER_INTEGRITY_MANIFEST.json", _json_bytes(xer_manifest), "Compatibility alias for the XER integrity manifest"),
        ("RECOVERY_AUDIT.json", _json_bytes(recovery_audit), "Compatibility alias for the recovery audit"),
        ("04_AUDIT/SCHEDULE_MODEL.json", _json_bytes(schedule.to_dict(include_raw_tables=False)), "Portable normalized schedule model without raw source tables"),
        ("04_AUDIT/QA_FINDINGS.json", _json_bytes({
            "score": report_data["final"]["qa_score"],
            "grade": report_data["final"]["qa_grade"],
            "errors": report_data["final"]["qa_errors"],
            "warnings": report_data["final"]["qa_warnings"],
            "metrics": report_data.get("qa_metrics"),
            "issues": report_data.get("qa_issues"),
        }), "Schedule-quality findings and screening metrics"),
    ])

    manifest_files = []
    for name, payload, description in files:
        manifest_files.append({
            "path": name,
            "description": description,
            "bytes": len(payload),
            "sha256": sha256_hex(payload),
        })

    package_manifest = {
        "schema_version": "1.0",
        "engine": ENGINE_ID,
        "engine_version": VERSION,
        "generated_at": report_data["generated_at"],
        "accepted": bool(accepted),
        "project_id": schedule.project_id,
        "project_name": schedule.project_name,
        "schedule_fingerprint": schedule_fingerprint(schedule),
        "audit_chain_valid": audit_verification.get("valid", False),
        "audit_head_hash": audit_verification.get("head_hash", ""),
        "file_count": len(files),
        "files": manifest_files,
    }
    manifest_bytes = _json_bytes(package_manifest)

    readme = f"""PRIMAVERA PLANNING & RECOVERY INTELLIGENCE 10X - READ ME FIRST
========================================================

Engine: {ENGINE_ID}
Project: {schedule.project_id} - {schedule.project_name}
Generated: {report_data['generated_at']}
Workflow status: {'ACCEPTED' if accepted else 'DRAFT / NOT ACCEPTED'}
Schedule fingerprint: {schedule_fingerprint(schedule)}
Audit chain: {'VALID' if audit_verification.get('valid') else 'INVALID'}

PACKAGE CONTENTS
----------------
01_SCHEDULE   Recovered XER when the source was XER.
02_REPORTS    Formal Word and PDF reports.
03_ANALYSIS   Multi-sheet Excel schedule analysis.
04_AUDIT      Machine-readable schedule, QA, recovery, integrity and checksum records.

MANDATORY ISSUE CHECKS
----------------------
1. Verify CHECKSUMS.sha256 or PACKAGE_MANIFEST.json before relying on the files.
2. Re-import the recovered XER into Primavera P6.
3. Run the organization-approved native P6 scheduler and schedule-check settings.
4. Confirm Data Date, calendars, constraints, progress, critical/longest path and forecast finish.
5. Confirm every duration, logic, resource and calendar intervention has approval and supporting evidence.
6. Do not treat calculated recovery as contractual entitlement without separate cause-and-effect analysis.

The original/master schedule is not modified by the recovery workflow. The accepted output is a cloned schedule.
""".encode("utf-8")

    checksum_lines = [f"{item['sha256']}  {item['path']}" for item in manifest_files]
    checksum_lines.append(f"{sha256_hex(manifest_bytes)}  PACKAGE_MANIFEST.json")
    checksum_lines.append(f"{sha256_hex(readme)}  READ_ME_FIRST.txt")
    checksums = ("\n".join(checksum_lines) + "\n").encode("ascii")

    bio = BytesIO()
    with zipfile.ZipFile(bio, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        archive.writestr(_zip_info("READ_ME_FIRST.txt"), readme)
        for name, payload, _description in files:
            archive.writestr(_zip_info(name), payload)
        archive.writestr(_zip_info("PACKAGE_MANIFEST.json"), manifest_bytes)
        archive.writestr(_zip_info("CHECKSUMS.sha256"), checksums)
    return bio.getvalue()
