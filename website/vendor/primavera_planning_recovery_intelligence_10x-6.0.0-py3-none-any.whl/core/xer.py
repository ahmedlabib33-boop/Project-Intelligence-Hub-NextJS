from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .calendar_engine import infer_working_weekdays
from .errors import XERValidationError
from .models import Activity, Calendar, ProjectSchedule, Relationship, normalize_status, parse_dt
from .utils import finite_float, sha256_hex


def _num(value: Any, default: float = 0.0) -> float:
    try:
        return finite_float(value, default)
    except ValueError:
        return float(default)


def _decode_xer_bytes(data: bytes) -> Tuple[str, str]:
    if data.startswith(b"\xef\xbb\xbf"):
        return data.decode("utf-8-sig", errors="strict"), "utf-8-sig"
    if data.startswith((b"\xff\xfe", b"\xfe\xff")):
        return data.decode("utf-16", errors="strict"), "utf-16"
    for encoding in ("utf-8", "cp1252", "latin-1"):
        try:
            return data.decode(encoding, errors="strict"), encoding
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace"), "utf-8-replace"


def _select_project(projects: List[Dict[str, Any]], requested: Optional[str]) -> Dict[str, Any]:
    if not projects:
        return {}
    if requested:
        requested_text = str(requested).strip()
        for row in projects:
            if requested_text in {str(row.get("proj_id", "")), str(row.get("proj_short_name", ""))}:
                return row
        raise XERValidationError(f"Requested project {requested!r} was not found in the XER")
    return projects[0]


def parse_xer_text(
    text: str,
    default_hours_per_day: float = 8.0,
    project_id: str | None = None,
    *,
    source_encoding: str = "utf-8",
) -> ProjectSchedule:
    if not isinstance(text, str) or not text.strip():
        raise XERValidationError("XER content is empty")
    default_hpd = finite_float(default_hours_per_day, 8.0, field="default_hours_per_day")
    if default_hpd <= 0 or default_hpd > 24:
        raise XERValidationError("default_hours_per_day must be greater than 0 and no more than 24")

    newline = "\r\n" if "\r\n" in text else "\n"
    tables: Dict[str, List[Dict[str, Any]]] = {}
    table_fields: Dict[str, List[str]] = {}
    table_order: List[str] = []
    table_sections: List[str] = []
    preamble: List[str] = []
    warnings: List[Dict[str, Any]] = []
    current_table: Optional[str] = None
    fields: List[str] = []
    seen_first_table = False

    for line_number, raw in enumerate(text.splitlines(), start=1):
        line = raw.rstrip("\r\n")
        if not line:
            if not seen_first_table:
                preamble.append(line)
            continue
        parts = line.split("\t")
        tag = parts[0]
        if tag == "%T":
            seen_first_table = True
            current_table = parts[1].strip() if len(parts) > 1 else ""
            if not current_table:
                warnings.append({"line": line_number, "type": "EMPTY_TABLE_NAME"})
                fields = []
                continue
            if current_table not in tables:
                tables[current_table] = []
                table_order.append(current_table)
            table_sections.append(current_table)
            fields = []
        elif tag == "%F":
            if not current_table:
                warnings.append({"line": line_number, "type": "FIELDS_WITHOUT_TABLE"})
                continue
            fields = parts[1:]
            if current_table not in table_fields:
                table_fields[current_table] = list(fields)
            elif table_fields[current_table] != fields:
                warnings.append({
                    "line": line_number,
                    "type": "REPEATED_TABLE_SCHEMA_DIFFERENCE",
                    "table": current_table,
                })
        elif tag == "%R":
            if not current_table or not fields:
                warnings.append({"line": line_number, "type": "ROW_WITHOUT_SCHEMA"})
                continue
            values = parts[1:]
            row = {field: (values[index] if index < len(values) else "") for index, field in enumerate(fields)}
            row["_xer_row_index"] = len(tables[current_table])
            tables[current_table].append(row)
            if len(values) != len(fields):
                warnings.append({
                    "line": line_number,
                    "type": "FIELD_COUNT_MISMATCH",
                    "table": current_table,
                    "expected": len(fields),
                    "actual": len(values),
                })
        elif tag == "%E":
            continue
        elif not seen_first_table:
            preamble.append(line)
        else:
            warnings.append({"line": line_number, "type": "UNKNOWN_XER_RECORD", "tag": tag})

    if not tables:
        raise XERValidationError("No %T table sections were found in the XER")

    projects = tables.get("PROJECT", [])
    selected_project = _select_project(projects, project_id)
    selected_internal_project_id = str(selected_project.get("proj_id") or "")

    schedule = ProjectSchedule(raw_tables=tables, calendars={})
    schedule.metadata.update({
        "import_format": "XER",
        "xer_preamble": preamble,
        "xer_table_order": table_order,
        "xer_table_sections": table_sections,
        "xer_table_fields": table_fields,
        "xer_line_ending": newline,
        "xer_encoding": source_encoding,
        "xer_parse_warnings": warnings,
        "source_xer_text_sha256": sha256_hex(text),
        "default_hours_per_day": default_hpd,
        "available_projects": [
            {
                "proj_id": str(row.get("proj_id") or ""),
                "proj_short_name": str(row.get("proj_short_name") or row.get("proj_name") or ""),
            }
            for row in projects
        ],
        "selected_project_internal_id": selected_internal_project_id,
        "lag_calendar_basis": "PROJECT_DEFAULT_HOURS_PER_DAY",
    })

    if selected_project:
        schedule.project_id = str(
            selected_project.get("proj_short_name")
            or selected_project.get("proj_id")
            or selected_project.get("proj_name")
            or "PROJECT"
        )
        schedule.project_name = str(
            selected_project.get("proj_name")
            or selected_project.get("proj_short_name")
            or schedule.project_id
        )
        schedule.data_date = parse_dt(
            selected_project.get("last_recalc_date")
            or selected_project.get("data_date")
            or selected_project.get("scd_end_date")
            or selected_project.get("plan_start_date")
        )
        required_finish = parse_dt(
            selected_project.get("plan_end_date")
            or selected_project.get("scd_end_date")
            or selected_project.get("must_finish_date")
        )
        if required_finish:
            schedule.metadata["required_finish_date"] = required_finish.isoformat()
        default_calendar_id = str(selected_project.get("clndr_id") or "DEFAULT")
        schedule.metadata["default_calendar_id"] = default_calendar_id
    else:
        schedule.project_id = "PROJECT"
        schedule.project_name = "Imported XER Schedule"
        schedule.metadata["default_calendar_id"] = "DEFAULT"

    # Parse calendars before tasks so activity durations can use the associated
    # hours-per-day conversion rather than a single global assumption.
    for row in tables.get("CALENDAR", []):
        calendar_id = str(row.get("clndr_id") or "").strip()
        if not calendar_id:
            continue
        day_hours = _num(row.get("day_hr_cnt"), default_hpd)
        if day_hours <= 0:
            day_hours = default_hpd
        week_hours = _num(row.get("week_hr_cnt"), day_hours * 5)
        schedule.calendars[calendar_id] = Calendar(
            id=calendar_id,
            name=row.get("clndr_name") or calendar_id,
            working_weekdays=infer_working_weekdays(day_hours, week_hours),
            hours_per_day=day_hours,
            source=row,
        )
    if "DEFAULT" not in schedule.calendars:
        schedule.calendars["DEFAULT"] = Calendar(id="DEFAULT", hours_per_day=default_hpd)
    default_calendar_id = str(schedule.metadata.get("default_calendar_id") or "DEFAULT")
    if default_calendar_id not in schedule.calendars:
        schedule.calendars[default_calendar_id] = Calendar(
            id=default_calendar_id,
            name=f"Inferred Calendar {default_calendar_id}",
            hours_per_day=default_hpd,
        )

    calendar_rows = tables.get("CALENDAR", [])
    schedule.metadata["calendar_parity"] = (
        "INFERRED_FROM_DAY_WEEK_HOURS;_NATIVE_WORK_PATTERN_BLOB_PRESERVED"
        if calendar_rows else "DEFAULT_ASSUMPTION_ONLY"
    )

    def project_matches(row: Dict[str, Any]) -> bool:
        row_project = str(row.get("proj_id") or "")
        return not selected_internal_project_id or not row_project or row_project == selected_internal_project_id

    for row in tables.get("PROJWBS", []):
        if not project_matches(row):
            continue
        wbs_id = str(row.get("wbs_id") or "").strip()
        if wbs_id:
            schedule.wbs[wbs_id] = str(row.get("wbs_name") or row.get("wbs_short_name") or wbs_id)

    internal_to_code: Dict[str, str] = {}
    duplicate_codes: Dict[str, int] = {}
    for row in tables.get("TASK", []):
        if not project_matches(row):
            continue
        internal_id = str(row.get("task_id") or "").strip()
        original_code = str(row.get("task_code") or internal_id).strip()
        if not original_code:
            warnings.append({"type": "TASK_WITHOUT_ID", "row_index": row.get("_xer_row_index")})
            continue
        code = original_code
        if code in schedule.activities:
            duplicate_codes[original_code] = duplicate_codes.get(original_code, 1) + 1
            code = f"{original_code}~{internal_id or duplicate_codes[original_code]}"
            warnings.append({
                "type": "DUPLICATE_TASK_CODE",
                "task_code": original_code,
                "resolved_activity_id": code,
            })

        calendar_id = str(row.get("clndr_id") or default_calendar_id or "DEFAULT")
        calendar = schedule.get_calendar(calendar_id)
        hpd = calendar.hours_per_day or default_hpd
        original_hours = _num(row.get("target_drtn_hr_cnt"), 0.0)
        remaining_hours = _num(row.get("remain_drtn_hr_cnt"), original_hours)
        percent_complete = _num(
            row.get("phys_complete_pct")
            or row.get("complete_pct")
            or row.get("task_complete_pct"),
            0.0,
        )
        source = dict(row)
        source.update({
            "_internal_task_id": internal_id or code,
            "_original_task_code": original_code,
            "_duration_hours_per_day": hpd,
        })
        activity = Activity(
            id=code,
            name=row.get("task_name") or original_code,
            wbs_id=str(row.get("wbs_id") or ""),
            status=normalize_status(row.get("status_code") or "NOT_STARTED"),
            activity_type=str(row.get("task_type") or "TASK"),
            calendar_id=calendar_id,
            original_duration=original_hours / hpd,
            remaining_duration=remaining_hours / hpd,
            actual_start=parse_dt(row.get("act_start_date")),
            actual_finish=parse_dt(row.get("act_end_date") or row.get("act_finish_date")),
            planned_start=parse_dt(row.get("target_start_date") or row.get("plan_start_date")),
            planned_finish=parse_dt(row.get("target_end_date") or row.get("plan_end_date")),
            expected_finish=parse_dt(row.get("expect_end_date")),
            suspend_date=parse_dt(row.get("suspend_date")),
            resume_date=parse_dt(row.get("resume_date")),
            constraint_type=str(row.get("cstr_type") or ""),
            constraint_date=parse_dt(row.get("cstr_date")),
            constraint_type2=str(row.get("cstr_type2") or ""),
            constraint_date2=parse_dt(row.get("cstr_date2")),
            percent_complete=percent_complete,
            primary_resource_id=str(row.get("rsrc_id") or row.get("primary_resource_id") or ""),
            source=source,
        )
        schedule.activities[code] = activity
        internal_to_code[internal_id or code] = code

    external_relationships = 0
    for row in tables.get("TASKPRED", []):
        successor_internal = str(row.get("task_id") or "").strip()
        predecessor_internal = str(row.get("pred_task_id") or "").strip()
        successor = internal_to_code.get(successor_internal)
        if not successor:
            # Relationship belongs to another project or an unavailable task.
            continue
        predecessor = internal_to_code.get(predecessor_internal)
        if not predecessor:
            predecessor = f"EXT:{predecessor_internal}" if predecessor_internal else "EXT:UNKNOWN"
            external_relationships += 1

        raw_type = str(row.get("pred_type") or "PR_FS").upper()
        rel_type = raw_type.replace("PR_", "")
        if rel_type not in {"FS", "SS", "FF", "SF"}:
            warnings.append({
                "type": "UNKNOWN_RELATIONSHIP_TYPE",
                "raw_type": raw_type,
                "successor": successor,
            })
            rel_type = "FS"
        lag_days = _num(row.get("lag_hr_cnt"), 0.0) / default_hpd
        source = dict(row)
        source.update({
            "_successor_internal_id": successor_internal,
            "_predecessor_internal_id": predecessor_internal,
            "_raw_rel_type": raw_type,
        })
        schedule.relationships.append(Relationship(
            predecessor_id=predecessor,
            successor_id=successor,
            rel_type=rel_type,
            lag=lag_days,
            id=str(row.get("task_pred_id") or row.get("pred_id") or ""),
            lag_calendar_id=str(row.get("lag_clndr_id") or ""),
            source=source,
        ))

    schedule.metadata["external_relationship_count"] = external_relationships
    schedule.metadata["selected_activity_count"] = len(schedule.activities)
    schedule.metadata["selected_relationship_count"] = len(schedule.relationships)
    schedule.metadata["duplicate_task_code_count"] = sum(max(0, count - 1) for count in duplicate_codes.values())
    return schedule


def parse_xer_bytes(
    data: bytes,
    default_hours_per_day: float = 8.0,
    project_id: str | None = None,
) -> ProjectSchedule:
    if not isinstance(data, (bytes, bytearray)):
        raise XERValidationError("XER input must be bytes")
    text, encoding = _decode_xer_bytes(bytes(data))
    schedule = parse_xer_text(
        text,
        default_hours_per_day=default_hours_per_day,
        project_id=project_id,
        source_encoding=encoding,
    )
    schedule.metadata["source_xer_sha256"] = sha256_hex(bytes(data))
    schedule.metadata["source_xer_size_bytes"] = len(data)
    return schedule


def parse_xer_file(
    path: str | Path,
    default_hours_per_day: float = 8.0,
    project_id: str | None = None,
) -> ProjectSchedule:
    data = Path(path).read_bytes()
    return parse_xer_bytes(data, default_hours_per_day=default_hours_per_day, project_id=project_id)
