"""Application and engine version metadata."""

ENGINE_NAME = "LABIBV20E - Primavera Planning & Recovery Intelligence"
VERSION = "6.0.0"
BUILD_NAME = "Planning Intelligence Studio"
ENGINE_ID = f"{ENGINE_NAME} {VERSION}"
REPORT_AUTHOR = ENGINE_NAME
