"""Application and engine version metadata."""

ENGINE_NAME = "Primavera Planning & Recovery Intelligence 10X"
VERSION = "6.0.0"
BUILD_NAME = "Planning Intelligence Studio"
ENGINE_ID = f"{ENGINE_NAME} {VERSION}"
REPORT_AUTHOR = ENGINE_NAME
