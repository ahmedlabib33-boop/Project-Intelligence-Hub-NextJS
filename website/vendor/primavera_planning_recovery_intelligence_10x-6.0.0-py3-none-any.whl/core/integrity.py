from __future__ import annotations

from dataclasses import asdict
from typing import Any, Dict, Iterable, List

from .models import ProjectSchedule
from .utils import canonical_sha256, utc_now_iso


def _dt(value):
    return value.isoformat() if value else None


def _calendar_payload(schedule: ProjectSchedule) -> List[Dict[str, Any]]:
    return [
        {
            "id": calendar.id,
            "name": calendar.name,
            "working_weekdays": list(calendar.working_weekdays),
            "hours_per_day": round(float(calendar.hours_per_day), 9),
            "hours_by_weekday": {str(k): round(float(v), 9) for k, v in sorted(calendar.hours_by_weekday.items())},
            "non_working_dates": list(calendar.non_working_dates),
            "working_dates": list(calendar.working_dates),
        }
        for calendar in sorted(schedule.calendars.values(), key=lambda item: item.id)
    ]


def schedule_fingerprint(schedule: ProjectSchedule) -> str:
    """Stable hash of schedule inputs, excluding calculated fields and change log."""
    payload = {
        "project_id": schedule.project_id,
        "project_name": schedule.project_name,
        "data_date": _dt(schedule.data_date),
        "scheduling_mode": str(schedule.metadata.get("scheduling_mode", "RETAINED_LOGIC")).upper(),
        "required_finish_date": schedule.metadata.get("required_finish_date"),
        "activities": [
            {
                "id": activity.id,
                "name": activity.name,
                "wbs_id": activity.wbs_id,
                "status": activity.status,
                "activity_type": activity.activity_type,
                "calendar_id": activity.calendar_id,
                "original_duration": round(float(activity.original_duration), 9),
                "remaining_duration": round(float(activity.remaining_duration), 9),
                "actual_start": _dt(activity.actual_start),
                "actual_finish": _dt(activity.actual_finish),
                "planned_start": _dt(activity.planned_start),
                "planned_finish": _dt(activity.planned_finish),
                "expected_finish": _dt(activity.expected_finish),
                "suspend_date": _dt(activity.suspend_date),
                "resume_date": _dt(activity.resume_date),
                "constraint_type": activity.constraint_type,
                "constraint_date": _dt(activity.constraint_date),
                "constraint_type2": activity.constraint_type2,
                "constraint_date2": _dt(activity.constraint_date2),
                "percent_complete": round(float(activity.percent_complete), 9),
                "primary_resource_id": activity.primary_resource_id,
            }
            for activity in sorted(schedule.activities.values(), key=lambda item: item.id)
        ],
        "relationships": [
            {
                "id": rel.id,
                "predecessor_id": rel.predecessor_id,
                "successor_id": rel.successor_id,
                "rel_type": rel.rel_type,
                "lag": round(float(rel.lag), 9),
                "lag_calendar_id": rel.lag_calendar_id,
            }
            for rel in sorted(schedule.relationships, key=lambda item: item.key)
        ],
        "calendars": _calendar_payload(schedule),
        "wbs": dict(sorted(schedule.wbs.items())),
    }
    return canonical_sha256(payload)


def scenario_fingerprint(master: ProjectSchedule | str, scenario: Dict[str, Any]) -> str:
    master_hash = master if isinstance(master, str) else schedule_fingerprint(master)
    payload = {
        "base_fingerprint": master_hash,
        "changes": scenario.get("changes", []),
        "strategy": scenario.get("strategy"),
        "type": scenario.get("type"),
    }
    return canonical_sha256(payload)


def _locked_relationships(schedule: ProjectSchedule) -> List[tuple]:
    locked = []
    for rel in schedule.relationships:
        successor = schedule.activities.get(rel.successor_id)
        if successor and successor.is_complete:
            locked.append((rel.id, rel.predecessor_id, rel.successor_id, rel.rel_type, round(float(rel.lag), 9)))
    return sorted(locked)


def validate_history_unchanged(before: ProjectSchedule, after: ProjectSchedule) -> List[Dict[str, Any]]:
    """Detect changes to statused/actualized history and completed logic."""
    violations: List[Dict[str, Any]] = []
    if before.project_id != after.project_id:
        violations.append({"issue": "PROJECT_ID_CHANGED", "before": before.project_id, "after": after.project_id})
    if before.data_date != after.data_date:
        violations.append({"issue": "DATA_DATE_CHANGED", "before": _dt(before.data_date), "after": _dt(after.data_date)})

    for aid, activity_before in before.activities.items():
        activity_after = after.activities.get(aid)
        if not activity_after:
            violations.append({"activity_id": aid, "issue": "ACTIVITY_REMOVED"})
            continue

        # Recovery must never manufacture or rewrite progress/status history.
        for field in ("status", "actual_start", "actual_finish"):
            if getattr(activity_before, field) != getattr(activity_after, field):
                violations.append({
                    "activity_id": aid,
                    "issue": "HISTORY_FIELD_CHANGED",
                    "field": field,
                    "before": str(getattr(activity_before, field)),
                    "after": str(getattr(activity_after, field)),
                })

        if activity_before.is_complete:
            for field in (
                "name", "wbs_id", "activity_type", "calendar_id", "original_duration",
                "remaining_duration", "constraint_type", "constraint_date",
                "constraint_type2", "constraint_date2", "percent_complete",
            ):
                if getattr(activity_before, field) != getattr(activity_after, field):
                    violations.append({
                        "activity_id": aid,
                        "issue": "LOCKED_COMPLETED_ACTIVITY_CHANGED",
                        "field": field,
                        "before": str(getattr(activity_before, field)),
                        "after": str(getattr(activity_after, field)),
                    })
        elif activity_before.actual_start:
            # In-progress history is locked, but remaining duration may be changed
            # through an explicitly approved recovery scenario.
            for field in ("name", "wbs_id", "activity_type", "calendar_id", "original_duration"):
                if getattr(activity_before, field) != getattr(activity_after, field):
                    violations.append({
                        "activity_id": aid,
                        "issue": "LOCKED_IN_PROGRESS_HISTORY_CHANGED",
                        "field": field,
                    })

    before_locked_logic = _locked_relationships(before)
    after_locked_logic = _locked_relationships(after)
    if before_locked_logic != after_locked_logic:
        violations.append({
            "issue": "COMPLETED_SUCCESSOR_LOGIC_CHANGED",
            "before_count": len(before_locked_logic),
            "after_count": len(after_locked_logic),
        })

    completed_calendar_ids = {activity.calendar_id for activity in before.activities.values() if activity.is_complete}
    for calendar_id in sorted(completed_calendar_ids):
        before_calendar = before.calendars.get(calendar_id)
        after_calendar = after.calendars.get(calendar_id)
        if before_calendar and not after_calendar:
            violations.append({"issue": "LOCKED_CALENDAR_REMOVED", "calendar_id": calendar_id})
        elif before_calendar and after_calendar and asdict(before_calendar) != asdict(after_calendar):
            violations.append({"issue": "LOCKED_CALENDAR_CHANGED", "calendar_id": calendar_id})
    return violations


def append_audit_event(log: List[Dict[str, Any]], event: Dict[str, Any]) -> Dict[str, Any]:
    """Append a hash-chained audit event and return the stored event."""
    stored = dict(event)
    stored.setdefault("time", utc_now_iso())
    stored["sequence"] = len(log) + 1
    stored["prev_hash"] = log[-1].get("event_hash", "") if log else ""
    payload = {key: value for key, value in stored.items() if key != "event_hash"}
    stored["event_hash"] = canonical_sha256(payload)
    log.append(stored)
    return stored


def verify_audit_chain(log: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    previous = ""
    count = 0
    for count, event in enumerate(log, start=1):
        if int(event.get("sequence", -1)) != count:
            return {"valid": False, "count": count, "error": "SEQUENCE_MISMATCH"}
        if event.get("prev_hash", "") != previous:
            return {"valid": False, "count": count, "error": "PREVIOUS_HASH_MISMATCH"}
        payload = {key: value for key, value in event.items() if key != "event_hash"}
        calculated = canonical_sha256(payload)
        if event.get("event_hash") != calculated:
            return {"valid": False, "count": count, "error": "EVENT_HASH_MISMATCH"}
        previous = calculated
    return {"valid": True, "count": count, "head_hash": previous}


def audit_log_fingerprint(log: Iterable[Dict[str, Any]]) -> str:
    events = list(log)
    return canonical_sha256(events)
