from __future__ import annotations

from datetime import datetime
import csv
from io import BytesIO, StringIO
import json
import re
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple
import xml.etree.ElementTree as ET

from openpyxl import load_workbook

from .models import Activity, Calendar, ProjectSchedule, Relationship, parse_dt
from .utils import clean_text, finite_float


MAX_PRESERVED_ROWS = 100_000

_HEADER_ALIASES = {
    "id": {"id", "activityid", "activity_id", "activity id", "taskid", "task_id", "task id", "activity code", "activitycode"},
    "name": {"name", "activityname", "activity_name", "activity name", "taskname", "task name", "description", "activity description", "item description", "work description"},
    "wbs": {"wbs", "wbsid", "wbs_id", "wbs id", "wbs code", "section", "phase", "package", "work package"},
    "duration": {"duration", "originalduration", "original_duration", "original duration", "od", "duration days", "planned duration"},
    "remaining": {"remainingduration", "remaining_duration", "remaining duration", "rd", "remaining days"},
    "status": {"status", "activitystatus", "activity status", "task status"},
    "percent": {"percentcomplete", "percent_complete", "percent complete", "% complete", "progress", "physical %", "physical percent"},
    "start": {"start", "plannedstart", "planned_start", "planned start", "start date", "early start"},
    "finish": {"finish", "plannedfinish", "planned_finish", "planned finish", "finish date", "end", "end date", "early finish"},
    "actual_start": {"actualstart", "actual_start", "actual start", "actual start date"},
    "actual_finish": {"actualfinish", "actual_finish", "actual finish", "actual finish date"},
    "calendar": {"calendar", "calendarid", "calendar_id", "calendar id"},
    "predecessors": {"predecessors", "predecessor", "pred", "preds", "predecessor ids", "predecessor id", "logic"},
    "successors": {"successors", "successor", "succ", "successor ids", "successor id"},
    "type": {"type", "activitytype", "activity_type", "activity type", "task type"},
    "constraint_type": {"constrainttype", "constraint_type", "constraint type"},
    "constraint_date": {"constraintdate", "constraint_date", "constraint date"},
    "resource": {"resource", "primary resource", "resource id", "primaryresourceid"},
}


def _norm(value: Any) -> str:
    text = clean_text(value or "", 500).strip().lower()
    text = re.sub(r"[^a-z0-9%]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _header_map(headers: Sequence[Any]) -> Dict[str, int]:
    normalized = [_norm(h) for h in headers]
    result: Dict[str, int] = {}
    for field, aliases in _HEADER_ALIASES.items():
        alias_norm = {_norm(a) for a in aliases}
        for idx, value in enumerate(normalized):
            if value in alias_norm:
                result[field] = idx
                break
    return result


def _as_rows(values: Iterable[Sequence[Any]]) -> Tuple[List[Any], List[List[Any]]]:
    rows = [list(row) for row in values]
    while rows and not any(v not in (None, "") for v in rows[0]):
        rows.pop(0)
    if not rows:
        return [], []
    header_idx = 0
    best_score = -1
    for idx, row in enumerate(rows[:20]):
        score = len(_header_map(row))
        if score > best_score:
            best_score = score
            header_idx = idx
    headers = rows[header_idx]
    body = [row for row in rows[header_idx + 1 :] if any(v not in (None, "") for v in row)]
    return headers, body


def _cell(row: Sequence[Any], mapping: Dict[str, int], key: str, default: Any = "") -> Any:
    idx = mapping.get(key)
    if idx is None or idx >= len(row):
        return default
    return row[idx]


def _duration_days(value: Any, default: float = 0.0) -> float:
    if value in (None, ""):
        return default
    if isinstance(value, (int, float)):
        return max(0.0, finite_float(value, default))
    text = clean_text(value, 200).lower().replace(",", "")
    match = re.search(r"(-?\d+(?:\.\d+)?)\s*(hour|hr|day|week|month)s?", text)
    if match:
        n = float(match.group(1))
        unit = match.group(2)
        if unit in {"hour", "hr"}:
            return max(0.0, n / 8.0)
        if unit == "week":
            return max(0.0, n * 5.0)
        if unit == "month":
            return max(0.0, n * 21.0)
        return max(0.0, n)
    try:
        return max(0.0, float(text))
    except ValueError:
        return default


def _parse_pred_token(token: str) -> Tuple[str, str, float]:
    token = token.strip()
    if not token:
        return "", "FS", 0.0
    # A1000 FS+2d | A1000:SS-1 | A1000
    m = re.match(r"^(.+?)(?:\s*[: ]\s*(FS|SS|FF|SF))?(?:\s*([+-])\s*(\d+(?:\.\d+)?)\s*[dD]?)?$", token, re.I)
    if not m:
        return token, "FS", 0.0
    aid = clean_text(m.group(1), 255)
    rel = (m.group(2) or "FS").upper()
    lag = float(m.group(4) or 0.0)
    if m.group(3) == "-":
        lag *= -1
    return aid, rel, lag


def _pred_tokens(value: Any) -> List[Tuple[str, str, float]]:
    text = clean_text(value or "", 4000)
    if not text:
        return []
    return [_parse_pred_token(tok) for tok in re.split(r"[;,|\n]+", text) if tok.strip()]


def schedule_from_rows(
    headers: Sequence[Any],
    rows: Sequence[Sequence[Any]],
    *,
    project_name: str = "Imported Tabular Schedule",
    data_date: Any = None,
    source_format: str = "TABULAR",
) -> ProjectSchedule:
    mapping = _header_map(headers)
    if "name" not in mapping and "id" not in mapping:
        raise ValueError("Could not identify Activity ID/Name columns in the tabular schedule.")

    schedule = ProjectSchedule(
        project_id="TABULAR",
        project_name=clean_text(project_name, 4000) or "Imported Tabular Schedule",
        data_date=parse_dt(data_date),
        calendars={"DEFAULT": Calendar(id="DEFAULT", name="Default 5D")},
        metadata={"import_format": source_format, "header_mapping": mapping},
    )
    source_id_to_internal: Dict[str, str] = {}
    pending_preds: List[Tuple[str, Any]] = []

    used: set[str] = set()
    for idx, row in enumerate(rows, start=1):
        raw_id = clean_text(_cell(row, mapping, "id", ""), 255)
        base = raw_id or f"A{idx:05d}"
        aid = base
        suffix = 2
        while aid in used:
            aid = f"{base}-{suffix}"
            suffix += 1
        used.add(aid)
        if raw_id:
            source_id_to_internal[raw_id] = aid
        name = clean_text(_cell(row, mapping, "name", raw_id or f"Activity {idx}"), 4000)
        od = _duration_days(_cell(row, mapping, "duration", 0.0), 0.0)
        rd_raw = _cell(row, mapping, "remaining", None)
        rd = _duration_days(rd_raw, od) if rd_raw not in (None, "") else od
        status = _cell(row, mapping, "status", "NOT_STARTED")
        pct = finite_float(_cell(row, mapping, "percent", 0.0), 0.0)
        activity = Activity(
            id=aid,
            name=name,
            wbs_id=clean_text(_cell(row, mapping, "wbs", ""), 255),
            status=status,
            activity_type=_cell(row, mapping, "type", "TASK"),
            calendar_id=clean_text(_cell(row, mapping, "calendar", "DEFAULT"), 255) or "DEFAULT",
            original_duration=od,
            remaining_duration=rd,
            planned_start=parse_dt(_cell(row, mapping, "start", None)),
            planned_finish=parse_dt(_cell(row, mapping, "finish", None)),
            actual_start=parse_dt(_cell(row, mapping, "actual_start", None)),
            actual_finish=parse_dt(_cell(row, mapping, "actual_finish", None)),
            percent_complete=pct,
            constraint_type=_cell(row, mapping, "constraint_type", ""),
            constraint_date=parse_dt(_cell(row, mapping, "constraint_date", None)),
            primary_resource_id=clean_text(_cell(row, mapping, "resource", ""), 255),
            source={"row": idx, "source_id": raw_id, "source_format": source_format},
        )
        if activity.status == "COMPLETE":
            activity.remaining_duration = 0.0
            if activity.percent_complete == 0:
                activity.percent_complete = 100.0
        schedule.activities[aid] = activity
        pending_preds.append((aid, _cell(row, mapping, "predecessors", "")))
        if activity.wbs_id:
            schedule.wbs.setdefault(activity.wbs_id, activity.wbs_id)
        if activity.calendar_id not in schedule.calendars:
            schedule.calendars[activity.calendar_id] = Calendar(id=activity.calendar_id, name=activity.calendar_id)

    rel_seen = set()
    for succ, value in pending_preds:
        for pred_raw, rel_type, lag in _pred_tokens(value):
            pred = source_id_to_internal.get(pred_raw, pred_raw)
            if pred not in schedule.activities or pred == succ:
                continue
            key = (pred, succ, rel_type, round(lag, 6))
            if key in rel_seen:
                continue
            rel_seen.add(key)
            schedule.relationships.append(Relationship(pred, succ, rel_type, lag))

    # If no predecessor data is available, sequence by source row to create a usable deterministic network.
    if schedule.activities and not schedule.relationships:
        ids = list(schedule.activities)
        for pred, succ in zip(ids, ids[1:]):
            schedule.relationships.append(Relationship(pred, succ, "FS", 0.0, source={"generated": True, "reason": "No source logic columns detected"}))
        schedule.metadata["logic_assumption"] = "Sequential FS logic generated because the import contained no recognized predecessor logic."

    return schedule


def parse_csv_schedule_bytes(data: bytes, *, filename: str = "schedule.csv", data_date: Any = None) -> ProjectSchedule:
    text = data.decode("utf-8-sig", errors="replace")
    sample = text[:8192]
    delimiter = "\t" if filename.lower().endswith(".tsv") else ","
    try:
        delimiter = csv.Sniffer().sniff(sample, delimiters=",\t;|").delimiter
    except csv.Error:
        pass
    rows = list(csv.reader(StringIO(text), delimiter=delimiter))
    headers, body = _as_rows(rows)
    schedule = schedule_from_rows(headers, body, project_name=filename.rsplit(".", 1)[0], data_date=data_date, source_format="CSV")
    h=[str(x or "") for x in headers]
    schedule.raw_tables["CSV_SOURCE"]=[{h[i] if i<len(h) and h[i] else f"COL_{i+1}": (row[i] if i<len(row) else "") for i in range(max(len(h),len(row)))} for row in body]
    return schedule


def parse_xlsx_schedule_bytes(data: bytes, *, filename: str = "schedule.xlsx", data_date: Any = None) -> ProjectSchedule:
    wb = load_workbook(BytesIO(data), read_only=True, data_only=False)
    best = None
    best_score = -1
    preserved: Dict[str, List[Dict[str, Any]]] = {}
    for ws in wb.worksheets:
        all_rows=[list(r) for r in ws.iter_rows(values_only=True)]
        headers, body = _as_rows(all_rows)
        score = len(_header_map(headers))
        if headers:
            h=[str(x or "") for x in headers]
            preserved[f"XLSX::{ws.title}"]=[{h[i] if i<len(h) and h[i] else f"COL_{i+1}": (row[i] if i<len(row) else "") for i in range(max(len(h),len(row)))} for row in body[:MAX_PRESERVED_ROWS]]
        if body and score > best_score:
            best = (ws.title, headers, body)
            best_score = score
    if best is None:
        raise ValueError("No populated worksheet with recognizable schedule columns was found.")
    sheet, headers, body = best
    schedule = schedule_from_rows(headers, body, project_name=filename.rsplit(".", 1)[0], data_date=data_date, source_format="XLSX")
    schedule.metadata["source_sheet"] = sheet
    schedule.raw_tables.update(preserved)
    return schedule


def _lname(tag: str) -> str:
    return tag.split("}")[-1].split(":")[-1]


def _children_map(elem: ET.Element) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for child in list(elem):
        name = _lname(child.tag)
        if child.text is not None and name not in out:
            out[name] = child.text.strip()
    return out


def parse_xml_schedule_bytes(data: bytes, *, filename: str = "schedule.xml") -> ProjectSchedule:
    root = ET.fromstring(data)
    project_name = filename.rsplit(".", 1)[0]
    data_date = None
    for elem in root.iter():
        name = _lname(elem.tag)
        if name in {"Project", "PROJECT"}:
            m = _children_map(elem)
            project_name = m.get("Name") or m.get("ProjectName") or m.get("Id") or project_name
            data_date = m.get("DataDate") or m.get("CurrentDate") or data_date
            if project_name:
                break

    schedule = ProjectSchedule(
        project_id="XML",
        project_name=clean_text(project_name, 4000),
        data_date=parse_dt(data_date),
        calendars={"DEFAULT": Calendar(id="DEFAULT")},
        metadata={"import_format": "XML", "source_filename": filename},
    )

    object_to_activity: Dict[str, str] = {}
    activity_nodes: List[ET.Element] = []
    for elem in root.iter():
        n = _lname(elem.tag).lower()
        if n in {"activity", "task"}:
            m = _children_map(elem)
            if any(k in m for k in ("ActivityId", "Id", "UID", "Name")):
                activity_nodes.append(elem)

    used: set[str] = set()
    for idx, elem in enumerate(activity_nodes, start=1):
        m = _children_map(elem)
        object_id = m.get("ObjectId") or m.get("UID") or m.get("Id") or str(idx)
        raw_id = m.get("ActivityId") or m.get("ID") or m.get("Id") or m.get("UID") or f"A{idx:05d}"
        aid = clean_text(raw_id, 255) or f"A{idx:05d}"
        base = aid
        i = 2
        while aid in used:
            aid = f"{base}-{i}"
            i += 1
        used.add(aid)
        object_to_activity[str(object_id)] = aid
        object_to_activity[str(raw_id)] = aid
        od = _duration_days(m.get("OriginalDuration") or m.get("Duration") or 0.0)
        rd = _duration_days(m.get("RemainingDuration") or m.get("RemainingDurationHours") or od, od)
        # P6 XML durations are often ISO 8601; recognize PT40H / P5D.
        for key, target in ((m.get("OriginalDuration"), "od"), (m.get("RemainingDuration"), "rd")):
            if key and isinstance(key, str) and key.upper().startswith("P"):
                dm = re.search(r"(?:(\d+(?:\.\d+)?)D)?(?:T(?:(\d+(?:\.\d+)?)H)?)?", key.upper())
                if dm:
                    days = float(dm.group(1) or 0.0) + float(dm.group(2) or 0.0) / 8.0
                    if target == "od": od = days
                    else: rd = days
        status = m.get("Status") or m.get("ActivityStatus") or "NOT_STARTED"
        pct = finite_float(m.get("PercentComplete") or m.get("PhysicalPercentComplete") or 0.0, 0.0)
        cal_id = m.get("CalendarObjectId") or m.get("CalendarUID") or "DEFAULT"
        activity = Activity(
            id=aid,
            name=m.get("Name") or m.get("ActivityName") or aid,
            wbs_id=m.get("WBSObjectId") or m.get("OutlineNumber") or "",
            status=status,
            activity_type=m.get("Type") or m.get("ActivityType") or "TASK",
            calendar_id=str(cal_id),
            original_duration=od,
            remaining_duration=rd,
            planned_start=parse_dt(m.get("PlannedStartDate") or m.get("Start") or m.get("StartDate")),
            planned_finish=parse_dt(m.get("PlannedFinishDate") or m.get("Finish") or m.get("FinishDate")),
            actual_start=parse_dt(m.get("ActualStartDate") or m.get("ActualStart")),
            actual_finish=parse_dt(m.get("ActualFinishDate") or m.get("ActualFinish")),
            percent_complete=pct,
            constraint_type=m.get("PrimaryConstraintType") or m.get("ConstraintType") or "",
            constraint_date=parse_dt(m.get("PrimaryConstraintDate") or m.get("ConstraintDate")),
            source={"xml_object_id": str(object_id)},
        )
        schedule.activities[aid] = activity
        if activity.calendar_id not in schedule.calendars:
            schedule.calendars[activity.calendar_id] = Calendar(id=activity.calendar_id, name=activity.calendar_id)

    for elem in root.iter():
        n = _lname(elem.tag).lower()
        if n not in {"relationship", "predecessorlink", "taskpred", "predecessor"}:
            continue
        m = _children_map(elem)
        pred_raw = m.get("PredecessorActivityObjectId") or m.get("PredecessorUID") or m.get("PredecessorId") or m.get("PredecessorActivityId")
        succ_raw = m.get("SuccessorActivityObjectId") or m.get("SuccessorUID") or m.get("SuccessorId") or m.get("SuccessorActivityId")
        if n == "predecessorlink" and not succ_raw:
            parent = None
            # ElementTree does not expose parents; MSPDI relationships will often be caught only if SuccessorUID is explicit.
        pred = object_to_activity.get(str(pred_raw), str(pred_raw or ""))
        succ = object_to_activity.get(str(succ_raw), str(succ_raw or ""))
        if pred not in schedule.activities or succ not in schedule.activities or pred == succ:
            continue
        rel_type = m.get("Type") or m.get("RelationshipType") or "FS"
        type_map = {"0": "FF", "1": "FS", "2": "SF", "3": "SS", "FINISH_TO_START": "FS", "START_TO_START": "SS", "FINISH_TO_FINISH": "FF", "START_TO_FINISH": "SF"}
        rel_type = type_map.get(str(rel_type).upper(), str(rel_type).upper())
        lag = finite_float(m.get("Lag") or m.get("LagDuration") or 0.0, 0.0)
        schedule.relationships.append(Relationship(pred, succ, rel_type, lag))

    if not schedule.activities:
        raise ValueError("No Activity/Task nodes were recognized in the XML schedule.")
    if not schedule.relationships:
        ids = list(schedule.activities)
        for pred, succ in zip(ids, ids[1:]):
            schedule.relationships.append(Relationship(pred, succ, "FS", 0.0, source={"generated": True, "reason": "No recognized XML relationship nodes"}))
        schedule.metadata["logic_assumption"] = "Sequential FS logic generated because no supported XML relationship elements were recognized."
    return schedule
