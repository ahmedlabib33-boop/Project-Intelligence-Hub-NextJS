from __future__ import annotations

from dataclasses import asdict
from typing import Any, Dict, Iterable, List

from .cpm import calculate_cpm
from .errors import ScenarioValidationError
from .integrity import schedule_fingerprint, validate_history_unchanged
from .models import Activity, Change, ProjectSchedule, Relationship, parse_dt
from .utils import canonical_sha256, clean_text, finite_float, utc_now_iso


ALLOWED_BASES = {
    "APPROVED_VARIATION",
    "APPROVED_EOT",
    "DESIGN_CHANGE",
    "SCOPE_CHANGE",
    "MILESTONE_CHANGE",
    "PROCUREMENT_CHANGE",
    "APPROVED_METHOD_CHANGE",
    "CLIENT_INSTRUCTION",
}

_ACTIVITY_FIELDS = {
    "remaining_duration",
    "calendar_id",
    "constraint_type",
    "constraint_date",
    "constraint_type2",
    "constraint_date2",
    "expected_finish",
    "primary_resource_id",
}
_DATE_FIELDS = {"constraint_date", "constraint_date2", "expected_finish"}
_TEXT_FIELDS = {"calendar_id", "constraint_type", "constraint_type2", "primary_resource_id"}


def _find_relationship(schedule: ProjectSchedule, item: Dict[str, Any]) -> Relationship:
    relationship_id = clean_text(item.get("relationship_id"), 255)
    pred = clean_text(item.get("predecessor_id"), 255)
    succ = clean_text(item.get("successor_id"), 255)
    candidates = [rel for rel in schedule.relationships if rel.predecessor_id == pred and rel.successor_id == succ]
    if relationship_id:
        candidates = [rel for rel in candidates if rel.id == relationship_id]
    if not candidates:
        raise ScenarioValidationError(f"Approved relationship was not found: {pred} -> {succ}")
    return sorted(candidates, key=lambda rel: rel.key)[0]


def _change_record(
    *,
    basis: str,
    item: Dict[str, Any],
    activity_id: str,
    field: str,
    before: Any,
    after: Any,
    predecessor_id: str = "",
    successor_id: str = "",
    relationship_id: str = "",
) -> Change:
    approved_at = clean_text(item.get("approved_at") or utc_now_iso(), 100)
    approved_by = clean_text(item.get("approved_by"), 1000)
    evidence_ref = clean_text(item.get("evidence_ref"), 2000)
    reason = clean_text(item.get("reason") or "Approved revision", 8000)
    payload = {
        "basis": basis,
        "activity_id": activity_id,
        "field": field,
        "before": before,
        "after": after,
        "approved_at": approved_at,
        "approved_by": approved_by,
        "evidence_ref": evidence_ref,
        "reason": reason,
    }
    return Change(
        kind="REVISED_SCHEDULE_CHANGE",
        activity_id=activity_id,
        field=field,
        before=before,
        after=after,
        reason=f"{basis}: {reason}",
        risk=clean_text(item.get("risk") or "MEDIUM", 20).upper(),
        requires_approval=False,
        predecessor_id=predecessor_id,
        successor_id=successor_id,
        relationship_id=relationship_id,
        evidence_ref=evidence_ref,
        approved_by=approved_by,
        approved_at=approved_at,
        provenance_hash=canonical_sha256(payload),
    )


def build_revised_schedule(master: ProjectSchedule, basis: str, approved_changes: List[Dict[str, Any]]) -> ProjectSchedule:
    """Create a controlled revised schedule while preserving statused history.

    Supported operations are SET_ACTIVITY (default), ADD_ACTIVITY,
    ADD_RELATIONSHIP, UPDATE_RELATIONSHIP and REMOVE_RELATIONSHIP. Every item is
    logged with approval/evidence provenance and the master remains unchanged.
    """
    basis = clean_text(basis, 100).upper()
    if basis not in ALLOWED_BASES:
        raise ScenarioValidationError(f"Revision basis must be one of: {sorted(ALLOWED_BASES)}")
    if not isinstance(approved_changes, list) or not approved_changes:
        raise ScenarioValidationError("At least one approved revision change is required")

    revised = master.clone()
    calculate_cpm(revised)
    master_fingerprint = schedule_fingerprint(master)

    for index, raw_item in enumerate(approved_changes, start=1):
        if not isinstance(raw_item, dict):
            raise ScenarioValidationError(f"Approved change {index} must be an object")
        item = dict(raw_item)
        operation = clean_text(item.get("operation") or "SET_ACTIVITY", 100).upper()

        if operation == "SET_ACTIVITY":
            activity_id = clean_text(item.get("activity_id"), 255)
            if activity_id not in revised.activities:
                raise ScenarioValidationError(f"Unknown activity: {activity_id}")
            activity = revised.activities[activity_id]
            if activity.is_complete:
                raise ScenarioValidationError(f"Historical completed activity is locked: {activity_id}")
            field = clean_text(item.get("field"), 100)
            if field not in _ACTIVITY_FIELDS:
                raise ScenarioValidationError(f"Unsupported revised activity field: {field}")
            before = getattr(activity, field)
            raw_after = item.get("after")
            if field == "remaining_duration":
                after = finite_float(raw_after, field="remaining_duration")
                if after < 0:
                    raise ScenarioValidationError("remaining_duration cannot be negative")
            elif field in _DATE_FIELDS:
                after = parse_dt(raw_after)
                if raw_after not in (None, "") and after is None:
                    raise ScenarioValidationError(f"Invalid date for {field}")
            else:
                after = clean_text(raw_after, 255)
                if field == "calendar_id" and after not in revised.calendars:
                    raise ScenarioValidationError(f"Unknown calendar: {after}")
                if field.startswith("constraint_type"):
                    after = after.upper()
            setattr(activity, field, after)
            revised.changes.append(_change_record(
                basis=basis, item=item, activity_id=activity_id, field=field, before=before, after=after,
            ))

        elif operation == "ADD_ACTIVITY":
            row = dict(item.get("activity") or item)
            activity_id = clean_text(row.get("id") or row.get("activity_id"), 255)
            if not activity_id or activity_id in revised.activities:
                raise ScenarioValidationError(f"New activity ID is missing or already exists: {activity_id}")
            activity = Activity(
                id=activity_id,
                name=row.get("name", ""),
                wbs_id=row.get("wbs_id", ""),
                status="NOT_STARTED",
                activity_type=row.get("activity_type", "TASK"),
                calendar_id=row.get("calendar_id", revised.metadata.get("default_calendar_id", "DEFAULT")),
                original_duration=row.get("original_duration", row.get("remaining_duration", 0)),
                remaining_duration=row.get("remaining_duration", 0),
                planned_start=parse_dt(row.get("planned_start")),
                planned_finish=parse_dt(row.get("planned_finish")),
                constraint_type=row.get("constraint_type", ""),
                constraint_date=parse_dt(row.get("constraint_date")),
                primary_resource_id=row.get("primary_resource_id", ""),
            )
            if activity.calendar_id not in revised.calendars:
                raise ScenarioValidationError(f"Unknown calendar: {activity.calendar_id}")
            revised.activities[activity_id] = activity
            revised.changes.append(_change_record(
                basis=basis, item=item, activity_id=activity_id, field="activity", before=None, after=asdict(activity),
            ))

        elif operation == "ADD_RELATIONSHIP":
            pred = clean_text(item.get("predecessor_id"), 255)
            succ = clean_text(item.get("successor_id"), 255)
            if pred not in revised.activities or succ not in revised.activities:
                raise ScenarioValidationError(f"Unknown relationship activity: {pred} -> {succ}")
            relationship = Relationship(
                predecessor_id=pred,
                successor_id=succ,
                rel_type=item.get("rel_type", "FS"),
                lag=item.get("lag", 0),
                id=item.get("relationship_id", ""),
                lag_calendar_id=item.get("lag_calendar_id", ""),
            )
            revised.relationships.append(relationship)
            revised.changes.append(_change_record(
                basis=basis, item=item, activity_id=succ, field="relationship", before=None, after=asdict(relationship),
                predecessor_id=pred, successor_id=succ, relationship_id=relationship.id,
            ))

        elif operation in {"UPDATE_RELATIONSHIP", "REMOVE_RELATIONSHIP"}:
            relationship = _find_relationship(revised, item)
            successor = revised.activities.get(relationship.successor_id)
            if successor and successor.is_complete:
                raise ScenarioValidationError("Logic feeding a completed successor is locked")
            before = asdict(relationship)
            if operation == "REMOVE_RELATIONSHIP":
                revised.relationships.remove(relationship)
                after = None
            else:
                if "rel_type" in item:
                    relationship.rel_type = clean_text(item.get("rel_type"), 10).upper()
                if "lag" in item:
                    relationship.lag = finite_float(item.get("lag"), field="relationship lag")
                after = asdict(relationship)
            revised.changes.append(_change_record(
                basis=basis, item=item, activity_id=relationship.successor_id, field="relationship", before=before, after=after,
                predecessor_id=relationship.predecessor_id, successor_id=relationship.successor_id, relationship_id=relationship.id,
            ))
        else:
            raise ScenarioValidationError(f"Unsupported revision operation: {operation}")

    calculate_cpm(revised)
    violations = validate_history_unchanged(master, revised)
    if violations:
        raise ScenarioValidationError(f"Approved revision changed locked history: {violations[:10]}")

    revised.metadata.update({
        "revision_basis": basis,
        "revision_source_fingerprint": master_fingerprint,
        "revision_fingerprint": schedule_fingerprint(revised),
        "revision_change_count": len(approved_changes),
        "revision_created_at": utc_now_iso(),
    })
    return revised
