from __future__ import annotations

from collections import defaultdict
import heapq
import math
import time
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

from .calendar_engine import forecast_activity_dates, workdays_between
from .errors import ScheduleCycleError, ScheduleDataError
from .models import Activity, ProjectSchedule, Relationship, parse_dt
from .utils import finite_float

_VALID_MODES = {"RETAINED_LOGIC", "PROGRESS_OVERRIDE", "ACTUAL_DATES"}

_CONSTRAINT_MAP = {
    "CS_MSO": "START_ON",
    "MANDATORY_START": "START_ON",
    "MUST_START_ON": "START_ON",
    "START_ON": "START_ON",
    "CS_MEO": "FINISH_ON",
    "MANDATORY_FINISH": "FINISH_ON",
    "MUST_FINISH_ON": "FINISH_ON",
    "FINISH_ON": "FINISH_ON",
    "CS_SNET": "START_ON_OR_AFTER",
    "START_ON_OR_AFTER": "START_ON_OR_AFTER",
    "START_NOT_EARLIER_THAN": "START_ON_OR_AFTER",
    "START_NO_EARLIER_THAN": "START_ON_OR_AFTER",
    "CS_SNLT": "START_ON_OR_BEFORE",
    "START_ON_OR_BEFORE": "START_ON_OR_BEFORE",
    "START_NOT_LATER_THAN": "START_ON_OR_BEFORE",
    "START_NO_LATER_THAN": "START_ON_OR_BEFORE",
    "CS_FNET": "FINISH_ON_OR_AFTER",
    "FINISH_ON_OR_AFTER": "FINISH_ON_OR_AFTER",
    "FINISH_NOT_EARLIER_THAN": "FINISH_ON_OR_AFTER",
    "FINISH_NO_EARLIER_THAN": "FINISH_ON_OR_AFTER",
    "CS_FNLT": "FINISH_ON_OR_BEFORE",
    "FINISH_ON_OR_BEFORE": "FINISH_ON_OR_BEFORE",
    "FINISH_NOT_LATER_THAN": "FINISH_ON_OR_BEFORE",
    "FINISH_NO_LATER_THAN": "FINISH_ON_OR_BEFORE",
    "CS_ALAP": "AS_LATE_AS_POSSIBLE",
    "AS_LATE_AS_POSSIBLE": "AS_LATE_AS_POSSIBLE",
    "CS_ASAP": "AS_SOON_AS_POSSIBLE",
    "AS_SOON_AS_POSSIBLE": "AS_SOON_AS_POSSIBLE",
}


def _normalized_mode(schedule: ProjectSchedule) -> str:
    mode = str(schedule.metadata.get("scheduling_mode", "RETAINED_LOGIC")).upper().strip()
    return mode if mode in _VALID_MODES else "RETAINED_LOGIC"


def _active_relationships(schedule: ProjectSchedule, mode: str) -> List[Relationship]:
    rels: List[Relationship] = []
    for rel in schedule.relationships:
        if rel.predecessor_id not in schedule.activities or rel.successor_id not in schedule.activities:
            continue
        if mode in {"PROGRESS_OVERRIDE", "ACTUAL_DATES"} and schedule.activities[rel.successor_id].is_in_progress:
            # The successor has already started. In this approximation, progress
            # override releases its remaining work from incoming logic.
            continue
        rels.append(rel)
    return rels


def _find_cycle(nodes: Iterable[str], adjacency: Dict[str, set[str]]) -> List[str]:
    """Find one directed cycle without recursion-depth limits."""
    state: Dict[str, int] = {node: 0 for node in nodes}
    for start_node in sorted(state):
        if state[start_node] != 0:
            continue
        path: List[str] = [start_node]
        positions: Dict[str, int] = {start_node: 0}
        state[start_node] = 1
        stack: List[Tuple[str, object]] = [(start_node, iter(sorted(adjacency.get(start_node, set()))))]
        while stack:
            node, iterator = stack[-1]
            try:
                nxt = next(iterator)
            except StopIteration:
                stack.pop()
                state[node] = 2
                positions.pop(node, None)
                if path and path[-1] == node:
                    path.pop()
                continue

            nxt_state = state.get(nxt, 0)
            if nxt_state == 0:
                state[nxt] = 1
                positions[nxt] = len(path)
                path.append(nxt)
                stack.append((nxt, iter(sorted(adjacency.get(nxt, set())))))
            elif nxt_state == 1:
                start_index = positions[nxt]
                return path[start_index:] + [nxt]
    return []


def _topological_order(nodes: Sequence[str], relationships: Sequence[Relationship]) -> List[str]:
    adjacency: Dict[str, set[str]] = {node: set() for node in nodes}
    indegree: Dict[str, int] = {node: 0 for node in nodes}
    for rel in relationships:
        pred, succ = rel.predecessor_id, rel.successor_id
        if succ not in adjacency[pred]:
            adjacency[pred].add(succ)
            indegree[succ] += 1

    heap = [node for node, degree in indegree.items() if degree == 0]
    heapq.heapify(heap)
    order: List[str] = []
    while heap:
        node = heapq.heappop(heap)
        order.append(node)
        for succ in sorted(adjacency[node]):
            indegree[succ] -= 1
            if indegree[succ] == 0:
                heapq.heappush(heap, succ)

    if len(order) != len(nodes):
        cycle = _find_cycle(nodes, adjacency)
        detail = " -> ".join(cycle) if cycle else "cycle detected"
        raise ScheduleCycleError(f"Schedule contains a directed logic cycle: {detail}")
    return order


def _forward_bound(pred: Activity, succ: Activity, rel: Relationship) -> float:
    dp = pred.duration
    ds = succ.duration
    rel_type = rel.rel_type.upper()
    if rel_type == "FS":
        return pred.es + dp + rel.lag
    if rel_type == "SS":
        return pred.es + rel.lag
    if rel_type == "FF":
        return pred.es + dp + rel.lag - ds
    if rel_type == "SF":
        return pred.es + rel.lag - ds
    raise ScheduleDataError(f"Unsupported relationship type: {rel.rel_type}")


def _latest_start_bound(pred: Activity, succ: Activity, rel: Relationship) -> float:
    dp = pred.duration
    ds = succ.duration
    rel_type = rel.rel_type.upper()
    if rel_type == "FS":
        return succ.ls - rel.lag - dp
    if rel_type == "SS":
        return succ.ls - rel.lag
    if rel_type == "FF":
        return (succ.ls + ds) - rel.lag - dp
    if rel_type == "SF":
        return (succ.ls + ds) - rel.lag
    raise ScheduleDataError(f"Unsupported relationship type: {rel.rel_type}")


def relationship_slack(schedule: ProjectSchedule, rel: Relationship) -> float:
    pred = schedule.activities[rel.predecessor_id]
    succ = schedule.activities[rel.successor_id]
    return succ.es - _forward_bound(pred, succ, rel)


def normalize_constraint_type(value: str) -> str:
    text = str(value or "").upper().strip().replace("-", "_").replace(" ", "_")
    return _CONSTRAINT_MAP.get(text, text)


def _constraint_bounds(schedule: ProjectSchedule, activity: Activity) -> Tuple[List[float], List[float], List[Dict]]:
    lowers: List[float] = []
    uppers: List[float] = []
    details: List[Dict] = []
    if not schedule.data_date:
        for raw_type, raw_date in (
            (activity.constraint_type, activity.constraint_date),
            (activity.constraint_type2, activity.constraint_date2),
        ):
            if raw_type:
                details.append({
                    "activity_id": activity.id,
                    "constraint_type": normalize_constraint_type(raw_type),
                    "constraint_date": raw_date.isoformat() if raw_date else None,
                    "applied": False,
                    "reason": "DATA_DATE_MISSING",
                })
        return lowers, uppers, details

    calendar = schedule.get_calendar(activity.calendar_id)
    for raw_type, raw_date in (
        (activity.constraint_type, activity.constraint_date),
        (activity.constraint_type2, activity.constraint_date2),
    ):
        if not raw_type:
            continue
        constraint_type = normalize_constraint_type(raw_type)
        if not raw_date:
            details.append({
                "activity_id": activity.id,
                "constraint_type": constraint_type,
                "constraint_date": None,
                "applied": False,
                "reason": "CONSTRAINT_DATE_MISSING",
            })
            continue
        offset = workdays_between(schedule.data_date, raw_date, calendar)
        start_offset = offset
        if constraint_type.startswith("FINISH_") or constraint_type == "FINISH_ON":
            start_offset = offset - activity.duration

        applied = True
        if constraint_type in {"START_ON_OR_AFTER", "FINISH_ON_OR_AFTER"}:
            lowers.append(start_offset)
        elif constraint_type in {"START_ON_OR_BEFORE", "FINISH_ON_OR_BEFORE"}:
            uppers.append(start_offset)
        elif constraint_type in {"START_ON", "FINISH_ON"}:
            lowers.append(start_offset)
            uppers.append(start_offset)
        elif constraint_type in {"AS_SOON_AS_POSSIBLE"}:
            pass
        elif constraint_type == "AS_LATE_AS_POSSIBLE":
            applied = False
        else:
            applied = False

        details.append({
            "activity_id": activity.id,
            "constraint_type": constraint_type,
            "constraint_date": raw_date.isoformat(),
            "start_offset_days": round(start_offset, 6),
            "applied": applied,
            "reason": None if applied else "UNSUPPORTED_OR_INFORMATIONAL_CONSTRAINT",
        })
    return lowers, uppers, details


def _required_finish_offset(schedule: ProjectSchedule) -> Optional[float]:
    if not schedule.data_date:
        return None
    raw = (
        schedule.metadata.get("required_finish_date")
        or schedule.metadata.get("must_finish_by")
        or schedule.metadata.get("planned_finish_date")
    )
    finish = parse_dt(raw)
    if not finish:
        return None
    return workdays_between(schedule.data_date, finish, schedule.get_calendar())


def _validate_numeric_inputs(schedule: ProjectSchedule) -> None:
    for activity in schedule.activities.values():
        for field_name in ("original_duration", "remaining_duration"):
            value = finite_float(getattr(activity, field_name), field=field_name)
            if value < -1e-9:
                raise ScheduleDataError(f"Activity {activity.id} has negative {field_name}: {value}")
        if not (0.0 <= float(activity.percent_complete) <= 100.0 + 1e-9):
            raise ScheduleDataError(f"Activity {activity.id} has invalid percent_complete: {activity.percent_complete}")
    for rel in schedule.relationships:
        finite_float(rel.lag, field="relationship lag")
        if rel.predecessor_id == rel.successor_id:
            raise ScheduleCycleError(f"Self-referencing relationship on activity {rel.predecessor_id}")


def _enumerate_driving_paths(
    schedule: ProjectSchedule,
    driving_predecessors: Dict[str, List[str]],
    project_finish: float,
    tolerance: float,
    max_paths: int,
) -> List[List[str]]:
    """Enumerate driving paths iteratively to support very deep schedules."""
    end_nodes = sorted(
        aid for aid, activity in schedule.activities.items()
        if abs(activity.ef - project_finish) <= tolerance and activity.critical
    )
    paths: List[List[str]] = []

    for end in end_nodes:
        # The predecessor graph is a subset of the already validated DAG. Store
        # paths as persistent linked tuples so a 100k-activity chain does not
        # repeatedly copy an ever-growing Python list.
        stack: List[Tuple[str, tuple]] = [(end, (end, None))]
        while stack and len(paths) < max_paths:
            node, link = stack.pop()
            predecessors = sorted(
                pred for pred in driving_predecessors.get(node, [])
                if schedule.activities[pred].critical
            )
            if not predecessors:
                path: List[str] = []
                cursor = link
                while cursor is not None:
                    path.append(cursor[0])
                    cursor = cursor[1]
                paths.append(path)
                continue
            # Reverse push order so lexical-first predecessor is processed first.
            for pred in reversed(predecessors):
                stack.append((pred, (pred, link)))
        if len(paths) >= max_paths:
            break

    unique: List[List[str]] = []
    seen_paths = set()
    for path in paths:
        key = tuple(path)
        if key not in seen_paths:
            seen_paths.add(key)
            unique.append(path)
    return unique


def _calculate_core(
    schedule: ProjectSchedule,
    critical_threshold: float,
    driving_tolerance: float,
    max_critical_paths: int,
) -> Dict:
    _validate_numeric_inputs(schedule)
    mode = _normalized_mode(schedule)
    active_relationships = _active_relationships(schedule, mode)
    node_ids = sorted(schedule.activities)
    order = _topological_order(node_ids, active_relationships)

    predecessors: Dict[str, List[Relationship]] = {aid: [] for aid in node_ids}
    successors: Dict[str, List[Relationship]] = {aid: [] for aid in node_ids}
    for rel in active_relationships:
        predecessors[rel.successor_id].append(rel)
        successors[rel.predecessor_id].append(rel)
    for rels in predecessors.values():
        rels.sort(key=lambda r: r.key)
    for rels in successors.values():
        rels.sort(key=lambda r: r.key)

    constraint_details: List[Dict] = []
    constraint_lowers: Dict[str, List[float]] = {}
    constraint_uppers: Dict[str, List[float]] = {}
    for aid, activity in schedule.activities.items():
        activity.es = activity.ef = activity.ls = activity.lf = 0.0
        activity.total_float = activity.free_float = 0.0
        activity.critical = activity.longest_path = False
        activity.path_drag = 0.0
        activity.driving_predecessor_id = ""
        lowers, uppers, details = _constraint_bounds(schedule, activity)
        constraint_lowers[aid] = lowers
        constraint_uppers[aid] = uppers
        constraint_details.extend(details)

    allow_negative = bool(schedule.metadata.get("allow_negative_offsets", False))
    controlling_predecessor: Dict[str, Optional[str]] = {}
    controlling_relationship: Dict[str, Optional[Relationship]] = {}

    for aid in order:
        activity = schedule.activities[aid]
        candidates: List[Tuple[float, Optional[Relationship]]] = []
        if not allow_negative:
            candidates.append((0.0, None))
        for rel in predecessors[aid]:
            pred = schedule.activities[rel.predecessor_id]
            candidates.append((_forward_bound(pred, activity, rel), rel))
        for lower in constraint_lowers[aid]:
            candidates.append((lower, None))
        if not candidates:
            candidates = [(0.0, None)]

        max_value = max(value for value, _ in candidates)
        tight = [(value, rel) for value, rel in candidates if abs(value - max_value) <= driving_tolerance]
        tight.sort(key=lambda item: item[1].key if item[1] else ("", "", "", 0.0, ""))
        chosen_value, chosen_rel = tight[0]
        activity.es = chosen_value
        activity.ef = activity.es + activity.duration
        activity.driving_predecessor_id = chosen_rel.predecessor_id if chosen_rel else ""
        controlling_predecessor[aid] = chosen_rel.predecessor_id if chosen_rel else None
        controlling_relationship[aid] = chosen_rel

    project_finish = max((activity.ef for activity in schedule.activities.values()), default=0.0)
    required_finish = _required_finish_offset(schedule)
    backward_finish = required_finish if required_finish is not None else project_finish

    for aid in reversed(order):
        activity = schedule.activities[aid]
        bounds: List[float] = []
        for rel in successors[aid]:
            succ = schedule.activities[rel.successor_id]
            bounds.append(_latest_start_bound(activity, succ, rel))
        if not bounds:
            bounds.append(backward_finish - activity.duration)
        bounds.extend(constraint_uppers[aid])
        activity.ls = min(bounds)
        activity.lf = activity.ls + activity.duration
        activity.total_float = activity.ls - activity.es
        activity.critical = activity.total_float <= critical_threshold + driving_tolerance

    relationship_details: List[Dict] = []
    driving_predecessors: Dict[str, List[str]] = defaultdict(list)
    driving_relationships: List[Dict] = []
    for rel in active_relationships:
        slack = relationship_slack(schedule, rel)
        detail = {
            "id": rel.id,
            "predecessor_id": rel.predecessor_id,
            "successor_id": rel.successor_id,
            "rel_type": rel.rel_type,
            "lag": round(rel.lag, 6),
            "slack_days": round(slack, 6),
            "driving": abs(slack) <= driving_tolerance,
        }
        relationship_details.append(detail)
        if detail["driving"]:
            driving_predecessors[rel.successor_id].append(rel.predecessor_id)
            driving_relationships.append(detail)

    for aid, activity in schedule.activities.items():
        allowances: List[float] = []
        for rel in successors[aid]:
            allowances.append(relationship_slack(schedule, rel))
        terminal_allowance = backward_finish - activity.ef
        activity.free_float = min(allowances) if allowances else terminal_allowance

    # Deterministic primary controlling chain.
    longest_path: List[str] = []
    if schedule.activities:
        max_finish = max(activity.ef for activity in schedule.activities.values())
        end_id = min(aid for aid, activity in schedule.activities.items() if abs(activity.ef - max_finish) <= driving_tolerance)
        seen = set()
        current: Optional[str] = end_id
        while current is not None and current not in seen:
            longest_path.append(current)
            seen.add(current)
            current = controlling_predecessor.get(current)
        longest_path.reverse()
        for aid in longest_path:
            schedule.activities[aid].longest_path = True

    critical_paths = _enumerate_driving_paths(
        schedule,
        driving_predecessors,
        project_finish,
        driving_tolerance,
        max_critical_paths,
    )

    constraint_violations: List[Dict] = []
    for aid, uppers in constraint_uppers.items():
        if not uppers:
            continue
        activity = schedule.activities[aid]
        upper = min(uppers)
        if activity.es > upper + driving_tolerance:
            constraint_violations.append({
                "activity_id": aid,
                "type": "UPPER_CONSTRAINT_VIOLATION",
                "scheduled_start_offset": round(activity.es, 6),
                "latest_allowed_start_offset": round(upper, 6),
                "variance_days": round(activity.es - upper, 6),
            })

    if required_finish is not None and project_finish > required_finish + driving_tolerance:
        constraint_violations.append({
            "activity_id": "",
            "type": "PROJECT_REQUIRED_FINISH_VIOLATION",
            "forecast_finish_offset": round(project_finish, 6),
            "required_finish_offset": round(required_finish, 6),
            "variance_days": round(project_finish - required_finish, 6),
        })

    if schedule.data_date:
        forecast_activity_dates(schedule, schedule.data_date)

    return {
        "project_finish_offset_days": project_finish,
        "backward_finish_offset_days": backward_finish,
        "required_finish_offset_days": required_finish,
        "critical_activity_ids": sorted(aid for aid, activity in schedule.activities.items() if activity.critical),
        "activity_count": len(schedule.activities),
        "relationship_count": len(schedule.relationships),
        "active_relationship_count": len(active_relationships),
        "longest_path_activity_ids": longest_path,
        "critical_paths": critical_paths,
        "driving_relationships": driving_relationships,
        "relationship_details": relationship_details,
        "controlling_predecessor": controlling_predecessor,
        "constraint_details": constraint_details,
        "constraint_violations": constraint_violations,
        "scheduling_mode": mode,
    }


def _compute_path_drag(
    schedule: ProjectSchedule,
    base_finish: float,
    activity_ids: Sequence[str],
    critical_threshold: float,
    driving_tolerance: float,
    max_activities: int,
) -> Dict[str, float]:
    drags: Dict[str, float] = {}
    for aid in list(activity_ids)[:max_activities]:
        activity = schedule.activities[aid]
        if activity.duration <= driving_tolerance:
            drags[aid] = 0.0
            continue
        test = schedule.clone()
        test.activities[aid].remaining_duration = 0.0
        result = _calculate_core(test, critical_threshold, driving_tolerance, 1)
        drag = max(0.0, base_finish - float(result["project_finish_offset_days"]))
        schedule.activities[aid].path_drag = drag
        drags[aid] = drag
    return drags


def calculate_cpm(
    schedule: ProjectSchedule,
    critical_threshold: float = 0.01,
    *,
    driving_tolerance: float = 1e-7,
    max_critical_paths: int = 20,
    compute_path_drag: bool = False,
    max_path_drag_activities: int = 80,
) -> Dict:
    """Calculate deterministic generalized-precedence CPM.

    Supported logic: FS, SS, FF and SF with signed lag. The engine also applies
    common start/finish constraints when a Data Date and constraint date are
    available. It intentionally reports, rather than hides, unsupported P6
    scheduling nuances.
    """
    started = time.perf_counter()
    threshold = max(0.0, finite_float(critical_threshold, 0.01))
    tolerance = max(1e-12, finite_float(driving_tolerance, 1e-7))
    result = _calculate_core(schedule, threshold, tolerance, max(1, int(max_critical_paths)))
    if compute_path_drag and result["longest_path_activity_ids"]:
        result["path_drag_days"] = _compute_path_drag(
            schedule,
            float(result["project_finish_offset_days"]),
            result["longest_path_activity_ids"],
            threshold,
            tolerance,
            max(1, int(max_path_drag_activities)),
        )
    else:
        result["path_drag_days"] = {
            aid: schedule.activities[aid].path_drag for aid in result["longest_path_activity_ids"]
        }
    result["calculation_runtime_ms"] = round((time.perf_counter() - started) * 1000.0, 3)
    return result


def topological_order(schedule: ProjectSchedule) -> List[str]:
    mode = _normalized_mode(schedule)
    return _topological_order(sorted(schedule.activities), _active_relationships(schedule, mode))
