from __future__ import annotations

from datetime import date, datetime, timezone
import hashlib
import json
import math
import re
from typing import Any

_CONTROL_RE = re.compile(r"[\x00-\x08\x0B\x0C\x0E-\x1F]")
_UNSAFE_FILENAME_RE = re.compile(r"[^A-Za-z0-9._-]+")


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def finite_float(value: Any, default: float | None = None, *, field: str = "value") -> float:
    try:
        result = float(value)
    except (TypeError, ValueError):
        if default is not None:
            return float(default)
        raise ValueError(f"{field} must be numeric") from None
    if not math.isfinite(result):
        if default is not None:
            return float(default)
        raise ValueError(f"{field} must be finite")
    return result


def clean_text(value: Any, max_length: int | None = None) -> str:
    text = _CONTROL_RE.sub("", str(value or "")).strip()
    if max_length is not None:
        text = text[:max_length]
    return text


def safe_filename(value: Any, fallback: str = "PROJECT", max_length: int = 120) -> str:
    text = clean_text(value).replace(" ", "_")
    text = _UNSAFE_FILENAME_RE.sub("_", text).strip("._-")
    return (text or fallback)[:max_length]


def spreadsheet_safe(value: Any) -> Any:
    """Prevent formula execution when untrusted schedule text is written to Excel."""
    if isinstance(value, str) and value[:1] in {"=", "+", "-", "@"}:
        return "'" + value
    return value


def _json_default(value: Any):
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, set):
        return sorted(value)
    if hasattr(value, "to_dict"):
        return value.to_dict()
    raise TypeError(f"Cannot serialize {type(value).__name__}")


def canonical_json(value: Any) -> str:
    return json.dumps(
        value,
        sort_keys=True,
        ensure_ascii=False,
        separators=(",", ":"),
        default=_json_default,
        allow_nan=False,
    )


def sha256_hex(value: bytes | str) -> str:
    raw = value.encode("utf-8") if isinstance(value, str) else value
    return hashlib.sha256(raw).hexdigest()


def canonical_sha256(value: Any) -> str:
    return sha256_hex(canonical_json(value))
