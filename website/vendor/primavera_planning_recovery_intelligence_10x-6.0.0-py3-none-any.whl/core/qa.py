from __future__ import annotations

from collections import Counter, defaultdict
import math
from typing import Any, Dict, List

from .cpm import topological_order
from .errors import ScheduleCycleError
from .models import ProjectSchedule


# This module deliberately calls the metrics "DCMA-like screening". A complete
# contractual DCMA 14-point assessment requires fields and policy choices that
# may not be present in a core XER import.


def _pct(count: int, total: int) -> float:
    return round(100.0 * count / total, 3) if total else 0.0


def _grade(score: float) -> str:
    if score >= 90:
        return "A"
    if score >= 80:
        return "B"
    if score >= 70:
        return "C"
    if score >= 60:
        return "D"
    return "F"


def schedule_quality(
    schedule: ProjectSchedule,
    long_duration: float = 20.0,
    long_lag: float = 5.0,
    high_float: float = 44.0,
) -> Dict[str, Any]:
    issues: List[Dict[str, Any]] = []

    def add(
        severity: str,
        issue_type: str,
        detail: str,
        *,
        activity_id: str = "",
        category: str = "GENERAL",
        recommendation: str = "",
    ) -> None:
        issues.append({
            "severity": severity,
            "type": issue_type,
            "activity_id": activity_id,
            "detail": detail,
            "category": category,
            "recommendation": recommendation,
        })

    ids = set(schedule.activities)
    incoming = {aid: 0 for aid in ids}
    outgoing = {aid: 0 for aid in ids}
    rel_seen = set()
    pair_seen: Dict[tuple[str, str], int] = defaultdict(int)
    leads = long_lags = invalid_refs = duplicate_rels = self_rels = 0
    non_fs = 0

    if not schedule.activities:
        add("ERROR", "NO_ACTIVITIES", "The schedule contains no activities.", category="STRUCTURE")
    if not schedule.data_date:
        add(
            "WARN", "DATA_DATE_MISSING", "No Data Date was available; forecast dates and constraints are less reliable.",
            category="DATES", recommendation="Set and verify the current schedule Data Date.",
        )

    for rel in schedule.relationships:
        rel_key = (rel.predecessor_id, rel.successor_id, rel.rel_type, round(float(rel.lag), 9))
        if rel_key in rel_seen:
            duplicate_rels += 1
            add(
                "WARN", "DUPLICATE_RELATIONSHIP", f"{rel.predecessor_id} {rel.rel_type} {rel.lag:+.2f}d",
                activity_id=rel.successor_id, category="LOGIC",
                recommendation="Remove duplicate logic or document why parallel links are required.",
            )
        rel_seen.add(rel_key)
        pair_seen[(rel.predecessor_id, rel.successor_id)] += 1

        if rel.predecessor_id == rel.successor_id:
            self_rels += 1
            add("ERROR", "SELF_RELATIONSHIP", "Activity is linked to itself.", activity_id=rel.predecessor_id, category="LOGIC")
            continue
        if rel.predecessor_id not in ids or rel.successor_id not in ids:
            invalid_refs += 1
            add(
                "ERROR", "MISSING_ACTIVITY_REFERENCE", f"{rel.predecessor_id} -> {rel.successor_id}",
                activity_id=rel.successor_id if rel.successor_id in ids else "", category="LOGIC",
                recommendation="Repair or remove the dangling relationship before schedule use.",
            )
            continue

        incoming[rel.successor_id] += 1
        outgoing[rel.predecessor_id] += 1
        if rel.rel_type != "FS":
            non_fs += 1
        if rel.lag < 0:
            leads += 1
            add(
                "WARN", "NEGATIVE_LAG", f"{rel.rel_type} lag {rel.lag:.2f}d",
                activity_id=rel.successor_id, category="LOGIC",
                recommendation="Replace leads with explicit, auditable activities where practical.",
            )
        if abs(rel.lag) > long_lag:
            long_lags += 1
            add(
                "WARN", "LONG_LAG", f"{rel.rel_type} lag {rel.lag:.2f}d",
                activity_id=rel.successor_id, category="LOGIC",
                recommendation="Model significant waiting periods as activities when possible.",
            )

    for pair, count in sorted(pair_seen.items()):
        if count > 1:
            add(
                "INFO", "PARALLEL_RELATIONSHIPS", f"{count} relationships exist for {pair[0]} -> {pair[1]}.",
                activity_id=pair[1], category="LOGIC",
            )

    try:
        topological_order(schedule)
    except ScheduleCycleError as exc:
        add("ERROR", "CYCLE", str(exc), category="LOGIC", recommendation="Break the directed cycle before CPM calculation.")

    open_starts = open_finishes = 0
    long_durations = negative_float = high_float_count = hard_constraints = 0
    invalid_dates = missing_calendars = zero_non_milestones = 0
    out_of_sequence = 0

    for aid, activity in sorted(schedule.activities.items()):
        if activity.calendar_id not in schedule.calendars:
            missing_calendars += 1
            add(
                "ERROR", "MISSING_CALENDAR", f"Calendar {activity.calendar_id!r} is not defined.",
                activity_id=aid, category="CALENDAR",
            )

        if activity.original_duration < -1e-9 or activity.remaining_duration < -1e-9:
            add(
                "ERROR", "NEGATIVE_DURATION", f"OD={activity.original_duration:.2f}, RD={activity.remaining_duration:.2f}",
                activity_id=aid, category="DURATION",
            )
        if activity.original_duration >= 0 and activity.remaining_duration > activity.original_duration + 1e-6:
            add(
                "WARN", "REMAINING_EXCEEDS_ORIGINAL", f"RD {activity.remaining_duration:.2f}d > OD {activity.original_duration:.2f}d",
                activity_id=aid, category="DURATION",
            )
        if activity.duration > long_duration:
            long_durations += 1
            add(
                "WARN", "LONG_DURATION", f"{activity.duration:.2f}d",
                activity_id=aid, category="DURATION",
                recommendation="Break long work packages into measurable, logic-linked activities.",
            )
        if activity.is_milestone and activity.remaining_duration > 1e-9:
            add(
                "WARN", "MILESTONE_WITH_DURATION", f"Milestone has {activity.remaining_duration:.2f}d remaining duration.",
                activity_id=aid, category="DURATION",
            )
        if not activity.is_milestone and not activity.is_complete and abs(activity.remaining_duration) <= 1e-9:
            zero_non_milestones += 1
            add(
                "WARN", "ZERO_DURATION_NON_MILESTONE", activity.name or aid,
                activity_id=aid, category="DURATION",
            )

        if not activity.is_complete:
            if incoming[aid] == 0 and not activity.is_milestone:
                open_starts += 1
                add(
                    "INFO", "OPEN_START", activity.name or aid, activity_id=aid, category="LOGIC",
                    recommendation="Confirm this is an intentional network start.",
                )
            if outgoing[aid] == 0 and not activity.is_milestone:
                open_finishes += 1
                add(
                    "INFO", "OPEN_FINISH", activity.name or aid, activity_id=aid, category="LOGIC",
                    recommendation="Confirm this is an intentional network finish.",
                )

        if activity.total_float < -0.01:
            negative_float += 1
            add("WARN", "NEGATIVE_FLOAT", f"{activity.total_float:.2f}d", activity_id=aid, category="FLOAT")
        if activity.total_float > high_float:
            high_float_count += 1
            add("INFO", "HIGH_FLOAT", f"{activity.total_float:.2f}d", activity_id=aid, category="FLOAT")

        if activity.actual_start and schedule.data_date and activity.actual_start > schedule.data_date:
            invalid_dates += 1
            add("ERROR", "ACTUAL_AFTER_DATA_DATE", str(activity.actual_start), activity_id=aid, category="DATES")
        if activity.actual_finish and schedule.data_date and activity.actual_finish > schedule.data_date:
            invalid_dates += 1
            add("ERROR", "ACTUAL_AFTER_DATA_DATE", str(activity.actual_finish), activity_id=aid, category="DATES")
        if activity.actual_start and activity.actual_finish and activity.actual_finish < activity.actual_start:
            invalid_dates += 1
            add("ERROR", "ACTUAL_DATE_ORDER", "Actual Finish is before Actual Start.", activity_id=aid, category="DATES")
        if activity.planned_start and activity.planned_finish and activity.planned_finish < activity.planned_start:
            invalid_dates += 1
            add("ERROR", "PLANNED_DATE_ORDER", "Planned Finish is before Planned Start.", activity_id=aid, category="DATES")
        if activity.suspend_date and activity.resume_date and activity.resume_date < activity.suspend_date:
            invalid_dates += 1
            add("ERROR", "SUSPEND_RESUME_ORDER", "Resume date is before suspend date.", activity_id=aid, category="DATES")

        if activity.is_complete:
            if not activity.actual_finish:
                add("WARN", "COMPLETE_WITHOUT_AF", activity.name or aid, activity_id=aid, category="PROGRESS")
            if not activity.actual_start:
                add("WARN", "COMPLETE_WITHOUT_AS", activity.name or aid, activity_id=aid, category="PROGRESS")
            if activity.remaining_duration > 1e-9:
                add(
                    "WARN", "COMPLETE_WITH_REMAINING", f"Completed activity has {activity.remaining_duration:.2f}d RD.",
                    activity_id=aid, category="PROGRESS",
                )
        elif activity.is_in_progress:
            if not activity.actual_start:
                add("WARN", "IN_PROGRESS_WITHOUT_AS", activity.name or aid, activity_id=aid, category="PROGRESS")
            if activity.remaining_duration <= 1e-9:
                add("WARN", "IN_PROGRESS_WITHOUT_REMAINING", activity.name or aid, activity_id=aid, category="PROGRESS")
        else:
            if activity.actual_start or activity.actual_finish:
                add("ERROR", "NOT_STARTED_WITH_ACTUALS", activity.name or aid, activity_id=aid, category="PROGRESS")

        if activity.percent_complete < -1e-9 or activity.percent_complete > 100 + 1e-9:
            add("ERROR", "INVALID_PERCENT_COMPLETE", str(activity.percent_complete), activity_id=aid, category="PROGRESS")
        if activity.is_complete and activity.percent_complete not in {0.0, 100.0}:
            add("INFO", "COMPLETE_PERCENT_INCONSISTENT", str(activity.percent_complete), activity_id=aid, category="PROGRESS")

        for constraint_type, constraint_date in (
            (activity.constraint_type, activity.constraint_date),
            (activity.constraint_type2, activity.constraint_date2),
        ):
            if constraint_type:
                hard_constraints += 1
                if constraint_date:
                    add(
                        "INFO", "CONSTRAINT_PRESENT", f"{constraint_type} {constraint_date}",
                        activity_id=aid, category="CONSTRAINTS",
                    )
                else:
                    add(
                        "WARN", "CONSTRAINT_WITHOUT_DATE", constraint_type,
                        activity_id=aid, category="CONSTRAINTS",
                    )
        if activity.expected_finish:
            add("INFO", "EXPECTED_FINISH_PRESENT", str(activity.expected_finish), activity_id=aid, category="DATES")

    for rel in schedule.relationships:
        if rel.predecessor_id not in schedule.activities or rel.successor_id not in schedule.activities:
            continue
        pred = schedule.activities[rel.predecessor_id]
        succ = schedule.activities[rel.successor_id]
        if succ.is_in_progress and not pred.is_complete and rel.rel_type == "FS":
            out_of_sequence += 1
            add(
                "WARN", "OUT_OF_SEQUENCE_PROGRESS",
                f"Successor is in progress while FS predecessor {pred.id} is incomplete.",
                activity_id=succ.id, category="PROGRESS",
                recommendation="Confirm retained-logic/progress-override policy and remaining-work treatment.",
            )

    activity_count = len(schedule.activities)
    relationship_count = len(schedule.relationships)
    incomplete_count = sum(1 for activity in schedule.activities.values() if not activity.is_complete)
    missing_logic_ends = open_starts + open_finishes
    metrics = {
        "activity_count": activity_count,
        "incomplete_activity_count": incomplete_count,
        "relationship_count": relationship_count,
        "relationship_density": round(relationship_count / activity_count, 3) if activity_count else 0.0,
        "open_start_count": open_starts,
        "open_finish_count": open_finishes,
        "missing_logic_end_pct": _pct(missing_logic_ends, max(1, incomplete_count * 2)),
        "lead_count": leads,
        "lead_pct": _pct(leads, relationship_count),
        "long_lag_count": long_lags,
        "long_lag_pct": _pct(long_lags, relationship_count),
        "non_fs_count": non_fs,
        "non_fs_pct": _pct(non_fs, relationship_count),
        "duplicate_relationship_count": duplicate_rels,
        "invalid_reference_count": invalid_refs,
        "self_relationship_count": self_rels,
        "long_duration_count": long_durations,
        "long_duration_pct": _pct(long_durations, incomplete_count),
        "hard_constraint_count": hard_constraints,
        "hard_constraint_pct": _pct(hard_constraints, activity_count),
        "high_float_count": high_float_count,
        "high_float_pct": _pct(high_float_count, activity_count),
        "negative_float_count": negative_float,
        "invalid_date_count": invalid_dates,
        "missing_calendar_count": missing_calendars,
        "zero_duration_non_milestone_count": zero_non_milestones,
        "out_of_sequence_count": out_of_sequence,
    }

    def screening(name: str, value: float, pass_limit: float, warn_limit: float, lower_is_better: bool = True):
        if lower_is_better:
            status = "PASS" if value <= pass_limit else ("WARN" if value <= warn_limit else "FAIL")
        else:
            status = "PASS" if value >= pass_limit else ("WARN" if value >= warn_limit else "FAIL")
        return {"metric": name, "value": value, "status": status, "pass_limit": pass_limit, "warn_limit": warn_limit}

    screening_metrics = [
        screening("Missing logic ends %", metrics["missing_logic_end_pct"], 5.0, 10.0),
        screening("Leads %", metrics["lead_pct"], 0.0, 1.0),
        screening("Long lags %", metrics["long_lag_pct"], 5.0, 10.0),
        screening("Long durations %", metrics["long_duration_pct"], 5.0, 10.0),
        screening("Hard constraints %", metrics["hard_constraint_pct"], 5.0, 10.0),
        screening("High float %", metrics["high_float_pct"], 5.0, 10.0),
        screening("Negative float count", float(metrics["negative_float_count"]), 0.0, 1.0),
        screening("Invalid date count", float(metrics["invalid_date_count"]), 0.0, 1.0),
        screening("Invalid relationship references", float(metrics["invalid_reference_count"]), 0.0, 1.0),
    ]

    severity_counts = Counter(issue["severity"] for issue in issues)
    errors = severity_counts["ERROR"]
    warnings = severity_counts["WARN"]
    infos = severity_counts["INFO"]
    penalty = min(70.0, errors * 9.0) + min(27.0, warnings * 2.25) + min(3.0, infos * 0.15)
    score = round(max(0.0, 100.0 - penalty), 1)
    category_counts = Counter(issue["category"] for issue in issues)
    type_counts = Counter(issue["type"] for issue in issues)

    issues.sort(key=lambda issue: (
        {"ERROR": 0, "WARN": 1, "INFO": 2}.get(issue["severity"], 3),
        issue.get("category", ""), issue.get("activity_id", ""), issue.get("type", ""),
    ))

    return {
        "score": score,
        "grade": _grade(score),
        "errors": errors,
        "warnings": warnings,
        "infos": infos,
        "issues": issues,
        "issue_type_counts": dict(sorted(type_counts.items())),
        "category_counts": dict(sorted(category_counts.items())),
        "metrics": metrics,
        "dcma_like_screening": screening_metrics,
        "screening_disclaimer": (
            "Screening indicators only; this is not a formal DCMA 14-point acceptance determination "
            "and does not replace native P6 checks or contract-specific criteria."
        ),
    }
