from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import date, datetime, timezone
import copy
from typing import Any, Dict, Iterable, List, Optional

from .errors import ScheduleDataError
from .utils import clean_text, finite_float


_COMPLETE_TOKENS = {"COMPLETE", "COMPLETED", "TK_COMPLETE", "FINISHED"}
_IN_PROGRESS_TOKENS = {"IN_PROGRESS", "IN PROGRESS", "ACTIVE", "TK_ACTIVE", "PROGRESS"}
_VALID_REL_TYPES = {"FS", "SS", "FF", "SF"}


def parse_dt(value: Any) -> Optional[datetime]:
    """Parse common JSON, Excel-like and Primavera date strings.

    Timezone-aware values are converted to UTC and stored as naive UTC so the
    rest of the local scheduling engine remains deterministic.
    """
    if value in (None, "", "None", "null", "NULL"):
        return None
    if isinstance(value, datetime):
        dt = value
    elif isinstance(value, date):
        dt = datetime.combine(value, datetime.min.time())
    else:
        text = str(value).strip()
        formats = (
            "%Y-%m-%d %H:%M:%S.%f",
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%d %H:%M",
            "%Y-%m-%d",
            "%Y/%m/%d %H:%M:%S",
            "%Y/%m/%d",
            "%d-%b-%y %H:%M",
            "%d-%b-%Y %H:%M",
            "%d-%b-%y",
            "%d-%b-%Y",
            "%m/%d/%Y %H:%M:%S",
            "%m/%d/%Y %H:%M",
            "%m/%d/%Y",
            "%d/%m/%Y %H:%M:%S",
            "%d/%m/%Y %H:%M",
            "%d/%m/%Y",
        )
        dt = None
        for fmt in formats:
            try:
                dt = datetime.strptime(text, fmt)
                break
            except ValueError:
                continue
        if dt is None:
            try:
                dt = datetime.fromisoformat(text.replace("Z", "+00:00"))
            except (TypeError, ValueError):
                return None
    if dt.tzinfo is not None:
        dt = dt.astimezone(timezone.utc).replace(tzinfo=None)
    return dt


def normalize_status(value: Any) -> str:
    text = clean_text(value or "NOT_STARTED").upper().replace("-", "_")
    if text in _COMPLETE_TOKENS or "COMP" in text:
        return "COMPLETE"
    if text in _IN_PROGRESS_TOKENS or "ACT" in text or "PROGRESS" in text:
        return "IN_PROGRESS"
    return "NOT_STARTED"


def normalize_rel_type(value: Any) -> str:
    text = clean_text(value or "FS").upper().replace("PR_", "")
    return text if text in _VALID_REL_TYPES else "FS"


def normalize_activity_type(value: Any) -> str:
    return clean_text(value or "TASK").upper().replace(" ", "_")


def _dt_or_none(value: Any) -> Optional[datetime]:
    return value if isinstance(value, datetime) else parse_dt(value)


@dataclass
class Activity:
    id: str
    name: str = ""
    wbs_id: str = ""
    status: str = "NOT_STARTED"
    activity_type: str = "TASK"
    calendar_id: str = "DEFAULT"
    original_duration: float = 0.0
    remaining_duration: float = 0.0
    actual_start: Optional[datetime] = None
    actual_finish: Optional[datetime] = None
    planned_start: Optional[datetime] = None
    planned_finish: Optional[datetime] = None
    expected_finish: Optional[datetime] = None
    suspend_date: Optional[datetime] = None
    resume_date: Optional[datetime] = None
    constraint_type: str = ""
    constraint_date: Optional[datetime] = None
    constraint_type2: str = ""
    constraint_date2: Optional[datetime] = None
    percent_complete: float = 0.0
    primary_resource_id: str = ""

    # Calculated fields in project working-day offsets from the Data Date.
    es: float = 0.0
    ef: float = 0.0
    ls: float = 0.0
    lf: float = 0.0
    total_float: float = 0.0
    free_float: float = 0.0
    critical: bool = False
    longest_path: bool = False
    path_drag: float = 0.0
    driving_predecessor_id: str = ""
    forecast_start: Optional[datetime] = None
    forecast_finish: Optional[datetime] = None

    source: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        self.id = clean_text(self.id, 255)
        if not self.id:
            raise ScheduleDataError("Activity ID cannot be empty")
        self.name = clean_text(self.name, 4000)
        self.wbs_id = clean_text(self.wbs_id, 255)
        self.status = normalize_status(self.status)
        self.activity_type = normalize_activity_type(self.activity_type)
        self.calendar_id = clean_text(self.calendar_id or "DEFAULT", 255) or "DEFAULT"
        self.original_duration = finite_float(self.original_duration, 0.0, field="original_duration")
        self.remaining_duration = finite_float(self.remaining_duration, 0.0, field="remaining_duration")
        self.percent_complete = finite_float(self.percent_complete, 0.0, field="percent_complete")
        self.actual_start = _dt_or_none(self.actual_start)
        self.actual_finish = _dt_or_none(self.actual_finish)
        self.planned_start = _dt_or_none(self.planned_start)
        self.planned_finish = _dt_or_none(self.planned_finish)
        self.expected_finish = _dt_or_none(self.expected_finish)
        self.suspend_date = _dt_or_none(self.suspend_date)
        self.resume_date = _dt_or_none(self.resume_date)
        self.constraint_date = _dt_or_none(self.constraint_date)
        self.constraint_date2 = _dt_or_none(self.constraint_date2)
        self.constraint_type = clean_text(self.constraint_type, 100).upper()
        self.constraint_type2 = clean_text(self.constraint_type2, 100).upper()
        self.primary_resource_id = clean_text(self.primary_resource_id, 255)
        self.source = dict(self.source or {})

    @property
    def is_complete(self) -> bool:
        return self.status == "COMPLETE"

    @property
    def is_in_progress(self) -> bool:
        return self.status == "IN_PROGRESS"

    @property
    def is_milestone(self) -> bool:
        return "MILESTONE" in self.activity_type or self.activity_type in {"START_MILESTONE", "FINISH_MILESTONE"}

    @property
    def duration(self) -> float:
        if self.is_complete or self.is_milestone:
            return 0.0
        return max(0.0, float(self.remaining_duration))


@dataclass
class Relationship:
    predecessor_id: str
    successor_id: str
    rel_type: str = "FS"
    lag: float = 0.0
    id: str = ""
    lag_calendar_id: str = ""
    source: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        self.predecessor_id = clean_text(self.predecessor_id, 255)
        self.successor_id = clean_text(self.successor_id, 255)
        self.rel_type = normalize_rel_type(self.rel_type)
        self.lag = finite_float(self.lag, 0.0, field="relationship lag")
        self.id = clean_text(self.id, 255)
        self.lag_calendar_id = clean_text(self.lag_calendar_id, 255)
        self.source = dict(self.source or {})

    @property
    def key(self) -> tuple[str, str, str, float, str]:
        return (
            self.predecessor_id,
            self.successor_id,
            self.rel_type,
            round(float(self.lag), 9),
            self.id,
        )


@dataclass
class Calendar:
    id: str
    name: str = "Default 5D"
    working_weekdays: List[int] = field(default_factory=lambda: [0, 1, 2, 3, 4])
    hours_per_day: float = 8.0
    hours_by_weekday: Dict[int, float] = field(default_factory=dict)
    non_working_dates: List[str] = field(default_factory=list)
    working_dates: List[str] = field(default_factory=list)
    source: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        self.id = clean_text(self.id or "DEFAULT", 255) or "DEFAULT"
        self.name = clean_text(self.name or self.id, 1000)
        self.hours_per_day = finite_float(self.hours_per_day, 8.0, field="hours_per_day")
        if self.hours_per_day <= 0:
            raise ScheduleDataError(f"Calendar {self.id} has non-positive hours_per_day")
        weekdays = []
        for value in self.working_weekdays or []:
            try:
                day = int(value)
            except (TypeError, ValueError):
                continue
            if 0 <= day <= 6 and day not in weekdays:
                weekdays.append(day)
        self.working_weekdays = sorted(weekdays) or [0, 1, 2, 3, 4]
        converted: Dict[int, float] = {}
        for key, value in (self.hours_by_weekday or {}).items():
            try:
                day = int(key)
                hours = finite_float(value, self.hours_per_day)
            except (TypeError, ValueError):
                continue
            if 0 <= day <= 6 and hours >= 0:
                converted[day] = hours
        self.hours_by_weekday = converted
        self.non_working_dates = sorted({str(x)[:10] for x in (self.non_working_dates or []) if str(x).strip()})
        self.working_dates = sorted({str(x)[:10] for x in (self.working_dates or []) if str(x).strip()})
        self.source = dict(self.source or {})

    def weekday_hours(self, weekday: int) -> float:
        if weekday not in self.working_weekdays:
            return 0.0
        return max(0.0, float(self.hours_by_weekday.get(weekday, self.hours_per_day)))


@dataclass
class Change:
    kind: str
    activity_id: str
    field: str
    before: Any
    after: Any
    reason: str
    risk: str = "MEDIUM"
    requires_approval: bool = True
    calculated_recovery_days: float = 0.0
    predecessor_id: str = ""
    successor_id: str = ""
    relationship_id: str = ""
    scenario_id: str = ""
    evidence_ref: str = ""
    approved_by: str = ""
    approved_at: str = ""
    provenance_hash: str = ""

    def __post_init__(self):
        self.kind = clean_text(self.kind, 100).upper()
        self.activity_id = clean_text(self.activity_id, 255)
        self.field = clean_text(self.field, 100)
        self.reason = clean_text(self.reason, 8000)
        self.risk = clean_text(self.risk or "MEDIUM", 20).upper()
        self.calculated_recovery_days = finite_float(self.calculated_recovery_days, 0.0)
        self.predecessor_id = clean_text(self.predecessor_id, 255)
        self.successor_id = clean_text(self.successor_id, 255)
        self.relationship_id = clean_text(self.relationship_id, 255)
        self.scenario_id = clean_text(self.scenario_id, 255)
        self.evidence_ref = clean_text(self.evidence_ref, 2000)
        self.approved_by = clean_text(self.approved_by, 1000)
        self.approved_at = clean_text(self.approved_at, 100)
        self.provenance_hash = clean_text(self.provenance_hash, 128)


@dataclass
class ProjectSchedule:
    project_id: str = "PROJECT"
    project_name: str = "Imported Schedule"
    data_date: Optional[datetime] = None
    activities: Dict[str, Activity] = field(default_factory=dict)
    relationships: List[Relationship] = field(default_factory=list)
    calendars: Dict[str, Calendar] = field(default_factory=dict)
    wbs: Dict[str, str] = field(default_factory=dict)
    raw_tables: Dict[str, List[Dict[str, Any]]] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    changes: List[Change] = field(default_factory=list)

    def __post_init__(self):
        self.project_id = clean_text(self.project_id or "PROJECT", 255) or "PROJECT"
        self.project_name = clean_text(self.project_name or self.project_id, 4000)
        self.data_date = _dt_or_none(self.data_date)
        self.metadata = dict(self.metadata or {})
        self.raw_tables = {str(k): [dict(row) for row in (rows or [])] for k, rows in (self.raw_tables or {}).items()}
        self.wbs = {str(k): clean_text(v, 4000) for k, v in (self.wbs or {}).items()}
        if not self.calendars:
            self.calendars["DEFAULT"] = Calendar(id="DEFAULT")

    def clone(self) -> "ProjectSchedule":
        return copy.deepcopy(self)

    def get_calendar(self, calendar_id: str | None = None) -> Calendar:
        if calendar_id and calendar_id in self.calendars:
            return self.calendars[calendar_id]
        default_id = str(self.metadata.get("default_calendar_id") or "DEFAULT")
        if default_id in self.calendars:
            return self.calendars[default_id]
        if self.calendars:
            return next(iter(self.calendars.values()))
        cal = Calendar(id="DEFAULT")
        self.calendars[cal.id] = cal
        return cal

    def to_dict(self, *, include_raw_tables: bool = False, include_calculated: bool = True) -> Dict[str, Any]:
        def cv(value: Any):
            if isinstance(value, datetime):
                return value.isoformat()
            if isinstance(value, dict):
                return {str(k): cv(v) for k, v in value.items()}
            if isinstance(value, (list, tuple)):
                return [cv(v) for v in value]
            return value

        activity_fields = set(Activity.__dataclass_fields__)
        if not include_calculated:
            activity_fields -= {
                "es", "ef", "ls", "lf", "total_float", "free_float", "critical",
                "longest_path", "path_drag", "driving_predecessor_id", "forecast_start", "forecast_finish",
            }
        activities = {}
        for aid, activity in self.activities.items():
            row = asdict(activity)
            activities[aid] = {k: cv(v) for k, v in row.items() if k in activity_fields}

        result = {
            "project_id": self.project_id,
            "project_name": self.project_name,
            "data_date": cv(self.data_date),
            "activities": activities,
            "relationships": [cv(asdict(r)) for r in self.relationships],
            "calendars": {cid: cv(asdict(cal)) for cid, cal in self.calendars.items()},
            "wbs": cv(self.wbs),
            "metadata": cv(self.metadata),
            "changes": [cv(asdict(change)) for change in self.changes],
        }
        if include_raw_tables:
            result["raw_tables"] = cv(self.raw_tables)
        return result

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> "ProjectSchedule":
        if not isinstance(data, dict):
            raise ScheduleDataError("Schedule JSON root must be an object")
        schedule = ProjectSchedule(
            project_id=str(data.get("project_id", "PROJECT")),
            project_name=str(data.get("project_name", "Imported Schedule")),
            data_date=parse_dt(data.get("data_date")),
            metadata=data.get("metadata", {}) or {},
            raw_tables=data.get("raw_tables", {}) or {},
            wbs=data.get("wbs", {}) or {},
            calendars={},
        )

        raw_calendars = data.get("calendars") or {}
        calendar_items: Iterable[tuple[str, Dict[str, Any]]]
        if isinstance(raw_calendars, list):
            calendar_items = [(str(c.get("id", f"CAL-{i+1}")), c) for i, c in enumerate(raw_calendars)]
        else:
            calendar_items = [(str(cid), c) for cid, c in raw_calendars.items()]
        for cid, c in calendar_items:
            c = c or {}
            calendar = Calendar(
                id=str(c.get("id", cid)),
                name=c.get("name", "Calendar"),
                working_weekdays=list(c.get("working_weekdays", [0, 1, 2, 3, 4])),
                hours_per_day=c.get("hours_per_day", 8.0),
                hours_by_weekday=c.get("hours_by_weekday", {}) or {},
                non_working_dates=c.get("non_working_dates", []) or [],
                working_dates=c.get("working_dates", []) or [],
                source=c.get("source", {}) or {},
            )
            schedule.calendars[calendar.id] = calendar
        if not schedule.calendars:
            schedule.calendars["DEFAULT"] = Calendar(id="DEFAULT")

        raw_activities = data.get("activities") or {}
        if isinstance(raw_activities, list):
            activity_items = [(str(a.get("id", "")), a) for a in raw_activities]
        elif isinstance(raw_activities, dict):
            activity_items = [(str(aid), a) for aid, a in raw_activities.items()]
        else:
            raise ScheduleDataError("activities must be an object or array")

        for key, row in activity_items:
            row = row or {}
            aid = str(row.get("id", key)).strip()
            if aid in schedule.activities:
                raise ScheduleDataError(f"Duplicate activity ID: {aid}")
            activity = Activity(
                id=aid,
                name=row.get("name", ""),
                wbs_id=str(row.get("wbs_id", "")),
                status=row.get("status", "NOT_STARTED"),
                activity_type=row.get("activity_type", "TASK"),
                calendar_id=str(row.get("calendar_id", "DEFAULT")),
                original_duration=row.get("original_duration", 0),
                remaining_duration=row.get("remaining_duration", 0),
                actual_start=parse_dt(row.get("actual_start")),
                actual_finish=parse_dt(row.get("actual_finish")),
                planned_start=parse_dt(row.get("planned_start")),
                planned_finish=parse_dt(row.get("planned_finish")),
                expected_finish=parse_dt(row.get("expected_finish")),
                suspend_date=parse_dt(row.get("suspend_date")),
                resume_date=parse_dt(row.get("resume_date")),
                constraint_type=row.get("constraint_type", "") or "",
                constraint_date=parse_dt(row.get("constraint_date")),
                constraint_type2=row.get("constraint_type2", "") or "",
                constraint_date2=parse_dt(row.get("constraint_date2")),
                percent_complete=row.get("percent_complete", 0),
                primary_resource_id=row.get("primary_resource_id", ""),
                source=row.get("source", {}) or {},
            )
            for calc_name in (
                "es", "ef", "ls", "lf", "total_float", "free_float", "path_drag",
            ):
                if calc_name in row:
                    setattr(activity, calc_name, finite_float(row.get(calc_name), 0.0))
            for flag_name in ("critical", "longest_path"):
                if flag_name in row:
                    setattr(activity, flag_name, bool(row.get(flag_name)))
            activity.driving_predecessor_id = clean_text(row.get("driving_predecessor_id", ""), 255)
            activity.forecast_start = parse_dt(row.get("forecast_start"))
            activity.forecast_finish = parse_dt(row.get("forecast_finish"))
            schedule.activities[aid] = activity

        raw_relationships = data.get("relationships", []) or []
        if not isinstance(raw_relationships, list):
            raise ScheduleDataError("relationships must be an array")
        for index, row in enumerate(raw_relationships, start=1):
            if not isinstance(row, dict):
                raise ScheduleDataError(f"Relationship {index} must be an object")
            try:
                pred = str(row["predecessor_id"])
                succ = str(row["successor_id"])
            except KeyError as exc:
                raise ScheduleDataError(f"Relationship {index} missing {exc.args[0]}") from None
            schedule.relationships.append(Relationship(
                predecessor_id=pred,
                successor_id=succ,
                rel_type=row.get("rel_type", "FS"),
                lag=row.get("lag", 0),
                id=row.get("id", ""),
                lag_calendar_id=row.get("lag_calendar_id", ""),
                source=row.get("source", {}) or {},
            ))

        for row in data.get("changes", []) or []:
            if not isinstance(row, dict):
                continue
            allowed = {k: row.get(k) for k in Change.__dataclass_fields__ if k in row}
            required = {"kind", "activity_id", "field", "before", "after", "reason"}
            if required.issubset(allowed):
                schedule.changes.append(Change(**allowed))
        return schedule
