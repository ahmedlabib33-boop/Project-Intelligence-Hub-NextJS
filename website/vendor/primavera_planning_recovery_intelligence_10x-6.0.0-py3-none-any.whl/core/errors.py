"""Domain-specific exceptions used across the scheduling engine."""


class ScheduleError(Exception):
    """Base class for deterministic schedule-engine failures."""


class ScheduleDataError(ScheduleError, ValueError):
    """Raised when schedule input is structurally or numerically invalid."""


class ScheduleCycleError(ScheduleDataError):
    """Raised when the active logic network contains a directed cycle."""


class ScenarioValidationError(ScheduleError, ValueError):
    """Raised when a proposed recovery scenario is unsafe or inconsistent."""


class InvalidDecisionError(ScheduleError, ValueError):
    """Raised when an interactive recovery decision is invalid for its stage."""


class XERValidationError(ScheduleError, ValueError):
    """Raised when an XER cannot be parsed or safely round-tripped."""
