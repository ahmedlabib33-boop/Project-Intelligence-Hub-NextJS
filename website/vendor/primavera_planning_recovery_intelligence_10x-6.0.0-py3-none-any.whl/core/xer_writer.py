from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence, Tuple

from .integrity import validate_history_unchanged
from .models import ProjectSchedule
from .utils import sha256_hex
from .xer import parse_xer_text


def _fmt_num(value: Any) -> str:
    try:
        number = float(value)
        if abs(number - round(number)) < 1e-9:
            return str(int(round(number)))
        return f"{number:.9f}".rstrip("0").rstrip(".")
    except (TypeError, ValueError):
        return str(value)


def _serialize_table(name: str, rows: List[Dict[str, Any]], fields_hint: Optional[Sequence[str]] = None) -> List[str]:
    if fields_hint:
        fields = list(fields_hint)
    elif rows:
        fields = [key for key in rows[0].keys() if not str(key).startswith("_")]
    else:
        fields = []

    seen = set(fields)
    for row in rows:
        for key in row.keys():
            if str(key).startswith("_"):
                continue
            if key not in seen:
                fields.append(key)
                seen.add(key)

    lines = [f"%T\t{name}"]
    if fields:
        lines.append("%F\t" + "\t".join(fields))
        for row in rows:
            values = []
            for field in fields:
                value = row.get(field, "")
                values.append("" if value is None else str(value))
            lines.append("%R\t" + "\t".join(values))
    return lines


def _set_cell(
    table: str,
    row_index: int,
    row: Dict[str, Any],
    field: str,
    value: Any,
    changed_cells: List[Dict[str, Any]],
) -> None:
    if field not in row:
        return
    before = "" if row.get(field) is None else str(row.get(field))
    after = "" if value is None else str(value)
    if before == after:
        return
    row[field] = after
    changed_cells.append({
        "table": table,
        "row_index": row_index,
        "field": field,
        "before": before,
        "after": after,
    })


def _find_task_row(
    activity,
    task_rows: List[Dict[str, Any]],
    by_code: Dict[str, List[Tuple[int, Dict[str, Any]]]],
    by_internal: Dict[str, Tuple[int, Dict[str, Any]]],
) -> Optional[Tuple[int, Dict[str, Any]]]:
    internal_id = str(activity.source.get("_internal_task_id") or "")
    if internal_id and internal_id in by_internal:
        return by_internal[internal_id]
    original_code = str(activity.source.get("_original_task_code") or activity.id)
    matches = by_code.get(original_code, [])
    return matches[0] if matches else None


def _find_relationship_row(
    relationship,
    rel_rows: List[Dict[str, Any]],
    code_to_internal: Dict[str, str],
    used_indices: set[int],
) -> Optional[Tuple[int, Dict[str, Any]]]:
    source_index = relationship.source.get("_xer_row_index")
    if isinstance(source_index, int) and 0 <= source_index < len(rel_rows) and source_index not in used_indices:
        return source_index, rel_rows[source_index]

    relationship_id = str(relationship.id or "")
    if relationship_id:
        for index, row in enumerate(rel_rows):
            if index in used_indices:
                continue
            if relationship_id in {str(row.get("task_pred_id") or ""), str(row.get("pred_id") or "")}:
                return index, row

    predecessor_internal = code_to_internal.get(relationship.predecessor_id, relationship.predecessor_id)
    successor_internal = code_to_internal.get(relationship.successor_id, relationship.successor_id)
    candidates = []
    for index, row in enumerate(rel_rows):
        if index in used_indices:
            continue
        if (
            str(row.get("task_id") or "") == str(successor_internal)
            and str(row.get("pred_task_id") or "") == str(predecessor_internal)
        ):
            candidates.append((index, row))
    if not candidates:
        return None
    # Prefer a row matching the original relationship type and lag.
    original_type = str(relationship.source.get("_raw_rel_type") or relationship.source.get("pred_type") or "")
    for candidate in candidates:
        if original_type and str(candidate[1].get("pred_type") or "") == original_type:
            return candidate
    return candidates[0]


def _render_recovered_xer(schedule: ProjectSchedule) -> Tuple[str, List[Dict[str, Any]], List[Dict[str, Any]]]:
    if not schedule.raw_tables:
        raise ValueError("Recovered XER export requires a schedule imported from an XER file.")

    tables = {name: [dict(row) for row in rows] for name, rows in schedule.raw_tables.items()}
    changed_cells: List[Dict[str, Any]] = []
    unsupported_changes: List[Dict[str, Any]] = []

    task_rows = tables.get("TASK", [])
    by_code: Dict[str, List[Tuple[int, Dict[str, Any]]]] = {}
    by_internal: Dict[str, Tuple[int, Dict[str, Any]]] = {}
    for index, row in enumerate(task_rows):
        code = str(row.get("task_code") or "").strip()
        internal = str(row.get("task_id") or "").strip()
        if code:
            by_code.setdefault(code, []).append((index, row))
        if internal:
            by_internal[internal] = (index, row)

    for activity in schedule.activities.values():
        match = _find_task_row(activity, task_rows, by_code, by_internal)
        if match is None:
            unsupported_changes.append({
                "type": "ACTIVITY_ROW_NOT_FOUND",
                "activity_id": activity.id,
            })
            continue
        row_index, row = match
        hours_per_day = float(
            activity.source.get("_duration_hours_per_day")
            or schedule.get_calendar(activity.calendar_id).hours_per_day
            or schedule.metadata.get("default_hours_per_day", 8.0)
        )
        if "remain_drtn_hr_cnt" in row:
            _set_cell(
                "TASK",
                row_index,
                row,
                "remain_drtn_hr_cnt",
                _fmt_num(activity.remaining_duration * hours_per_day),
                changed_cells,
            )

    code_to_internal = {
        activity_id: str(activity.source.get("_internal_task_id") or activity_id)
        for activity_id, activity in schedule.activities.items()
    }
    rel_rows = tables.get("TASKPRED", [])
    used_indices: set[int] = set()
    for relationship in schedule.relationships:
        if relationship.predecessor_id.startswith("EXT:"):
            continue
        match = _find_relationship_row(relationship, rel_rows, code_to_internal, used_indices)
        if match is None:
            unsupported_changes.append({
                "type": "RELATIONSHIP_ROW_NOT_FOUND",
                "relationship_id": relationship.id,
                "predecessor_id": relationship.predecessor_id,
                "successor_id": relationship.successor_id,
            })
            continue
        row_index, row = match
        used_indices.add(row_index)
        _set_cell("TASKPRED", row_index, row, "pred_type", "PR_" + relationship.rel_type.upper(), changed_cells)
        default_hpd = float(schedule.metadata.get("default_hours_per_day", 8.0) or 8.0)
        _set_cell("TASKPRED", row_index, row, "lag_hr_cnt", _fmt_num(relationship.lag * default_hpd), changed_cells)

    # Report requested changes that are outside the conservative writer scope.
    for change in schedule.changes:
        if change.field not in {"remaining_duration", "relationship"}:
            unsupported_changes.append({
                "type": "UNSUPPORTED_CHANGE_FIELD",
                "field": change.field,
                "activity_id": change.activity_id,
            })

    lines = list(schedule.metadata.get("xer_preamble", []) or [])
    table_order = list(schedule.metadata.get("xer_table_order", []) or list(tables.keys()))
    fields_map = schedule.metadata.get("xer_table_fields", {}) or {}
    emitted = set()
    for table_name in table_order:
        if table_name in tables and table_name not in emitted:
            lines.extend(_serialize_table(table_name, tables[table_name], fields_map.get(table_name)))
            emitted.add(table_name)
    for table_name, rows in tables.items():
        if table_name not in emitted:
            lines.extend(_serialize_table(table_name, rows, fields_map.get(table_name)))

    if not lines or lines[-1] != "%E":
        lines.append("%E")
    newline = str(schedule.metadata.get("xer_line_ending") or "\n")
    return newline.join(lines) + newline, changed_cells, unsupported_changes


def build_recovered_xer_text(schedule: ProjectSchedule) -> str:
    text, _changed_cells, _unsupported = _render_recovered_xer(schedule)
    return text


def _encoding_for_output(schedule: ProjectSchedule) -> str:
    encoding = str(schedule.metadata.get("xer_encoding") or "utf-8").lower()
    if encoding in {"utf-8-replace", "latin-1"}:
        return "utf-8" if encoding == "utf-8-replace" else "latin-1"
    return encoding


def build_recovered_xer_bytes(schedule: ProjectSchedule) -> bytes:
    text = build_recovered_xer_text(schedule)
    encoding = _encoding_for_output(schedule)
    try:
        return text.encode(encoding, errors="strict")
    except (LookupError, UnicodeEncodeError):
        return text.encode("utf-8", errors="replace")


def verify_recovered_xer(schedule: ProjectSchedule, output_text: Optional[str] = None) -> Dict[str, Any]:
    text = output_text if output_text is not None else build_recovered_xer_text(schedule)
    errors: List[str] = []
    try:
        reparsed = parse_xer_text(
            text,
            default_hours_per_day=float(schedule.metadata.get("default_hours_per_day", 8.0) or 8.0),
            project_id=str(schedule.metadata.get("selected_project_internal_id") or "") or None,
            source_encoding=str(schedule.metadata.get("xer_encoding") or "utf-8"),
        )
    except Exception as exc:
        return {"valid": False, "errors": [f"Reparse failed: {type(exc).__name__}: {exc}"]}

    source_counts = {name: len(rows) for name, rows in schedule.raw_tables.items()}
    output_counts = {name: len(rows) for name, rows in reparsed.raw_tables.items()}
    if source_counts != output_counts:
        errors.append("Table row counts changed during XER round-trip")
    source_fields = schedule.metadata.get("xer_table_fields", {}) or {}
    output_fields = reparsed.metadata.get("xer_table_fields", {}) or {}
    if source_fields != output_fields:
        errors.append("Table field schemas changed during XER round-trip")
    if list(schedule.metadata.get("xer_table_order", [])) != list(reparsed.metadata.get("xer_table_order", [])):
        errors.append("Table order changed during XER round-trip")

    for activity_id, activity in schedule.activities.items():
        candidate = reparsed.activities.get(activity_id)
        if candidate is None:
            # Duplicate codes may have deterministic suffixes; use internal ID.
            internal_id = str(activity.source.get("_internal_task_id") or "")
            candidate = next(
                (item for item in reparsed.activities.values() if str(item.source.get("_internal_task_id") or "") == internal_id),
                None,
            )
        if candidate is None:
            errors.append(f"Activity {activity_id} missing after round-trip")
            continue
        if abs(candidate.remaining_duration - activity.remaining_duration) > 1e-6:
            errors.append(f"Remaining duration mismatch for activity {activity_id}")
        for field in ("actual_start", "actual_finish", "status"):
            if getattr(candidate, field) != getattr(activity, field):
                errors.append(f"Historical field {field} changed for activity {activity_id}")

    # Reparsed relationships are matched by internal IDs because duplicate task
    # codes and parallel links are legal in source data.
    for relationship in schedule.relationships:
        if relationship.predecessor_id.startswith("EXT:"):
            continue
        candidates = [
            rel for rel in reparsed.relationships
            if rel.predecessor_id == relationship.predecessor_id and rel.successor_id == relationship.successor_id
        ]
        if not any(
            rel.rel_type == relationship.rel_type and abs(rel.lag - relationship.lag) <= 1e-6
            for rel in candidates
        ):
            errors.append(
                f"Relationship mismatch for {relationship.predecessor_id}->{relationship.successor_id}"
            )

    history_violations = validate_history_unchanged(schedule, reparsed)
    if history_violations:
        errors.append(f"History integrity violations after round-trip: {history_violations[:5]}")
    return {
        "valid": not errors,
        "errors": errors,
        "source_table_counts": source_counts,
        "output_table_counts": output_counts,
        "activity_count": len(reparsed.activities),
        "relationship_count": len(reparsed.relationships),
    }


def build_xer_integrity_manifest(schedule: ProjectSchedule) -> Dict[str, Any]:
    if not schedule.raw_tables:
        raise ValueError("XER manifest requires a source XER schedule.")
    text, changed_cells, unsupported_changes = _render_recovered_xer(schedule)
    output_bytes = build_recovered_xer_bytes(schedule)
    verification = verify_recovered_xer(schedule, text)
    duration_changes = [change for change in schedule.changes if change.field == "remaining_duration"]
    logic_changes = [change for change in schedule.changes if change.field == "relationship"]
    historical_changes = [
        change for change in schedule.changes
        if change.field in {"actual_start", "actual_finish", "status", "percent_complete"}
    ]
    return {
        "project_id": schedule.project_id,
        "source_format": schedule.metadata.get("import_format"),
        "source_encoding": schedule.metadata.get("xer_encoding"),
        "line_ending": "CRLF" if schedule.metadata.get("xer_line_ending") == "\r\n" else "LF",
        "source_sha256": schedule.metadata.get("source_xer_sha256") or schedule.metadata.get("source_xer_text_sha256"),
        "output_sha256": sha256_hex(output_bytes),
        "table_count": len(schedule.raw_tables),
        "table_row_counts": {name: len(rows) for name, rows in schedule.raw_tables.items()},
        "activity_rows": len(schedule.raw_tables.get("TASK", [])),
        "relationship_rows": len(schedule.raw_tables.get("TASKPRED", [])),
        "preamble_lines_preserved": len(schedule.metadata.get("xer_preamble", []) or []),
        "table_order_preserved": bool(schedule.metadata.get("xer_table_order")),
        "field_schemas_preserved": bool(schedule.metadata.get("xer_table_fields")),
        "duration_changes_requested": len(duration_changes),
        "logic_changes_requested": len(logic_changes),
        "changed_cell_count": len(changed_cells),
        "changed_cells": changed_cells,
        "unsupported_changes": unsupported_changes,
        "actual_history_changes": len(historical_changes),
        "history_integrity_pass": len(historical_changes) == 0 and verification["valid"],
        "roundtrip_verification": verification,
        "writer_scope": [
            "TASK.remain_drtn_hr_cnt",
            "TASKPRED.pred_type",
            "TASKPRED.lag_hr_cnt",
        ],
        "native_p6_reschedule_required": True,
    }
