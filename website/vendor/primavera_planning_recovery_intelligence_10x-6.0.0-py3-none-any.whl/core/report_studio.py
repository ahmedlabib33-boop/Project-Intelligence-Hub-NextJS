from __future__ import annotations
from copy import copy
from io import BytesIO, StringIO
from pathlib import Path
import csv, html, json, re, zipfile
from typing import Any, Dict, List, Tuple
import xml.etree.ElementTree as ET
from docx import Document
from openpyxl import load_workbook
from pypdf import PdfReader, PdfWriter
from reportlab.pdfgen import canvas
from reportlab.pdfbase.pdfmetrics import stringWidth
try:
    from pptx import Presentation
except Exception:
    Presentation=None

TAG=re.compile(r"{{\s*([A-Za-z0-9_.:-]+)\s*}}")
TABLE_TAG=re.compile(r"^{{\s*TABLE:([A-Za-z0-9_.:-]+)\s*}}$",re.I)

def _flatten(obj: Any, prefix: str='', out: Dict[str,Any]|None=None) -> Dict[str,Any]:
    out={} if out is None else out
    if isinstance(obj,dict):
        for k,v in obj.items(): _flatten(v,f'{prefix}.{k}' if prefix else str(k),out)
    elif isinstance(obj,list): out[prefix]=obj
    else: out[prefix]=obj
    return out

def _lookup(data: Dict[str,Any], key: str) -> Any:
    if key in data: return data[key]
    cur: Any=data
    for part in key.split('.'):
        if isinstance(cur,dict) and part in cur: cur=cur[part]
        else: return ''
    return cur

def _replace_text(text: str, data: Dict[str,Any]) -> str:
    return TAG.sub(lambda m: str(_lookup(data,m.group(1))) if not isinstance(_lookup(data,m.group(1)),(dict,list)) else json.dumps(_lookup(data,m.group(1)),ensure_ascii=False,default=str), text)

def load_report_data(filename: str, payload: bytes) -> Dict[str,Any]:
    ext=Path(filename).suffix.lower()
    if ext=='.json':
        obj=json.loads(payload.decode('utf-8-sig')); return obj if isinstance(obj,dict) else {'rows':obj}
    if ext in {'.csv','.tsv'}:
        text=payload.decode('utf-8-sig',errors='replace'); delim='\t' if ext=='.tsv' else ','
        try: delim=csv.Sniffer().sniff(text[:4096],delimiters=',\t;|').delimiter
        except Exception: pass
        rows=list(csv.DictReader(StringIO(text),delimiter=delim)); data={'rows':rows}
        if len(rows)==1: data.update(rows[0])
        return data
    if ext in {'.xlsx','.xlsm'}:
        wb=load_workbook(BytesIO(payload),read_only=True,data_only=True); sheets={}
        for ws in wb.worksheets:
            values=list(ws.iter_rows(values_only=True));
            if not values: continue
            headers=[str(v or '') for v in values[0]]; rows=[{headers[i]: row[i] if i<len(row) else None for i in range(len(headers))} for row in values[1:] if any(v not in (None,'') for v in row)]
            sheets[ws.title]=rows
        first=next(iter(sheets.values()),[]); data={'sheets':sheets,'rows':first}
        if len(first)==1: data.update(first[0])
        return data
    if ext=='.xml':
        root=ET.fromstring(payload); data={}
        for e in root.iter():
            if e.text and e.text.strip() and len(list(e))==0: data[e.tag.split('}')[-1]]=e.text.strip()
        return data
    text=payload.decode('utf-8-sig',errors='replace'); data={'text':text}
    for line in text.splitlines():
        if ':' in line:
            k,v=line.split(':',1); k=k.strip()
            if k: data[k]=v.strip()
    return data

def inspect_template(filename: str, payload: bytes) -> Dict[str,Any]:
    ext=Path(filename).suffix.lower(); tags=set(); mode='unsupported'
    try:
        if ext=='.docx':
            d=Document(BytesIO(payload)); texts=[p.text for p in d.paragraphs]
            for t in d.tables:
                texts += [c.text for r in t.rows for c in r.cells]
            for x in texts: tags.update(TAG.findall(x)); mode='docx-placeholders'
        elif ext in {'.xlsx','.xlsm'}:
            wb=load_workbook(BytesIO(payload),read_only=True,data_only=False)
            for ws in wb.worksheets:
                for row in ws.iter_rows():
                    for c in row:
                        if isinstance(c.value,str): tags.update(TAG.findall(c.value))
            mode='xlsx-placeholders'
        elif ext=='.pptx' and Presentation:
            prs=Presentation(BytesIO(payload))
            for s in prs.slides:
                for sh in s.shapes:
                    if getattr(sh,'has_text_frame',False): tags.update(TAG.findall(sh.text))
            mode='pptx-placeholders'
        elif ext in {'.html','.htm','.txt','.md'}:
            tags.update(TAG.findall(payload.decode('utf-8-sig',errors='replace'))); mode='text-placeholders'
        elif ext=='.pdf':
            r=PdfReader(BytesIO(payload)); fields=r.get_fields() or {}; tags.update(fields.keys()); mode='pdf-form' if fields else 'pdf-placeholder-overlay'
            if not fields:
                for page in r.pages: tags.update(TAG.findall(page.extract_text() or ''))
        return {'format':ext.lstrip('.'),'mode':mode,'placeholders':sorted(tags),'placeholder_count':len(tags)}
    except Exception as e:
        return {'format':ext.lstrip('.'),'mode':'inspect-failed','placeholders':[],'placeholder_count':0,'warning':f'{type(e).__name__}: {e}'}

def _replace_paragraph_runs(paragraph, data: Dict[str,Any]) -> None:
    # Replace placeholders while preserving surrounding run formatting. A value inherits
    # the formatting of the run where the placeholder begins.
    for _ in range(500):
        runs=list(paragraph.runs)
        if not runs: return
        full=''.join(r.text for r in runs)
        match=TAG.search(full)
        if not match: return
        value=_lookup(data,match.group(1))
        if isinstance(value,(dict,list)): value=json.dumps(value,ensure_ascii=False,default=str)
        value='' if value is None else str(value)
        positions=[]
        pos=0
        for idx,r in enumerate(runs):
            positions.append((pos,pos+len(r.text),idx)); pos+=len(r.text)
        start_run=end_run=None; start_off=end_off=0
        for a,b,idx in positions:
            if start_run is None and a<=match.start()<b or (match.start()==len(full) and b==len(full)):
                start_run=idx; start_off=match.start()-a
            if a<match.end()<=b or (match.end()==a and a==b):
                end_run=idx; end_off=match.end()-a; break
        if start_run is None:
            start_run=0; start_off=0
        if end_run is None:
            end_run=len(runs)-1; end_off=len(runs[end_run].text)
        if start_run==end_run:
            txt=runs[start_run].text
            runs[start_run].text=txt[:start_off]+value+txt[end_off:]
        else:
            prefix=runs[start_run].text[:start_off]
            suffix=runs[end_run].text[end_off:]
            runs[start_run].text=prefix+value
            for i in range(start_run+1,end_run): runs[i].text=''
            runs[end_run].text=suffix

def _render_docx(payload: bytes, data: Dict[str,Any]) -> bytes:
    d=Document(BytesIO(payload))
    def process_container(paragraphs, tables):
        for p in paragraphs: _replace_paragraph_runs(p,data)
        for t in tables:
            for row in t.rows:
                for cell in row.cells:
                    process_container(cell.paragraphs,cell.tables)
    process_container(d.paragraphs,d.tables)
    for section in d.sections:
        for hf in (section.header,section.footer,section.first_page_header,section.first_page_footer,section.even_page_header,section.even_page_footer):
            process_container(hf.paragraphs,hf.tables)
    out=BytesIO(); d.save(out); return out.getvalue()

def _render_xlsx(payload: bytes, data: Dict[str,Any]) -> bytes:
    wb=load_workbook(BytesIO(payload))
    for ws in wb.worksheets:
        for row in list(ws.iter_rows()):
            for cell in row:
                if not isinstance(cell.value,str) or '{{' not in cell.value: continue
                m=TABLE_TAG.match(cell.value.strip())
                if m:
                    rows=_lookup(data,m.group(1));
                    if isinstance(rows,list) and rows and isinstance(rows[0],dict):
                        headers=list(rows[0].keys()); r0=cell.row; c0=cell.column
                        for j,h in enumerate(headers): ws.cell(r0,c0+j,h)
                        for i,item in enumerate(rows,start=1):
                            for j,h in enumerate(headers):
                                target=ws.cell(r0+i,c0+j,item.get(h)); target._style=copy(cell._style)
                    else: cell.value=''
                else: cell.value=_replace_text(cell.value,data)
    out=BytesIO(); wb.save(out); return out.getvalue()

def _render_pptx(payload: bytes, data: Dict[str,Any]) -> bytes:
    if Presentation is None: raise ValueError('python-pptx is not available')
    prs=Presentation(BytesIO(payload))
    def replace_paragraph(p):
        full=''.join(r.text for r in p.runs)
        if '{{' not in full: return
        # Preserve the first run's formatting and clear continuation runs when the placeholder spans runs.
        new=_replace_text(full,data)
        if p.runs:
            p.runs[0].text=new
            for r in p.runs[1:]: r.text=''
    for slide in prs.slides:
        for shape in slide.shapes:
            if getattr(shape,'has_text_frame',False):
                for p in shape.text_frame.paragraphs: replace_paragraph(p)
            if getattr(shape,'has_table',False):
                for row in shape.table.rows:
                    for cell in row.cells:
                        for p in cell.text_frame.paragraphs: replace_paragraph(p)
    out=BytesIO(); prs.save(out); return out.getvalue()

def _data_appendix_pdf(data: Dict[str,Any], pagesize=(612.0,792.0)) -> bytes:
    flat=_flatten(data)
    out=BytesIO(); c=canvas.Canvas(out,pagesize=pagesize); w,h=pagesize
    def header():
        c.setFont('Helvetica-Bold',16); c.drawString(42,h-48,'Report Studio - Unmapped Data Appendix')
        c.setFont('Helvetica',8); c.drawString(42,h-64,'The original PDF contained no fillable fields or {{tags}}, so data is appended without altering the source pages.')
        return h-88
    y=header()
    for key,value in sorted(flat.items()):
        if isinstance(value,(dict,list)): value=json.dumps(value,ensure_ascii=False,default=str)
        text=str(value)
        chunks=[text[i:i+90] for i in range(0,max(1,len(text)),90)] or ['']
        need=14*max(1,len(chunks)) + 4
        if y-need<44:
            c.showPage(); y=header()
        c.setFont('Helvetica-Bold',8); c.drawString(42,y,str(key)[:52]);
        c.setFont('Helvetica',8)
        for j,chunk in enumerate(chunks[:8]): c.drawString(210,y-14*j,chunk.replace('\n',' ')[:100])
        y-=need
    c.save(); return out.getvalue()

def _render_pdf(payload: bytes, data: Dict[str,Any]) -> Tuple[bytes,str]:
    reader=PdfReader(BytesIO(payload)); fields=reader.get_fields() or {}
    if fields:
        writer=PdfWriter(); writer.append(reader)
        values={k:str(_lookup(data,k)) for k in fields if _lookup(data,k) not in ('',None)}
        for page in writer.pages: writer.update_page_form_field_values(page,values,auto_regenerate=True)
        out=BytesIO(); writer.write(out); return out.getvalue(),'pdf-form'
    # Tagged-PDF overlay: replace visible {{key}} tags at extracted coordinates.
    writer=PdfWriter(); found=0
    for page in reader.pages:
        loc=[]
        def visitor(text,cm,tm,font_dict,font_size):
            if text and '{{' in text:
                size=float(font_size or 10)
                for m in TAG.finditer(text):
                    # tm[4]/tm[5] is the text-fragment origin, not the placeholder origin.
                    # Offset by the rendered width of the prefix so labels before a tag remain untouched.
                    prefix=text[:m.start()]
                    x=float(tm[4]) + stringWidth(prefix,'Helvetica',size)
                    loc.append((m.group(0),m.group(1),x,float(tm[5]),size))
        try: page.extract_text(visitor_text=visitor)
        except Exception: loc=[]
        if loc:
            packet=BytesIO(); w=float(page.mediabox.width); h=float(page.mediabox.height); c=canvas.Canvas(packet,pagesize=(w,h))
            for raw,key,x,y,size in loc:
                val=str(_lookup(data,key)); erase=max(stringWidth(raw,'Helvetica',size)+6,24)
                font_size=max(5.0,min(size,14.0))
                while font_size>5.0 and stringWidth(val,'Helvetica',font_size)>erase-4: font_size-=0.5
                c.setFillColorRGB(1,1,1); c.rect(x-3,y-max(3.0,size*0.35),erase+8,size*1.55,fill=1,stroke=0)
                c.setFillColorRGB(0,0,0); c.setFont('Helvetica',font_size); c.drawString(x,y,val); found+=1
            c.save(); packet.seek(0); overlay=PdfReader(packet).pages[0]; page.merge_page(overlay)
        writer.add_page(page)
    if found:
        out=BytesIO(); writer.write(out); return out.getvalue(),'pdf-placeholder-overlay'
    # Never-fail, non-destructive fallback: retain every source page and append the supplied data.
    appendix=_data_appendix_pdf(data,(float(reader.pages[0].mediabox.width),float(reader.pages[0].mediabox.height)) if reader.pages else (612.0,792.0))
    for p in PdfReader(BytesIO(appendix)).pages: writer.add_page(p)
    out=BytesIO(); writer.write(out); return out.getvalue(),'pdf-appended-data'

def render_template(filename: str, payload: bytes, data: Dict[str,Any]) -> Tuple[bytes,str,str]:
    ext=Path(filename).suffix.lower()
    if ext=='.docx': return _render_docx(payload,data),'application/vnd.openxmlformats-officedocument.wordprocessingml.document','.docx'
    if ext in {'.xlsx','.xlsm'}: return _render_xlsx(payload,data),'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','.xlsx'
    if ext=='.pptx': return _render_pptx(payload,data),'application/vnd.openxmlformats-officedocument.presentationml.presentation','.pptx'
    if ext in {'.html','.htm','.txt','.md'}:
        text=_replace_text(payload.decode('utf-8-sig',errors='replace'),data).encode('utf-8'); mt='text/html' if ext in {'.html','.htm'} else 'text/plain'; return text,mt,ext
    if ext=='.pdf':
        content,mode=_render_pdf(payload,data); return content,'application/pdf','.pdf'
    # Universal fallback for binary/unknown template formats: never discard the template.
    flat=_flatten(data)
    rows=''.join(f'<tr><th>{html.escape(str(k))}</th><td>{html.escape(str(v))}</td></tr>' for k,v in sorted(flat.items()))
    report=(f'<!doctype html><meta charset="utf-8"><title>Report Studio Fallback</title><style>body{{font-family:Arial,sans-serif;margin:32px;color:#172033}}table{{border-collapse:collapse;width:100%}}th,td{{padding:8px 10px;border-bottom:1px solid #ccd3df;text-align:left;vertical-align:top}}th{{width:30%;background:#f3f6fa}}</style><h1>Report Studio Fallback</h1><p>The supplied template format is preserved unchanged in this package. Parsed data is provided below because direct in-place rendering is not available for this format.</p><table>{rows}</table>').encode('utf-8')
    out=BytesIO()
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(f'ORIGINAL_TEMPLATE/{Path(filename).name or "template.bin"}',payload)
        zf.writestr('POPULATED_DATA.html',report)
        zf.writestr('POPULATED_DATA.json',json.dumps(data,indent=2,ensure_ascii=False,default=str).encode('utf-8'))
    return out.getvalue(),'application/zip','.zip'
