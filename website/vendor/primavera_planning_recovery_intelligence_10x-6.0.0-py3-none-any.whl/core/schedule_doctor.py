from __future__ import annotations
from dataclasses import asdict
from typing import Any, Dict, List, Set, Tuple
import hashlib, json
from .models import Change, ProjectSchedule
from .qa import schedule_quality
from .cpm import calculate_cpm


def _fix_id(payload: Dict[str,Any]) -> str:
    return hashlib.sha256(json.dumps(payload,sort_keys=True,default=str).encode()).hexdigest()[:16]

def build_repair_plan(schedule: ProjectSchedule) -> Dict[str,Any]:
    qa=schedule_quality(schedule); fixes=[]
    seen_rel=set()
    for i,rel in enumerate(schedule.relationships):
        key=(rel.predecessor_id,rel.successor_id,rel.rel_type,round(rel.lag,9))
        if rel.predecessor_id==rel.successor_id:
            f={"kind":"REMOVE_RELATIONSHIP","index":i,"safe":True,"risk":"LOW","reason":"Self-relationship is invalid logic."}; f["id"]=_fix_id(f); fixes.append(f)
        elif rel.predecessor_id not in schedule.activities or rel.successor_id not in schedule.activities:
            f={"kind":"REMOVE_RELATIONSHIP","index":i,"safe":True,"risk":"LOW","reason":"Dangling relationship references a missing activity."}; f["id"]=_fix_id(f); fixes.append(f)
        elif key in seen_rel:
            f={"kind":"REMOVE_RELATIONSHIP","index":i,"safe":True,"risk":"LOW","reason":"Exact duplicate relationship."}; f["id"]=_fix_id(f); fixes.append(f)
        seen_rel.add(key)
    for aid,a in schedule.activities.items():
        if a.calendar_id not in schedule.calendars:
            f={"kind":"ASSIGN_DEFAULT_CALENDAR","activity_id":aid,"safe":True,"risk":"LOW","reason":"Assigned calendar does not exist."}; f["id"]=_fix_id(f); fixes.append(f)
        if a.original_duration<0 or a.remaining_duration<0:
            f={"kind":"CLAMP_DURATION","activity_id":aid,"safe":True,"risk":"LOW","reason":"Negative durations are invalid."}; f["id"]=_fix_id(f); fixes.append(f)
        if a.is_milestone and a.remaining_duration>0:
            f={"kind":"ZERO_MILESTONE_DURATION","activity_id":aid,"safe":True,"risk":"LOW","reason":"Milestones must have zero duration."}; f["id"]=_fix_id(f); fixes.append(f)
        if a.is_complete and a.remaining_duration>0:
            f={"kind":"ZERO_COMPLETE_REMAINING","activity_id":aid,"safe":True,"risk":"LOW","reason":"Completed activity cannot retain remaining duration."}; f["id"]=_fix_id(f); fixes.append(f)
        if a.percent_complete<0 or a.percent_complete>100:
            f={"kind":"CLAMP_PERCENT","activity_id":aid,"safe":True,"risk":"LOW","reason":"Percent complete must be 0..100."}; f["id"]=_fix_id(f); fixes.append(f)
    for issue in qa["issues"]:
        if issue["type"] in {"OPEN_START","OPEN_FINISH","NEGATIVE_LAG","LONG_LAG","CONSTRAINT_WITHOUT_DATE","OUT_OF_SEQUENCE_PROGRESS","CYCLE"}:
            f={"kind":"REVIEW_REQUIRED","activity_id":issue.get("activity_id",""),"safe":False,"risk":"MEDIUM","reason":issue["detail"],"issue_type":issue["type"]}; f["id"]=_fix_id(f); fixes.append(f)
    return {"qa":qa,"fixes":fixes,"safe_fix_count":sum(1 for f in fixes if f["safe"]),"review_fix_count":sum(1 for f in fixes if not f["safe"])}

def apply_repairs(schedule: ProjectSchedule, selected_ids: List[str]|None=None, safe_only: bool=True, approved_by: str="") -> Tuple[ProjectSchedule,Dict[str,Any]]:
    plan=build_repair_plan(schedule); selected=set(selected_ids or [])
    clone=schedule.clone(); applied=[]
    remove_indices=[]
    for f in plan["fixes"]:
        if selected and f["id"] not in selected: continue
        if safe_only and not f["safe"]: continue
        kind=f["kind"]; aid=f.get("activity_id","")
        if kind=="REMOVE_RELATIONSHIP": remove_indices.append(f["index"])
        elif aid in clone.activities:
            a=clone.activities[aid]
            if kind=="ASSIGN_DEFAULT_CALENDAR": before=a.calendar_id; a.calendar_id=clone.get_calendar().id; field="calendar_id"; after=a.calendar_id
            elif kind=="CLAMP_DURATION": before=(a.original_duration,a.remaining_duration); a.original_duration=max(0,a.original_duration); a.remaining_duration=max(0,a.remaining_duration); field="durations"; after=(a.original_duration,a.remaining_duration)
            elif kind=="ZERO_MILESTONE_DURATION": before=a.remaining_duration; a.remaining_duration=0; a.original_duration=0; field="remaining_duration"; after=0
            elif kind=="ZERO_COMPLETE_REMAINING": before=a.remaining_duration; a.remaining_duration=0; field="remaining_duration"; after=0
            elif kind=="CLAMP_PERCENT": before=a.percent_complete; a.percent_complete=min(100,max(0,a.percent_complete)); field="percent_complete"; after=a.percent_complete
            else: continue
            clone.changes.append(Change(kind="QA_REPAIR",activity_id=aid,field=field,before=before,after=after,reason=f["reason"],risk=f["risk"],requires_approval=False,approved_by=approved_by))
        applied.append(f)
    if remove_indices:
        for idx in sorted(set(remove_indices),reverse=True):
            if 0<=idx<len(clone.relationships):
                rel=clone.relationships[idx]
                clone.changes.append(Change(kind="QA_REPAIR",activity_id=rel.successor_id,field="relationship",before={"pred":rel.predecessor_id,"succ":rel.successor_id,"type":rel.rel_type,"lag":rel.lag},after=None,reason="Removed invalid/duplicate relationship",risk="LOW",requires_approval=False,approved_by=approved_by))
                del clone.relationships[idx]
    try: calculate_cpm(clone)
    except Exception: pass
    return clone,{"applied":applied,"applied_count":len(applied),"remaining":build_repair_plan(clone)}
