from __future__ import annotations

from datetime import datetime, timezone
from html import escape
from io import BytesIO
from typing import Any, Dict, List, Optional, Sequence

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    KeepTogether,
    LongTable,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from .cpm import calculate_cpm
from .integrity import schedule_fingerprint, verify_audit_chain
from .models import ProjectSchedule
from .qa import schedule_quality
from .utils import utc_now_iso
from .version import ENGINE_ID, REPORT_AUTHOR, VERSION
from .xer_writer import build_xer_integrity_manifest


_NAVY = "17365D"
_BLUE = "2F75B5"
_LIGHT_BLUE = "D9EAF7"
_LIGHT_GREEN = "E2F0D9"
_LIGHT_ORANGE = "FCE4D6"
_LIGHT_RED = "F4CCCC"
_GRAY = "E7E6E6"
_WHITE = "FFFFFF"


def _fmt(value: Any, nd: int = 2) -> str:
    if value is None or value == "":
        return "-"
    if isinstance(value, bool):
        return "YES" if value else "NO"
    if isinstance(value, float):
        return f"{value:.{nd}f}"
    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d %H:%M")
    if isinstance(value, (dict, list, tuple)):
        import json
        return json.dumps(value, ensure_ascii=False, default=str, sort_keys=True)
    return str(value)


def _scenario_recovery(context: Dict[str, Any]) -> float:
    scenario = context.get("scenario") or {}
    try:
        return float(scenario.get("recovery_days", 0) or 0)
    except (TypeError, ValueError):
        return 0.0


def build_report_data(
    schedule: ProjectSchedule,
    context: Optional[Dict[str, Any]] = None,
    action_log: Optional[List[Dict[str, Any]]] = None,
    accepted: bool = False,
) -> Dict[str, Any]:
    """Create the single canonical report model used by DOCX, PDF and package export."""
    context = dict(context or {})
    action_log = list(action_log or [])

    calc = calculate_cpm(schedule, compute_path_drag=True)
    qa = schedule_quality(schedule)
    base = context.get("base_schedule")

    base_finish = None
    base_critical = None
    base_qa = None
    base_forecast = None
    base_fingerprint = None
    if isinstance(base, ProjectSchedule):
        base_calc = calculate_cpm(base, compute_path_drag=False)
        base_qa = schedule_quality(base)
        base_finish = float(base_calc["project_finish_offset_days"])
        base_critical = len(base_calc["critical_activity_ids"])
        base_forecast = max((activity.forecast_finish for activity in base.activities.values() if activity.forecast_finish), default=None)
        base_fingerprint = schedule_fingerprint(base)

    final_finish = float(calc["project_finish_offset_days"])
    recovery = (base_finish - final_finish) if base_finish is not None else _scenario_recovery(context)
    target_recovery = max(0.0, float(context.get("target_recovery_days", 0) or 0))
    residual_gap = max(0.0, target_recovery - recovery) if target_recovery else 0.0
    target_met = bool(target_recovery and recovery + 1e-9 >= target_recovery)

    xer_manifest = None
    if schedule.metadata.get("import_format") == "XER":
        try:
            xer_manifest = build_xer_integrity_manifest(schedule)
        except Exception as exc:  # Reporting must not hide a schedule export failure.
            xer_manifest = {"manifest_available": False, "error": type(exc).__name__}

    critical = sorted(
        [activity for activity in schedule.activities.values() if activity.critical],
        key=lambda activity: (activity.es, activity.id),
    )
    near = sorted(
        [activity for activity in schedule.activities.values() if not activity.critical and activity.total_float <= 5],
        key=lambda activity: (activity.total_float, activity.es, activity.id),
    )
    constrained = sorted(
        [activity for activity in schedule.activities.values() if activity.constraint_type or activity.constraint_type2],
        key=lambda activity: (activity.es, activity.id),
    )

    scenario = dict(context.get("scenario") or {})
    decisions = dict(context.get("decisions") or {})
    audit_verification = verify_audit_chain(action_log)
    final_fingerprint = schedule_fingerprint(schedule)
    final_forecast = max((activity.forecast_finish for activity in schedule.activities.values() if activity.forecast_finish), default=None)

    path_rows = []
    driving_paths = calc.get("critical_paths") or []
    if not driving_paths and calc.get("longest_path_activity_ids"):
        driving_paths = [calc["longest_path_activity_ids"]]
    for path_number, path in enumerate(driving_paths[:20], start=1):
        duration = sum(schedule.activities[aid].duration for aid in path if aid in schedule.activities)
        path_rows.append({"path_number": path_number, "activity_ids": path, "duration": duration})

    return {
        "engine": ENGINE_ID,
        "engine_version": VERSION,
        "title": "Recovery Schedule Analysis and Audit Report",
        "generated_at": utc_now_iso(),
        "accepted": bool(accepted),
        "acceptance_fingerprint": context.get("accepted_fingerprint", final_fingerprint if accepted else ""),
        "project": {
            "id": schedule.project_id,
            "name": schedule.project_name,
            "data_date": schedule.data_date.strftime("%Y-%m-%d") if schedule.data_date else "-",
            "activities": len(schedule.activities),
            "relationships": len(schedule.relationships),
            "calendars": len(schedule.calendars),
            "import_format": schedule.metadata.get("import_format", "UNKNOWN"),
            "scheduling_mode": schedule.metadata.get("scheduling_mode", "RETAINED_LOGIC"),
        },
        "baseline": {
            "finish_offset": base_finish,
            "forecast_finish": base_forecast,
            "critical_count": base_critical,
            "qa_score": base_qa["score"] if base_qa else None,
            "qa_grade": base_qa.get("grade") if base_qa else None,
            "fingerprint": base_fingerprint,
        },
        "final": {
            "finish_offset": final_finish,
            "forecast_finish": final_forecast,
            "critical_count": len(calc["critical_activity_ids"]),
            "near_critical_count": len(near),
            "driving_path_count": len(path_rows),
            "qa_score": qa["score"],
            "qa_grade": qa.get("grade"),
            "qa_errors": qa["errors"],
            "qa_warnings": qa["warnings"],
            "calculation_runtime_ms": calc.get("calculation_runtime_ms"),
            "fingerprint": final_fingerprint,
        },
        "recovery_days": recovery,
        "target_recovery_days": target_recovery,
        "residual_gap_days": residual_gap,
        "target_met": target_met,
        "xer_integrity_manifest": xer_manifest,
        "scenario": scenario,
        "decisions": decisions,
        "changes": [
            {
                "scenario_id": change.scenario_id,
                "kind": change.kind,
                "activity_id": change.activity_id,
                "relationship_id": change.relationship_id,
                "field": change.field,
                "before": change.before,
                "after": change.after,
                "reason": change.reason,
                "risk": change.risk,
                "approval_required": change.requires_approval,
                "approved_by": change.approved_by,
                "approved_at": change.approved_at,
                "evidence_ref": change.evidence_ref,
                "provenance_hash": change.provenance_hash,
                "calculated_recovery_days": change.calculated_recovery_days,
                "predecessor_id": change.predecessor_id,
                "successor_id": change.successor_id,
            }
            for change in schedule.changes
        ],
        "longest_path_ids": calc.get("longest_path_activity_ids", []),
        "driving_paths": path_rows,
        "critical": [
            {
                "id": activity.id,
                "name": activity.name,
                "duration": activity.duration,
                "es": activity.es,
                "ef": activity.ef,
                "tf": activity.total_float,
                "ff": activity.free_float,
                "path_drag": activity.path_drag,
                "forecast_finish": activity.forecast_finish,
            }
            for activity in critical[:150]
        ],
        "near_critical": [
            {
                "id": activity.id,
                "name": activity.name,
                "duration": activity.duration,
                "es": activity.es,
                "ef": activity.ef,
                "tf": activity.total_float,
                "forecast_finish": activity.forecast_finish,
            }
            for activity in near[:150]
        ],
        "constraints": [
            {
                "id": activity.id,
                "name": activity.name,
                "constraint_1": activity.constraint_type,
                "date_1": activity.constraint_date,
                "constraint_2": activity.constraint_type2,
                "date_2": activity.constraint_date2,
                "tf": activity.total_float,
            }
            for activity in constrained[:150]
        ],
        "qa_metrics": qa.get("metrics", {}),
        "qa_issues": qa["issues"][:250],
        "action_log": action_log[-250:],
        "audit_verification": audit_verification,
        "limitations": [
            "The CPM, float, path and recovery calculations are deterministic; an LLM is never used to calculate schedule dates.",
            "Every recovery intervention remains a planning proposal until explicitly approved and supported by constructability, resource and productivity evidence.",
            "Logic overlap requires construction-method, interface, access, temporary works and safety validation before implementation.",
            "Calendar sensitivity does not silently recreate every native P6 shift, holiday, exception or resource-calendar nuance.",
            "The recovered XER must be re-imported into Primavera P6 and scheduled with the organization-approved P6 options before issue.",
            "Schedule mathematics and recovery potential do not by themselves establish contractual cause, liability or entitlement.",
        ],
    }


def _docx_set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shading = tc_pr.find(qn("w:shd"))
    if shading is None:
        shading = OxmlElement("w:shd")
        tc_pr.append(shading)
    shading.set(qn("w:fill"), fill)


def _docx_set_cell_margins(cell, top: int = 80, start: int = 90, bottom: int = 80, end: int = 90) -> None:
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for margin, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{margin}"))
        if node is None:
            node = OxmlElement(f"w:{margin}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def _docx_prevent_row_split(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    if tr_pr.find(qn("w:cantSplit")) is None:
        tr_pr.append(OxmlElement("w:cantSplit"))


def _docx_repeat_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def _docx_add_page_field(paragraph) -> None:
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = paragraph.add_run("Page ")
    run.font.size = Pt(8)
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = "PAGE"
    separate = OxmlElement("w:fldChar")
    separate.set(qn("w:fldCharType"), "separate")
    text = OxmlElement("w:t")
    text.text = "1"
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    run._r.extend([begin, instr, separate, text, end])


def _docx_table(doc: Document, headers: Sequence[str], rows: Sequence[Sequence[Any]], widths: Optional[Sequence[float]] = None):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    table.autofit = True
    _docx_repeat_header(table.rows[0])
    _docx_prevent_row_split(table.rows[0])
    for index, heading in enumerate(headers):
        cell = table.rows[0].cells[index]
        cell.text = str(heading)
        _docx_set_cell_shading(cell, _NAVY)
        _docx_set_cell_margins(cell)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        for paragraph in cell.paragraphs:
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for run in paragraph.runs:
                run.bold = True
                run.font.color.rgb = RGBColor(255, 255, 255)
                run.font.size = Pt(8)
        if widths and index < len(widths):
            cell.width = Inches(widths[index])

    for raw_row in rows:
        row = table.add_row()
        _docx_prevent_row_split(row)
        for index, value in enumerate(raw_row):
            cell = row.cells[index]
            cell.text = _fmt(value)
            _docx_set_cell_margins(cell)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            if widths and index < len(widths):
                cell.width = Inches(widths[index])
            for paragraph in cell.paragraphs:
                paragraph.paragraph_format.space_after = Pt(0)
                paragraph.paragraph_format.line_spacing = 1.0
                for run in paragraph.runs:
                    run.font.size = Pt(8)
        if raw_row and str(raw_row[0]).upper() == "ERROR":
            _docx_set_cell_shading(row.cells[0], _LIGHT_RED)
        elif raw_row and str(raw_row[0]).upper() in {"WARN", "WARNING", "HIGH"}:
            _docx_set_cell_shading(row.cells[0], _LIGHT_ORANGE)
    doc.add_paragraph().paragraph_format.space_after = Pt(1)
    return table


def _docx_heading(doc: Document, text: str, level: int = 1) -> None:
    paragraph = doc.add_heading(text, level=level)
    paragraph.paragraph_format.keep_with_next = True


def build_docx_bytes(data: Dict[str, Any]) -> bytes:
    doc = Document()
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(0.62)
    section.bottom_margin = Inches(0.62)
    section.left_margin = Inches(0.68)
    section.right_margin = Inches(0.68)

    styles = doc.styles
    styles["Normal"].font.name = "Arial"
    styles["Normal"].font.size = Pt(9.5)
    styles["Normal"].paragraph_format.space_after = Pt(4)
    styles["Title"].font.name = "Arial"
    styles["Heading 1"].font.name = "Arial"
    styles["Heading 1"].font.color.rgb = RGBColor(23, 54, 93)
    styles["Heading 1"].font.size = Pt(14)
    styles["Heading 2"].font.name = "Arial"
    styles["Heading 2"].font.color.rgb = RGBColor(47, 117, 181)
    styles["Heading 2"].font.size = Pt(11)

    header = section.header.paragraphs[0]
    header.text = f"{ENGINE_ID} | {data['project']['id']}"
    header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    for run in header.runs:
        run.font.name = "Arial"
        run.font.size = Pt(8)
        run.font.color.rgb = RGBColor(100, 100, 100)
    footer = section.footer.paragraphs[0]
    _docx_add_page_field(footer)

    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title.paragraph_format.space_before = Pt(30)
    run = title.add_run("PRIMAVERA RECOVERY INTELLIGENCE")
    run.bold = True
    run.font.size = Pt(21)
    run.font.color.rgb = RGBColor(23, 54, 93)
    subtitle = doc.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = subtitle.add_run("10X Planning Intelligence Studio - Recovery Schedule Analysis and Audit Report")
    run.bold = True
    run.font.size = Pt(13)
    run.font.color.rgb = RGBColor(47, 117, 181)

    project = doc.add_paragraph()
    project.alignment = WD_ALIGN_PARAGRAPH.CENTER
    project.paragraph_format.space_before = Pt(16)
    r = project.add_run(data["project"]["name"])
    r.bold = True
    r.font.size = Pt(15)
    meta = doc.add_paragraph()
    meta.alignment = WD_ALIGN_PARAGRAPH.CENTER
    meta.add_run(
        f"Project ID: {data['project']['id']}\nData Date: {data['project']['data_date']}\nGenerated: {data['generated_at']}"
    )

    status = doc.add_paragraph()
    status.alignment = WD_ALIGN_PARAGRAPH.CENTER
    status.paragraph_format.space_before = Pt(14)
    status_run = status.add_run("ACCEPTED RECOVERY RESULT" if data["accepted"] else "DRAFT - NOT ACCEPTED")
    status_run.bold = True
    status_run.font.size = Pt(12)
    status_run.font.color.rgb = RGBColor(84, 130, 53) if data["accepted"] else RGBColor(192, 80, 77)

    doc.add_page_break()

    _docx_heading(doc, "1. Executive Decision Summary")
    _docx_table(
        doc,
        ["Metric", "Working Basis", "Recovered / Reviewed Clone"],
        [
            ["Forecast finish", data["baseline"]["forecast_finish"], data["final"]["forecast_finish"]],
            ["Finish offset (working days)", data["baseline"]["finish_offset"], data["final"]["finish_offset"]],
            ["Critical activities", data["baseline"]["critical_count"], data["final"]["critical_count"]],
            ["Schedule QA", f"{_fmt(data['baseline']['qa_score'])} / {data['baseline']['qa_grade'] or '-'}", f"{_fmt(data['final']['qa_score'])} / {data['final']['qa_grade'] or '-'}"],
            ["Recovery target", "-", data["target_recovery_days"] or "Not set"],
            ["Recovery achieved", "-", data["recovery_days"]],
            ["Residual target gap", "-", data["residual_gap_days"]],
            ["Target achieved", "-", "YES" if data["target_met"] else ("NO" if data["target_recovery_days"] else "N/A")],
            ["Audit chain", "-", "VALID" if data["audit_verification"].get("valid") else "INVALID"],
        ],
        widths=[3.4, 1.6, 2.2],
    )
    doc.add_paragraph(
        f"The selected clone produces {_fmt(data['recovery_days'])} working days of calculated improvement. "
        "The source/master schedule was not modified. Acceptance in this report records a workflow decision, not contractual approval."
    )

    _docx_heading(doc, "2. Control and Integrity Record")
    _docx_table(
        doc,
        ["Control", "Value"],
        [
            ["Engine", data["engine"]],
            ["Import format", data["project"]["import_format"]],
            ["Scheduling mode", data["project"]["scheduling_mode"]],
            ["Working-basis fingerprint", data["baseline"]["fingerprint"]],
            ["Final schedule fingerprint", data["final"]["fingerprint"]],
            ["Acceptance fingerprint", data.get("acceptance_fingerprint")],
            ["Audit events", data["audit_verification"].get("count")],
            ["Audit head hash", data["audit_verification"].get("head_hash")],
        ],
        widths=[2.2, 5.0],
    )

    _docx_heading(doc, "3. Recovery Basis and Planner Decisions")
    if data["decisions"]:
        _docx_table(doc, ["Recovery Gate", "Decision"], [[key, value] for key, value in data["decisions"].items()], widths=[2.5, 4.7])
    else:
        doc.add_paragraph("No interactive recovery decisions were recorded in this report context.")

    scenario = data.get("scenario") or {}
    _docx_heading(doc, "4. Selected Recovery Scenario")
    _docx_table(
        doc,
        ["Parameter", "Value"],
        [
            ["Scenario ID", scenario.get("id")],
            ["Scenario type", scenario.get("type")],
            ["Strategy", scenario.get("strategy")],
            ["Calculated recovery", scenario.get("recovery_days", data["recovery_days"])],
            ["Change count", scenario.get("change_count", len(data["changes"]))],
            ["Risk", scenario.get("risk")],
            ["Confidence", scenario.get("confidence")],
            ["Scenario fingerprint", scenario.get("scenario_fingerprint")],
        ],
        widths=[2.2, 5.0],
    )

    _docx_heading(doc, "5. Applied Change Register")
    if data["changes"]:
        _docx_table(
            doc,
            ["Activity / Link", "Field", "Before", "After", "Recovery d", "Risk", "Reason"],
            [
                [
                    change["activity_id"] or f"{change['predecessor_id']}->{change['successor_id']}",
                    change["field"].replace("_", " ").title(),
                    change["before"],
                    change["after"],
                    change["calculated_recovery_days"],
                    change["risk"],
                    change["reason"],
                ]
                for change in data["changes"][:150]
            ],
            widths=[1.0, 0.8, 0.8, 0.8, 0.7, 0.6, 2.5],
        )
    else:
        doc.add_paragraph("No changes are recorded on this schedule clone.")

    _docx_heading(doc, "6. Controlling and Driving Paths")
    if data["driving_paths"]:
        _docx_table(
            doc,
            ["Path", "Duration d", "Activity Chain"],
            [[path["path_number"], path["duration"], " -> ".join(path["activity_ids"])] for path in data["driving_paths"]],
            widths=[0.6, 1.0, 5.6],
        )
    else:
        doc.add_paragraph("No controlling path was identified.")

    _docx_heading(doc, "7. Critical and Near-Critical Work")
    if data["critical"]:
        _docx_heading(doc, "7.1 Critical Activities", level=2)
        _docx_table(
            doc,
            ["ID", "Activity", "RD d", "ES", "EF", "TF", "Drag", "Forecast Finish"],
            [[item["id"], item["name"], item["duration"], item["es"], item["ef"], item["tf"], item["path_drag"], item["forecast_finish"]] for item in data["critical"]],
            widths=[0.75, 2.65, 0.55, 0.55, 0.55, 0.55, 0.55, 1.1],
        )
    if data["near_critical"]:
        _docx_heading(doc, "7.2 Near-Critical Activities (TF <= 5 days)", level=2)
        _docx_table(
            doc,
            ["ID", "Activity", "RD d", "TF", "Forecast Finish"],
            [[item["id"], item["name"], item["duration"], item["tf"], item["forecast_finish"]] for item in data["near_critical"]],
            widths=[0.85, 3.55, 0.65, 0.65, 1.4],
        )

    _docx_heading(doc, "8. Constraints")
    if data["constraints"]:
        _docx_table(
            doc,
            ["ID", "Activity", "Constraint 1", "Date 1", "Constraint 2", "Date 2", "TF"],
            [[item["id"], item["name"], item["constraint_1"], item["date_1"], item["constraint_2"], item["date_2"], item["tf"]] for item in data["constraints"]],
            widths=[0.75, 2.4, 1.1, 0.9, 1.1, 0.9, 0.55],
        )
    else:
        doc.add_paragraph("No explicit activity constraints were identified in the imported schedule model.")

    _docx_heading(doc, "9. Schedule Quality Review")
    doc.add_paragraph(
        f"Final QA score: {_fmt(data['final']['qa_score'])} ({data['final']['qa_grade'] or '-'}) - "
        f"{data['final']['qa_errors']} error(s), {data['final']['qa_warnings']} warning(s)."
    )
    if data["qa_issues"]:
        _docx_table(
            doc,
            ["Severity", "Category", "Check", "Activity", "Finding", "Recommended Review"],
            [[issue.get("severity"), issue.get("category"), issue.get("type"), issue.get("activity_id", ""), issue.get("detail", ""), issue.get("recommendation", "")] for issue in data["qa_issues"][:150]],
            widths=[0.6, 0.75, 1.1, 0.8, 2.0, 2.1],
        )
    else:
        doc.add_paragraph("No schedule-quality issues were returned by the configured screening checks.")

    _docx_heading(doc, "10. Recovery Audit Trail")
    if data["action_log"]:
        _docx_table(
            doc,
            ["Seq", "Time", "Stage", "Action / Decision", "Event Hash"],
            [[event.get("sequence"), event.get("time"), event.get("stage"), event.get("message"), event.get("event_hash")] for event in data["action_log"]],
            widths=[0.45, 1.15, 1.05, 3.25, 1.5],
        )
    else:
        doc.add_paragraph("No action-log entries were available.")

    _docx_heading(doc, "11. XER Export Integrity")
    if data.get("xer_integrity_manifest"):
        _docx_table(
            doc,
            ["Integrity Check", "Value"],
            [[key, value] for key, value in data["xer_integrity_manifest"].items()],
            widths=[2.4, 4.8],
        )
    else:
        doc.add_paragraph("No XER integrity manifest applies to this source format.")

    _docx_heading(doc, "12. Assumptions, Risks and Limitations")
    for limitation in data["limitations"]:
        doc.add_paragraph(limitation, style="List Bullet")

    _docx_heading(doc, "13. Planner Acceptance")
    doc.add_paragraph(
        "Workflow status: " + ("Accepted in the application workflow." if data["accepted"] else "Not accepted in the application workflow.")
    )
    doc.add_paragraph("Planner / Reviewer: _________________________________________________")
    doc.add_paragraph("Date: ____________________    Signature: ______________________________")
    doc.add_paragraph("Organization approval reference: _____________________________________")

    bio = BytesIO()
    doc.save(bio)
    return bio.getvalue()


def _pdf_safe(value: Any) -> str:
    return escape(_fmt(value)).replace("\n", "<br/>")


def build_pdf_bytes(data: Dict[str, Any]) -> bytes:
    bio = BytesIO()
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(
        name="PRI50Title",
        parent=styles["Title"],
        fontName="Helvetica-Bold",
        fontSize=18,
        leading=22,
        textColor=colors.HexColor("#17365D"),
        alignment=TA_CENTER,
        spaceAfter=8,
    ))
    styles.add(ParagraphStyle(
        name="PRI50Subtitle",
        parent=styles["BodyText"],
        fontName="Helvetica-Bold",
        fontSize=11,
        leading=14,
        textColor=colors.HexColor("#2F75B5"),
        alignment=TA_CENTER,
        spaceAfter=6,
    ))
    styles.add(ParagraphStyle(
        name="PRI50Small",
        parent=styles["BodyText"],
        fontSize=7.2,
        leading=8.8,
        splitLongWords=True,
    ))
    styles.add(ParagraphStyle(
        name="PRI50Body",
        parent=styles["BodyText"],
        fontSize=9,
        leading=12,
        spaceAfter=5,
    ))
    styles.add(ParagraphStyle(
        name="PRI50H1",
        parent=styles["Heading1"],
        fontName="Helvetica-Bold",
        fontSize=12.5,
        leading=15,
        textColor=colors.HexColor("#17365D"),
        spaceBefore=9,
        spaceAfter=5,
        keepWithNext=True,
    ))

    def footer(canvas, document):
        canvas.saveState()
        canvas.setFont("Helvetica", 7)
        canvas.setFillColor(colors.HexColor("#666666"))
        canvas.drawString(14 * mm, 8 * mm, f"{ENGINE_ID} | {_fmt(data['project']['id'])}")
        canvas.drawRightString(A4[0] - 14 * mm, 8 * mm, f"Page {document.page}")
        canvas.restoreState()

    doc = SimpleDocTemplate(
        bio,
        pagesize=A4,
        leftMargin=13 * mm,
        rightMargin=13 * mm,
        topMargin=14 * mm,
        bottomMargin=14 * mm,
        title=data["title"],
        author=REPORT_AUTHOR,
        subject="Deterministic schedule recovery, QA and audit report",
    )
    story: List[Any] = []

    def paragraph(value: Any, style="PRI50Body"):
        return Paragraph(_pdf_safe(value), styles[style])

    def heading(value: str):
        story.append(Paragraph(escape(value), styles["PRI50H1"]))

    def table(headers: Sequence[str], rows: Sequence[Sequence[Any]], widths: Optional[Sequence[float]] = None):
        cooked = [[Paragraph(escape(str(header)), styles["PRI50Small"]) for header in headers]]
        for row in rows:
            cooked.append([Paragraph(_pdf_safe(value), styles["PRI50Small"]) for value in row])
        tbl = LongTable(cooked, colWidths=widths, repeatRows=1, hAlign="LEFT", splitByRow=True)
        tbl.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#17365D")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("LINEBELOW", (0, 0), (-1, 0), 0.8, colors.HexColor("#17365D")),
            ("LINEBELOW", (0, 1), (-1, -1), 0.25, colors.HexColor("#D9E1F2")),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("LEFTPADDING", (0, 0), (-1, -1), 4),
            ("RIGHTPADDING", (0, 0), (-1, -1), 4),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]))
        story.append(tbl)
        story.append(Spacer(1, 6))

    story.append(Spacer(1, 18 * mm))
    story.append(Paragraph("PRIMAVERA RECOVERY INTELLIGENCE", styles["PRI50Title"]))
    story.append(Paragraph("10X Planning Intelligence Studio - Recovery Schedule Analysis and Audit Report", styles["PRI50Subtitle"]))
    story.append(Spacer(1, 8 * mm))
    story.append(Paragraph(f"<b>{_pdf_safe(data['project']['name'])}</b>", styles["PRI50Subtitle"]))
    story.append(Paragraph(
        f"Project ID: {_pdf_safe(data['project']['id'])}<br/>Data Date: {_pdf_safe(data['project']['data_date'])}<br/>Generated: {_pdf_safe(data['generated_at'])}",
        styles["PRI50Body"],
    ))
    story.append(Spacer(1, 5 * mm))
    status_color = "#548235" if data["accepted"] else "#C0504D"
    story.append(Paragraph(
        f"<font color='{status_color}'><b>{'ACCEPTED RECOVERY RESULT' if data['accepted'] else 'DRAFT - NOT ACCEPTED'}</b></font>",
        styles["PRI50Subtitle"],
    ))
    story.append(PageBreak())

    heading("1. Executive Decision Summary")
    table(
        ["Metric", "Working Basis", "Recovered / Reviewed Clone"],
        [
            ["Forecast finish", data["baseline"]["forecast_finish"], data["final"]["forecast_finish"]],
            ["Finish offset (working days)", data["baseline"]["finish_offset"], data["final"]["finish_offset"]],
            ["Critical activities", data["baseline"]["critical_count"], data["final"]["critical_count"]],
            ["Schedule QA", f"{_fmt(data['baseline']['qa_score'])} / {data['baseline']['qa_grade'] or '-'}", f"{_fmt(data['final']['qa_score'])} / {data['final']['qa_grade'] or '-'}"],
            ["Recovery target", "-", data["target_recovery_days"] or "Not set"],
            ["Recovery achieved", "-", data["recovery_days"]],
            ["Residual target gap", "-", data["residual_gap_days"]],
            ["Target achieved", "-", "YES" if data["target_met"] else ("NO" if data["target_recovery_days"] else "N/A")],
            ["Audit chain", "-", "VALID" if data["audit_verification"].get("valid") else "INVALID"],
        ],
        [61 * mm, 49 * mm, 58 * mm],
    )

    heading("2. Control and Integrity Record")
    table(
        ["Control", "Value"],
        [
            ["Engine", data["engine"]],
            ["Import format", data["project"]["import_format"]],
            ["Scheduling mode", data["project"]["scheduling_mode"]],
            ["Working-basis fingerprint", data["baseline"]["fingerprint"]],
            ["Final schedule fingerprint", data["final"]["fingerprint"]],
            ["Acceptance fingerprint", data.get("acceptance_fingerprint")],
            ["Audit events", data["audit_verification"].get("count")],
            ["Audit head hash", data["audit_verification"].get("head_hash")],
        ],
        [53 * mm, 115 * mm],
    )

    heading("3. Recovery Basis and Planner Decisions")
    if data["decisions"]:
        table(["Recovery Gate", "Decision"], [[key, value] for key, value in data["decisions"].items()], [58 * mm, 110 * mm])
    else:
        story.append(paragraph("No interactive recovery decisions were recorded in this report context."))

    heading("4. Selected Recovery Scenario")
    scenario = data.get("scenario") or {}
    table(
        ["Parameter", "Value"],
        [
            ["Scenario ID", scenario.get("id")],
            ["Scenario type", scenario.get("type")],
            ["Strategy", scenario.get("strategy")],
            ["Calculated recovery", scenario.get("recovery_days", data["recovery_days"])],
            ["Change count", scenario.get("change_count", len(data["changes"]))],
            ["Risk", scenario.get("risk")],
            ["Confidence", scenario.get("confidence")],
            ["Scenario fingerprint", scenario.get("scenario_fingerprint")],
        ],
        [50 * mm, 118 * mm],
    )

    heading("5. Applied Change Register")
    if data["changes"]:
        table(
            ["Activity / Link", "Field", "Before", "After", "Rec. d", "Risk", "Reason"],
            [[
                change["activity_id"] or f"{change['predecessor_id']}->{change['successor_id']}",
                change["field"], change["before"], change["after"], change["calculated_recovery_days"], change["risk"], change["reason"],
            ] for change in data["changes"][:150]],
            [20 * mm, 20 * mm, 22 * mm, 22 * mm, 14 * mm, 14 * mm, 56 * mm],
        )
    else:
        story.append(paragraph("No changes are recorded on this schedule clone."))

    heading("6. Controlling and Driving Paths")
    if data["driving_paths"]:
        table(
            ["Path", "Duration d", "Activity Chain"],
            [[path["path_number"], path["duration"], " -> ".join(path["activity_ids"])] for path in data["driving_paths"]],
            [15 * mm, 25 * mm, 128 * mm],
        )

    heading("7. Critical and Near-Critical Work")
    if data["critical"]:
        table(
            ["ID", "Activity", "RD d", "ES", "EF", "TF", "Drag", "Forecast Finish"],
            [[item["id"], item["name"], item["duration"], item["es"], item["ef"], item["tf"], item["path_drag"], item["forecast_finish"]] for item in data["critical"]],
            [18 * mm, 56 * mm, 14 * mm, 13 * mm, 13 * mm, 13 * mm, 14 * mm, 27 * mm],
        )
    if data["near_critical"]:
        table(
            ["ID", "Activity", "RD d", "TF", "Forecast Finish"],
            [[item["id"], item["name"], item["duration"], item["tf"], item["forecast_finish"]] for item in data["near_critical"]],
            [22 * mm, 84 * mm, 18 * mm, 18 * mm, 26 * mm],
        )

    heading("8. Constraints")
    if data["constraints"]:
        table(
            ["ID", "Activity", "Constraint 1", "Date 1", "Constraint 2", "Date 2", "TF"],
            [[item["id"], item["name"], item["constraint_1"], item["date_1"], item["constraint_2"], item["date_2"], item["tf"]] for item in data["constraints"]],
            [18 * mm, 50 * mm, 25 * mm, 21 * mm, 25 * mm, 21 * mm, 12 * mm],
        )
    else:
        story.append(paragraph("No explicit activity constraints were identified in the imported schedule model."))

    heading("9. Schedule Quality Review")
    story.append(paragraph(
        f"Final QA score: {_fmt(data['final']['qa_score'])} ({data['final']['qa_grade'] or '-'}) - "
        f"{data['final']['qa_errors']} error(s), {data['final']['qa_warnings']} warning(s)."
    ))
    if data["qa_issues"]:
        table(
            ["Severity", "Category", "Check", "Activity", "Finding", "Recommended Review"],
            [[issue.get("severity"), issue.get("category"), issue.get("type"), issue.get("activity_id", ""), issue.get("detail", ""), issue.get("recommendation", "")] for issue in data["qa_issues"][:150]],
            [15 * mm, 19 * mm, 30 * mm, 20 * mm, 42 * mm, 42 * mm],
        )

    heading("10. Recovery Audit Trail")
    if data["action_log"]:
        table(
            ["Seq", "Time", "Stage", "Action / Decision", "Event Hash"],
            [[event.get("sequence"), event.get("time"), event.get("stage"), event.get("message"), event.get("event_hash")] for event in data["action_log"]],
            [10 * mm, 32 * mm, 28 * mm, 66 * mm, 32 * mm],
        )

    heading("11. XER Export Integrity")
    if data.get("xer_integrity_manifest"):
        table(
            ["Integrity Check", "Value"],
            [[key, value] for key, value in data["xer_integrity_manifest"].items()],
            [52 * mm, 116 * mm],
        )
    else:
        story.append(paragraph("No XER integrity manifest applies to this source format."))

    heading("12. Assumptions, Risks and Limitations")
    for limitation in data["limitations"]:
        story.append(Paragraph("- " + _pdf_safe(limitation), styles["PRI50Body"]))

    heading("13. Planner Acceptance")
    story.append(paragraph(
        "Workflow status: " + ("Accepted in the application workflow." if data["accepted"] else "Not accepted in the application workflow.")
    ))
    story.append(Spacer(1, 6))
    story.append(paragraph("Planner / Reviewer: _________________________________________________"))
    story.append(paragraph("Date: ____________________    Signature: ______________________________"))
    story.append(paragraph("Organization approval reference: _____________________________________"))

    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    return bio.getvalue()
