from __future__ import annotations

from datetime import datetime
from io import BytesIO
from typing import Any, Dict, Iterable, List, Optional, Sequence

from openpyxl import Workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.formatting.rule import CellIsRule, FormulaRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo

from .cpm import calculate_cpm, relationship_slack
from .integrity import schedule_fingerprint, verify_audit_chain
from .models import ProjectSchedule
from .qa import schedule_quality
from .utils import spreadsheet_safe
from .version import ENGINE_ID


_NAVY = "17365D"
_BLUE = "2F75B5"
_TEAL = "0F6B78"
_GREEN = "548235"
_LIGHT_GREEN = "E2F0D9"
_LIGHT_BLUE = "D9EAF7"
_LIGHT_TEAL = "DDEBF7"
_ORANGE = "F4B183"
_LIGHT_ORANGE = "FCE4D6"
_LIGHT_RED = "F4CCCC"
_PURPLE = "7030A0"
_GRAY = "E7E6E6"
_WHITE = "FFFFFF"
_BLACK = "000000"
_IMPORTED_GREEN = "008000"
_STATIC_GRAY = "666666"

_THIN_GRAY = Side(style="thin", color="D9E1F2")


def _excel_value(value: Any) -> Any:
    if isinstance(value, datetime):
        return value
    if value is None:
        return ""
    if isinstance(value, bool):
        return "YES" if value else "NO"
    if isinstance(value, (dict, list, tuple, set)):
        import json
        return spreadsheet_safe(json.dumps(value, ensure_ascii=False, default=str, sort_keys=True))
    return spreadsheet_safe(value)


def _fmt_date(cell) -> None:
    if isinstance(cell.value, datetime):
        cell.number_format = "yyyy-mm-dd hh:mm"


def _set_sheet_defaults(ws) -> None:
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.page_margins.left = 0.25
    ws.page_margins.right = 0.25
    ws.page_margins.top = 0.5
    ws.page_margins.bottom = 0.5


def _write_table(
    ws,
    headers: Sequence[str],
    rows: Iterable[Sequence[Any]],
    *,
    table_name: str,
    widths: Optional[Dict[str, float]] = None,
    imported_columns: Optional[set[int]] = None,
    formula_columns: Optional[set[int]] = None,
    caution_columns: Optional[set[int]] = None,
) -> int:
    imported_columns = imported_columns or set()
    formula_columns = formula_columns or set()
    caution_columns = caution_columns or set()
    ws.append(list(headers))
    for index, header in enumerate(headers, start=1):
        cell = ws.cell(1, index)
        cell.fill = PatternFill("solid", fgColor=_NAVY)
        cell.font = Font(color=_WHITE, bold=True, size=10)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.row_dimensions[1].height = 30

    count = 0
    for raw_row in rows:
        count += 1
        row_index = count + 1
        for col_index, value in enumerate(raw_row, start=1):
            cell = ws.cell(row_index, col_index, _excel_value(value))
            cell.alignment = Alignment(vertical="center", wrap_text=True)
            cell.border = Border(bottom=_THIN_GRAY)
            _fmt_date(cell)
            if col_index in imported_columns:
                cell.font = Font(color=_IMPORTED_GREEN)
            elif col_index in formula_columns:
                cell.font = Font(color=_BLACK)
            elif col_index in caution_columns:
                cell.fill = PatternFill("solid", fgColor=_LIGHT_ORANGE)
        ws.row_dimensions[row_index].height = 20

    end_row = max(2, count + 1)
    end_col = max(1, len(headers))
    if count:
        ref = f"A1:{get_column_letter(end_col)}{end_row}"
        table = Table(displayName=table_name, ref=ref)
        table.tableStyleInfo = TableStyleInfo(
            name="TableStyleMedium2",
            showFirstColumn=False,
            showLastColumn=False,
            showRowStripes=False,
            showColumnStripes=False,
        )
        ws.add_table(table)
    _set_sheet_defaults(ws)

    for idx, header in enumerate(headers, start=1):
        letter = get_column_letter(idx)
        preferred = widths.get(header) if widths else None
        if preferred:
            ws.column_dimensions[letter].width = preferred
            continue
        max_length = len(str(header))
        for cell in ws[letter][1 : min(end_row, 501)]:
            max_length = max(max_length, len(str(cell.value or "")))
        ws.column_dimensions[letter].width = min(max(max_length + 2, 11), 48)
    return count


def _summary_sheet(wb: Workbook, schedule: ProjectSchedule, calc: Dict[str, Any], qa: Dict[str, Any], audit_log: List[Dict[str, Any]]) -> None:
    ws = wb.active
    ws.title = "Executive Summary"
    ws.sheet_view.showGridLines = False
    ws.merge_cells("A1:F1")
    ws["A1"] = "PRIMAVERA PLANNING & RECOVERY INTELLIGENCE 10X"
    ws["A1"].font = Font(size=18, bold=True, color=_WHITE)
    ws["A1"].fill = PatternFill("solid", fgColor=_NAVY)
    ws["A1"].alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[1].height = 34

    ws.merge_cells("A2:F2")
    ws["A2"] = f"{schedule.project_id} - {schedule.project_name}"
    ws["A2"].font = Font(size=13, bold=True, color=_NAVY)
    ws["A2"].alignment = Alignment(vertical="center")
    ws.row_dimensions[2].height = 26

    audit = verify_audit_chain(audit_log)
    forecast_finish = max((a.forecast_finish for a in schedule.activities.values() if a.forecast_finish), default=None)
    metrics = [
        ("Engine", ENGINE_ID, "STATIC"),
        ("Project ID", schedule.project_id, "IMPORTED"),
        ("Project Name", schedule.project_name, "IMPORTED"),
        ("Data Date", schedule.data_date, "IMPORTED"),
        ("Forecast Finish", forecast_finish, "CALCULATED"),
        ("Finish Offset (working days)", calc.get("project_finish_offset_days", 0), "CALCULATED"),
        ("Activities", len(schedule.activities), "CALCULATED"),
        ("Relationships", len(schedule.relationships), "CALCULATED"),
        ("Critical Activities", len(calc.get("critical_activity_ids", [])), "CALCULATED"),
        ("Driving Paths", len(calc.get("critical_paths", [])), "CALCULATED"),
        ("QA Score", qa.get("score", 0), "CALCULATED"),
        ("QA Grade", qa.get("grade", ""), "CALCULATED"),
        ("QA Errors", qa.get("errors", 0), "CALCULATED"),
        ("QA Warnings", qa.get("warnings", 0), "CALCULATED"),
        ("Schedule Fingerprint", schedule_fingerprint(schedule), "CONTROL"),
        ("Audit Chain", "VALID" if audit.get("valid") else "INVALID", "CONTROL"),
        ("Audit Events", audit.get("count", 0), "CONTROL"),
    ]

    start = 4
    for row_offset, (label, value, kind) in enumerate(metrics):
        row = start + row_offset
        ws.cell(row, 1, label)
        ws.cell(row, 2, _excel_value(value))
        ws.cell(row, 1).font = Font(bold=True, color=_STATIC_GRAY)
        ws.cell(row, 1).fill = PatternFill("solid", fgColor=_GRAY)
        ws.cell(row, 2).alignment = Alignment(wrap_text=True, vertical="center")
        _fmt_date(ws.cell(row, 2))
        if kind == "IMPORTED":
            ws.cell(row, 2).font = Font(color=_IMPORTED_GREEN)
        elif kind == "CONTROL":
            ws.cell(row, 2).font = Font(color=_PURPLE)
        else:
            ws.cell(row, 2).font = Font(color=_BLACK)
        ws.cell(row, 1).border = ws.cell(row, 2).border = Border(bottom=_THIN_GRAY)

    ws["D4"] = "QA Severity"
    ws["D4"].fill = PatternFill("solid", fgColor=_TEAL)
    ws["D4"].font = Font(color=_WHITE, bold=True)
    ws["E4"] = "Count"
    ws["E4"].fill = PatternFill("solid", fgColor=_TEAL)
    ws["E4"].font = Font(color=_WHITE, bold=True)
    for idx, (label, key) in enumerate((("Errors", "errors"), ("Warnings", "warnings"), ("Information", "infos")), start=5):
        ws.cell(idx, 4, label)
        ws.cell(idx, 5, int(qa.get(key, 0) or 0))
    chart = BarChart()
    chart.type = "col"
    chart.style = 10
    chart.title = "Schedule QA Findings"
    chart.y_axis.title = "Issue Count"
    chart.x_axis.title = "Severity"
    chart.add_data(Reference(ws, min_col=5, min_row=4, max_row=7), titles_from_data=True)
    chart.set_categories(Reference(ws, min_col=4, min_row=5, max_row=7))
    chart.height = 7
    chart.width = 11
    ws.add_chart(chart, "D9")

    ws["D25"] = "Interpretation"
    ws["D25"].font = Font(bold=True, color=_WHITE)
    ws["D25"].fill = PatternFill("solid", fgColor=_NAVY)
    ws.merge_cells("D26:F30")
    ws["D26"] = (
        "Green text = imported schedule data; black = calculated values; purple = control or integrity fields; "
        "orange/red highlights = items requiring planner review. Recalculate and validate the accepted schedule in "
        "Primavera P6 before contractual issue."
    )
    ws["D26"].alignment = Alignment(wrap_text=True, vertical="top")
    ws["D26"].fill = PatternFill("solid", fgColor=_LIGHT_BLUE)

    ws.column_dimensions["A"].width = 31
    ws.column_dimensions["B"].width = 55
    ws.column_dimensions["C"].width = 3
    ws.column_dimensions["D"].width = 20
    ws.column_dimensions["E"].width = 16
    ws.column_dimensions["F"].width = 16
    ws.freeze_panes = "A4"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 1
    ws.sheet_properties.pageSetUpPr.fitToPage = True


def schedule_to_excel_bytes(
    schedule: ProjectSchedule,
    context: Optional[Dict[str, Any]] = None,
    action_log: Optional[List[Dict[str, Any]]] = None,
) -> bytes:
    """Build a styled, audit-ready schedule analysis workbook.

    Text originating from schedule files is protected against spreadsheet formula
    injection. Calculated fields are refreshed immediately before export.
    """
    context = dict(context or {})
    action_log = list(action_log or [])
    calc = calculate_cpm(schedule, compute_path_drag=True)
    qa = schedule_quality(schedule)

    wb = Workbook()
    wb.calculation.fullCalcOnLoad = True
    wb.calculation.forceFullCalc = True
    wb.calculation.calcMode = "auto"
    wb.properties.creator = ENGINE_ID
    wb.properties.title = f"{schedule.project_id} Schedule Analysis"
    wb.properties.subject = "Schedule QA, CPM, recovery changes and audit trail"
    wb.properties.description = "Generated by Primavera Planning & Recovery Intelligence 10X"

    _summary_sheet(wb, schedule, calc, qa, action_log)

    ws = wb.create_sheet("Activities")
    activity_headers = [
        "Activity ID", "Activity Name", "WBS ID", "WBS Name", "Status", "Type", "Calendar",
        "Original Duration (d)", "Remaining Duration (d)", "Percent Complete", "Actual Start", "Actual Finish",
        "Planned Start", "Planned Finish", "Constraint 1", "Constraint Date 1", "Constraint 2", "Constraint Date 2",
        "ES (d)", "EF (d)", "LS (d)", "LF (d)", "Total Float (d)", "Free Float (d)", "Critical",
        "Longest Path", "Path Drag (d)", "Driving Predecessor", "Forecast Start", "Forecast Finish", "Primary Resource",
    ]
    activity_rows = []
    for a in sorted(schedule.activities.values(), key=lambda item: (item.es, item.id)):
        activity_rows.append([
            a.id, a.name, a.wbs_id, schedule.wbs.get(a.wbs_id, ""), a.status, a.activity_type, a.calendar_id,
            a.original_duration, a.remaining_duration, a.percent_complete, a.actual_start, a.actual_finish,
            a.planned_start, a.planned_finish, a.constraint_type, a.constraint_date, a.constraint_type2, a.constraint_date2,
            a.es, a.ef, a.ls, a.lf, a.total_float, a.free_float, a.critical, a.longest_path, a.path_drag,
            a.driving_predecessor_id, a.forecast_start, a.forecast_finish, a.primary_resource_id,
        ])
    _write_table(
        ws,
        activity_headers,
        activity_rows,
        table_name="tblActivities",
        widths={"Activity ID": 18, "Activity Name": 42, "WBS Name": 30, "Status": 16, "Type": 18},
        imported_columns=set(range(1, 19)) | {31},
        formula_columns=set(range(19, 31)),
    )
    ws.conditional_formatting.add(
        f"W2:W{max(2, len(activity_rows)+1)}",
        CellIsRule(operator="lessThanOrEqual", formula=["0.01"], fill=PatternFill("solid", fgColor=_LIGHT_RED)),
    )
    ws.conditional_formatting.add(
        f"Y2:Y{max(2, len(activity_rows)+1)}",
        FormulaRule(formula=["$Y2=\"YES\""], fill=PatternFill("solid", fgColor=_LIGHT_RED)),
    )

    ws = wb.create_sheet("Relationships")
    rel_headers = [
        "Relationship ID", "Predecessor", "Successor", "Type", "Lag (d)", "Lag Calendar",
        "Relationship Slack (d)", "Driving", "Predecessor Name", "Successor Name",
    ]
    rel_rows = []
    for rel in sorted(schedule.relationships, key=lambda item: item.key):
        pred = schedule.activities.get(rel.predecessor_id)
        succ = schedule.activities.get(rel.successor_id)
        slack = relationship_slack(schedule, rel) if pred and succ else None
        rel_rows.append([
            rel.id, rel.predecessor_id, rel.successor_id, rel.rel_type, rel.lag, rel.lag_calendar_id,
            slack, bool(slack is not None and abs(slack) <= 1e-7), pred.name if pred else "", succ.name if succ else "",
        ])
    _write_table(
        ws, rel_headers, rel_rows, table_name="tblRelationships",
        widths={"Relationship ID": 18, "Predecessor Name": 34, "Successor Name": 34},
        imported_columns={1, 2, 3, 4, 5, 6, 9, 10}, formula_columns={7, 8},
    )

    ws = wb.create_sheet("Critical Paths")
    path_headers = ["Path Number", "Sequence", "Activity ID", "Activity Name", "Duration (d)", "Total Float (d)", "Path Drag (d)"]
    path_rows = []
    driving_paths = calc.get("critical_paths") or ([calc.get("longest_path_activity_ids", [])] if calc.get("longest_path_activity_ids") else [])
    for path_no, path in enumerate(driving_paths, start=1):
        for sequence, aid in enumerate(path, start=1):
            a = schedule.activities.get(aid)
            if a:
                path_rows.append([path_no, sequence, a.id, a.name, a.duration, a.total_float, a.path_drag])
    _write_table(
        ws, path_headers, path_rows, table_name="tblCriticalPaths",
        widths={"Activity ID": 18, "Activity Name": 44},
        imported_columns={3, 4, 5}, formula_columns={1, 2, 6, 7},
    )

    ws = wb.create_sheet("QA Issues")
    qa_headers = ["Severity", "Category", "Issue Type", "Activity ID", "Detail", "Recommendation"]
    qa_rows = [[
        issue.get("severity", ""), issue.get("category", ""), issue.get("type", ""), issue.get("activity_id", ""),
        issue.get("detail", ""), issue.get("recommendation", ""),
    ] for issue in qa.get("issues", [])]
    _write_table(
        ws, qa_headers, qa_rows, table_name="tblQAIssues",
        widths={"Severity": 12, "Category": 16, "Issue Type": 28, "Activity ID": 18, "Detail": 50, "Recommendation": 55},
        caution_columns={1},
    )
    ws.conditional_formatting.add(
        f"A2:A{max(2, len(qa_rows)+1)}",
        FormulaRule(formula=["$A2=\"ERROR\""], fill=PatternFill("solid", fgColor=_LIGHT_RED)),
    )
    ws.conditional_formatting.add(
        f"A2:A{max(2, len(qa_rows)+1)}",
        FormulaRule(formula=["$A2=\"WARN\""], fill=PatternFill("solid", fgColor=_LIGHT_ORANGE)),
    )

    ws = wb.create_sheet("Change Register")
    change_headers = [
        "Scenario ID", "Kind", "Activity ID", "Relationship ID", "Predecessor", "Successor", "Field", "Before", "After",
        "Calculated Recovery (d)", "Risk", "Approval Required", "Approved By", "Approved At", "Evidence Reference",
        "Reason", "Provenance Hash",
    ]
    change_rows = [[
        c.scenario_id, c.kind, c.activity_id, c.relationship_id, c.predecessor_id, c.successor_id, c.field, c.before, c.after,
        c.calculated_recovery_days, c.risk, c.requires_approval, c.approved_by, c.approved_at, c.evidence_ref,
        c.reason, c.provenance_hash,
    ] for c in schedule.changes]
    _write_table(
        ws, change_headers, change_rows, table_name="tblChangeRegister",
        widths={"Scenario ID": 22, "Activity ID": 18, "Before": 30, "After": 30, "Reason": 55, "Evidence Reference": 32, "Provenance Hash": 48},
        caution_columns={11, 12},
    )

    ws = wb.create_sheet("Calendars")
    calendar_headers = ["Calendar ID", "Calendar Name", "Working Weekdays", "Hours / Day", "Weekday Hours", "Non-working Exceptions", "Working Exceptions"]
    calendar_rows = [[
        cal.id, cal.name, ", ".join(str(x) for x in cal.working_weekdays), cal.hours_per_day,
        cal.hours_by_weekday, ", ".join(cal.non_working_dates), ", ".join(cal.working_dates),
    ] for cal in sorted(schedule.calendars.values(), key=lambda item: item.id)]
    _write_table(
        ws, calendar_headers, calendar_rows, table_name="tblCalendars",
        widths={"Calendar ID": 20, "Calendar Name": 34, "Working Weekdays": 22, "Weekday Hours": 35, "Non-working Exceptions": 55, "Working Exceptions": 55},
        imported_columns=set(range(1, 8)),
    )

    ws = wb.create_sheet("Audit Trail")
    audit_headers = ["Sequence", "Time (UTC)", "Stage", "Message", "Requires User Action", "Options", "Previous Hash", "Event Hash"]
    audit_rows = [[
        event.get("sequence", idx), event.get("time", ""), event.get("stage", ""), event.get("message", ""),
        event.get("requires_user_action", False), event.get("options", []), event.get("prev_hash", ""), event.get("event_hash", ""),
    ] for idx, event in enumerate(action_log, start=1)]
    _write_table(
        ws, audit_headers, audit_rows, table_name="tblAuditTrail",
        widths={"Time (UTC)": 24, "Stage": 22, "Message": 70, "Options": 35, "Previous Hash": 48, "Event Hash": 48},
        formula_columns={1}, caution_columns={5},
    )

    ws = wb.create_sheet("Metadata")
    metadata_headers = ["Key", "Value"]
    metadata_rows = [
        ["engine", ENGINE_ID],
        ["schedule_fingerprint", schedule_fingerprint(schedule)],
        ["import_format", schedule.metadata.get("import_format", "UNKNOWN")],
        ["scheduling_mode", schedule.metadata.get("scheduling_mode", "RETAINED_LOGIC")],
        ["source_sha256", schedule.metadata.get("source_sha256", "")],
        ["context", context],
    ] + [[f"metadata.{key}", value] for key, value in sorted(schedule.metadata.items()) if key not in {"raw_text", "source_bytes"}]
    _write_table(
        ws, metadata_headers, metadata_rows, table_name="tblMetadata",
        widths={"Key": 36, "Value": 95}, formula_columns={2},
    )

    # Use a consistent tab palette and active summary sheet.
    tab_colors = [_NAVY, _GREEN, _BLUE, _TEAL, _ORANGE, _PURPLE, _TEAL, _GRAY, _NAVY]
    for ws, tab_color in zip(wb.worksheets, tab_colors):
        ws.sheet_properties.tabColor = tab_color
    wb.active = 0

    bio = BytesIO()
    wb.save(bio)
    return bio.getvalue()
