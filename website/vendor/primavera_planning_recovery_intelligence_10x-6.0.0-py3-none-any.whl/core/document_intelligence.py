from __future__ import annotations

from dataclasses import dataclass, asdict, field
from io import BytesIO, StringIO
from pathlib import Path
import csv
import hashlib
import html
from html.parser import HTMLParser
import json
import re
from typing import Any, Dict, Iterable, List, Optional, Tuple
import zipfile
import xml.etree.ElementTree as ET

from docx import Document
from openpyxl import load_workbook
from pypdf import PdfReader
try:
    from pptx import Presentation
except Exception:  # pragma: no cover
    Presentation = None

from .utils import clean_text, safe_filename


MAX_TEXT_CHARS_PER_DOCUMENT = 2_000_000
MAX_TABLE_ROWS_PER_DOCUMENT = 20_000
MAX_ARCHIVE_FILES = 500
MAX_ARCHIVE_UNCOMPRESSED = 500 * 1024 * 1024


@dataclass
class ExtractedTable:
    name: str
    headers: List[str] = field(default_factory=list)
    rows: List[List[Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {"name": self.name, "headers": self.headers, "rows": self.rows}


@dataclass
class DocumentEvidence:
    filename: str
    extension: str
    media_family: str
    sha256: str
    size_bytes: int
    parser: str
    text: str = ""
    tables: List[ExtractedTable] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def text_characters(self) -> int:
        return len(self.text)

    def to_dict(self, *, include_text: bool = True, include_tables: bool = True) -> Dict[str, Any]:
        data = {
            "filename": self.filename,
            "extension": self.extension,
            "media_family": self.media_family,
            "sha256": self.sha256,
            "size_bytes": self.size_bytes,
            "parser": self.parser,
            "text_characters": self.text_characters,
            "warnings": list(self.warnings),
            "metadata": dict(self.metadata),
        }
        if include_text:
            data["text"] = self.text
        if include_tables:
            data["tables"] = [table.to_dict() for table in self.tables]
        return data


class _HTMLText(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts: List[str] = []

    def handle_data(self, data: str) -> None:
        text = data.strip()
        if text:
            self.parts.append(text)


def _text_limit(text: str) -> Tuple[str, Optional[str]]:
    if len(text) <= MAX_TEXT_CHARS_PER_DOCUMENT:
        return text, None
    return text[:MAX_TEXT_CHARS_PER_DOCUMENT], f"Text truncated at {MAX_TEXT_CHARS_PER_DOCUMENT:,} characters."


def _safe_string(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (str, int, float, bool)):
        return str(value)
    return clean_text(value, 10_000)


def _rows_to_table(name: str, rows: Iterable[Iterable[Any]]) -> Optional[ExtractedTable]:
    materialized = [list(r) for r in rows]
    materialized = [r for r in materialized if any(v not in (None, "") for v in r)]
    if not materialized:
        return None
    headers = [_safe_string(v) for v in materialized[0]]
    body = [[_safe_string(v) for v in row] for row in materialized[1 : MAX_TABLE_ROWS_PER_DOCUMENT + 1]]
    return ExtractedTable(name=name, headers=headers, rows=body)


def _parse_pdf(data: bytes) -> Tuple[str, List[ExtractedTable], List[str], Dict[str, Any]]:
    warnings: List[str] = []
    reader = PdfReader(BytesIO(data))
    parts: List[str] = []
    for idx, page in enumerate(reader.pages, start=1):
        try:
            text = page.extract_text() or ""
        except Exception as exc:
            text = ""
            warnings.append(f"Page {idx}: text extraction failed ({type(exc).__name__}).")
        if text.strip():
            parts.append(f"[PAGE {idx}]\n{text}")
    if not parts:
        warnings.append("No embedded PDF text was found. The PDF may be scanned/image-only; it remains catalogued as evidence.")
    meta = {"pages": len(reader.pages), "encrypted": bool(reader.is_encrypted)}
    return "\n\n".join(parts), [], warnings, meta


def _parse_docx(data: bytes) -> Tuple[str, List[ExtractedTable], List[str], Dict[str, Any]]:
    doc = Document(BytesIO(data))
    parts = [p.text for p in doc.paragraphs if p.text.strip()]
    tables: List[ExtractedTable] = []
    for i, table in enumerate(doc.tables, start=1):
        rows = [[cell.text for cell in row.cells] for row in table.rows]
        parsed = _rows_to_table(f"Table {i}", rows)
        if parsed:
            tables.append(parsed)
            parts.append(f"[TABLE {i}]\n" + "\n".join(" | ".join(map(str, r)) for r in rows[:200]))
    return "\n".join(parts), tables, [], {"paragraphs": len(doc.paragraphs), "tables": len(doc.tables)}


def _parse_xlsx(data: bytes) -> Tuple[str, List[ExtractedTable], List[str], Dict[str, Any]]:
    wb = load_workbook(BytesIO(data), read_only=True, data_only=False)
    tables: List[ExtractedTable] = []
    parts: List[str] = []
    total_rows = 0
    for ws in wb.worksheets:
        rows = [list(row) for row in ws.iter_rows(values_only=True)]
        parsed = _rows_to_table(ws.title, rows)
        if parsed:
            tables.append(parsed)
            total_rows += len(parsed.rows)
            parts.append(f"[SHEET {ws.title}]\n" + "\n".join(" | ".join(_safe_string(v) for v in r) for r in rows[:500]))
    return "\n\n".join(parts), tables, [], {"sheets": len(wb.worksheets), "rows_extracted": total_rows}


def _parse_csv(data: bytes, filename: str) -> Tuple[str, List[ExtractedTable], List[str], Dict[str, Any]]:
    text = data.decode("utf-8-sig", errors="replace")
    delimiter = "\t" if filename.lower().endswith(".tsv") else ","
    try:
        delimiter = csv.Sniffer().sniff(text[:8192], delimiters=",\t;|").delimiter
    except csv.Error:
        pass
    rows = list(csv.reader(StringIO(text), delimiter=delimiter))
    parsed = _rows_to_table(Path(filename).stem, rows)
    return text, [parsed] if parsed else [], [], {"delimiter": delimiter, "rows": max(0, len(rows) - 1)}


def _parse_pptx(data: bytes) -> Tuple[str, List[ExtractedTable], List[str], Dict[str, Any]]:
    if Presentation is None:
        return "", [], ["python-pptx is not installed; presentation is catalogued but text was not extracted."], {}
    prs = Presentation(BytesIO(data))
    parts: List[str] = []
    tables: List[ExtractedTable] = []
    for slide_idx, slide in enumerate(prs.slides, start=1):
        slide_text: List[str] = []
        for shape in slide.shapes:
            if getattr(shape, "has_text_frame", False):
                text = shape.text.strip()
                if text:
                    slide_text.append(text)
            if getattr(shape, "has_table", False):
                rows = [[cell.text for cell in row.cells] for row in shape.table.rows]
                parsed = _rows_to_table(f"Slide {slide_idx} Table", rows)
                if parsed:
                    tables.append(parsed)
        if slide_text:
            parts.append(f"[SLIDE {slide_idx}]\n" + "\n".join(slide_text))
    return "\n\n".join(parts), tables, [], {"slides": len(prs.slides)}


def _parse_html(data: bytes) -> Tuple[str, List[ExtractedTable], List[str], Dict[str, Any]]:
    raw = data.decode("utf-8-sig", errors="replace")
    parser = _HTMLText()
    parser.feed(raw)
    return "\n".join(parser.parts), [], [], {}


def _parse_xml(data: bytes) -> Tuple[str, List[ExtractedTable], List[str], Dict[str, Any]]:
    root = ET.fromstring(data)
    parts: List[str] = []
    count = 0
    for elem in root.iter():
        if elem.text and elem.text.strip():
            tag = elem.tag.split("}")[-1]
            parts.append(f"{tag}: {elem.text.strip()}")
            count += 1
            if count >= 100_000:
                break
    return "\n".join(parts), [], [], {"elements_with_text": count, "root": root.tag.split("}")[-1]}


def _parse_json(data: bytes) -> Tuple[str, List[ExtractedTable], List[str], Dict[str, Any]]:
    obj = json.loads(data.decode("utf-8-sig"))
    text = json.dumps(obj, indent=2, ensure_ascii=False, default=str)
    tables: List[ExtractedTable] = []
    if isinstance(obj, list) and obj and all(isinstance(x, dict) for x in obj[:50]):
        headers: List[str] = []
        for row in obj:
            for key in row:
                if key not in headers:
                    headers.append(str(key))
        rows = [[_safe_string(row.get(h)) for h in headers] for row in obj[:MAX_TABLE_ROWS_PER_DOCUMENT]]
        tables.append(ExtractedTable(name="JSON rows", headers=headers, rows=rows))
    return text, tables, [], {"json_type": type(obj).__name__}


def _parse_text(data: bytes) -> Tuple[str, List[ExtractedTable], List[str], Dict[str, Any]]:
    return data.decode("utf-8-sig", errors="replace"), [], [], {}


def extract_document(filename: str, data: bytes) -> DocumentEvidence:
    filename = safe_filename(filename or "document", "document")
    ext = Path(filename).suffix.lower()
    sha = hashlib.sha256(data).hexdigest()
    parser = "opaque"
    family = "binary"
    text = ""
    tables: List[ExtractedTable] = []
    warnings: List[str] = []
    metadata: Dict[str, Any] = {}

    try:
        if ext == ".pdf":
            parser, family = "pypdf", "pdf"
            text, tables, warnings, metadata = _parse_pdf(data)
        elif ext in {".docx"}:
            parser, family = "python-docx", "word"
            text, tables, warnings, metadata = _parse_docx(data)
        elif ext in {".xlsx", ".xlsm"}:
            parser, family = "openpyxl", "spreadsheet"
            text, tables, warnings, metadata = _parse_xlsx(data)
        elif ext in {".csv", ".tsv"}:
            parser, family = "csv", "table"
            text, tables, warnings, metadata = _parse_csv(data, filename)
        elif ext == ".pptx":
            parser, family = "python-pptx", "presentation"
            text, tables, warnings, metadata = _parse_pptx(data)
        elif ext in {".html", ".htm"}:
            parser, family = "html.parser", "markup"
            text, tables, warnings, metadata = _parse_html(data)
        elif ext == ".xml":
            parser, family = "ElementTree", "xml"
            text, tables, warnings, metadata = _parse_xml(data)
        elif ext == ".json":
            parser, family = "json", "structured"
            text, tables, warnings, metadata = _parse_json(data)
        elif ext in {".txt", ".md", ".log", ".ini", ".cfg", ".yaml", ".yml"}:
            parser, family = "text", "text"
            text, tables, warnings, metadata = _parse_text(data)
        elif ext in {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp"}:
            parser, family = "image-metadata", "image"
            warnings.append("Image accepted as evidence. OCR is not performed by the deterministic local parser; add an OCR service/provider if image text must drive schedule logic.")
        elif ext in {".xer", ".mpp", ".mpx", ".dwg", ".dxf", ".ifc", ".rvt", ".msg", ".eml"}:
            parser, family = "catalog", "specialized"
            # XER is intentionally catalogued here; schedule parsing is handled by the schedule import layer.
            warnings.append(f"{ext or 'File'} accepted as evidence. Deep extraction is delegated to its specialist import workflow when available.")
        else:
            warnings.append("Unrecognized format accepted as binary evidence; filename, size and SHA-256 are preserved.")
    except Exception as exc:
        warnings.append(f"Deep parser failed safely: {type(exc).__name__}: {clean_text(str(exc), 500)}")
        text = ""
        tables = []
        metadata = {"parser_error": type(exc).__name__}

    text, truncation = _text_limit(text)
    if truncation:
        warnings.append(truncation)
    return DocumentEvidence(
        filename=filename,
        extension=ext,
        media_family=family,
        sha256=sha,
        size_bytes=len(data),
        parser=parser,
        text=text,
        tables=tables,
        warnings=warnings,
        metadata=metadata,
    )


def extract_document_pack(files: Iterable[Tuple[str, bytes]]) -> List[DocumentEvidence]:
    results: List[DocumentEvidence] = []
    archive_files = 0
    archive_uncompressed = 0

    def add_one(name: str, payload: bytes, depth: int = 0) -> None:
        nonlocal archive_files, archive_uncompressed
        if len(results) >= MAX_ARCHIVE_FILES:
            return
        ext = Path(name).suffix.lower()
        if ext == ".zip" and depth < 3:
            try:
                with zipfile.ZipFile(BytesIO(payload)) as zf:
                    for info in zf.infolist():
                        if info.is_dir():
                            continue
                        archive_files += 1
                        archive_uncompressed += int(info.file_size)
                        if archive_files > MAX_ARCHIVE_FILES or archive_uncompressed > MAX_ARCHIVE_UNCOMPRESSED:
                            results.append(DocumentEvidence(
                                filename=safe_filename(name, "archive.zip"), extension=".zip", media_family="archive",
                                sha256=hashlib.sha256(payload).hexdigest(), size_bytes=len(payload), parser="zipfile",
                                warnings=["Archive expansion stopped at the safety limit."],
                                metadata={"archive_files_seen": archive_files, "archive_uncompressed_bytes": archive_uncompressed},
                            ))
                            return
                        child_name = safe_filename(Path(info.filename).name, f"item-{archive_files}")
                        try:
                            child = zf.read(info)
                        except Exception as exc:
                            results.append(DocumentEvidence(
                                filename=child_name, extension=Path(child_name).suffix.lower(), media_family="archive-item",
                                sha256="", size_bytes=int(info.file_size), parser="zipfile",
                                warnings=[f"Archive item could not be read: {type(exc).__name__}"],
                            ))
                            continue
                        add_one(child_name, child, depth + 1)
                return
            except zipfile.BadZipFile:
                pass
        results.append(extract_document(name, payload))

    for name, payload in files:
        add_one(name, payload)
    return results


def evidence_summary(documents: List[DocumentEvidence]) -> Dict[str, Any]:
    return {
        "document_count": len(documents),
        "total_bytes": sum(d.size_bytes for d in documents),
        "text_characters": sum(d.text_characters for d in documents),
        "table_count": sum(len(d.tables) for d in documents),
        "warning_count": sum(len(d.warnings) for d in documents),
        "formats": sorted({d.extension or "(none)" for d in documents}),
        "documents": [d.to_dict(include_text=False, include_tables=False) for d in documents],
    }
