from __future__ import annotations

from datetime import datetime, time, timedelta
from typing import Dict, Iterable, List

from .models import Calendar, ProjectSchedule
from .utils import finite_float


def _date_key(dt: datetime) -> str:
    return dt.date().isoformat()


def is_working_day(dt: datetime, calendar: Calendar) -> bool:
    key = _date_key(dt)
    if key in set(calendar.working_dates):
        return True
    if key in set(calendar.non_working_dates):
        return False
    return dt.weekday() in set(calendar.working_weekdays) and calendar.weekday_hours(dt.weekday()) > 0


def working_hours_on(dt: datetime, calendar: Calendar) -> float:
    return calendar.weekday_hours(dt.weekday()) if is_working_day(dt, calendar) else 0.0


def next_working_day(dt: datetime, calendar: Calendar, *, include_current: bool = True) -> datetime:
    cur = dt
    if not include_current:
        cur += timedelta(days=1)
    for _ in range(3700):
        if is_working_day(cur, calendar):
            return cur
        cur += timedelta(days=1)
    raise ValueError(f"Calendar {calendar.id} has no working day in search horizon")


def previous_working_day(dt: datetime, calendar: Calendar, *, include_current: bool = True) -> datetime:
    cur = dt
    if not include_current:
        cur -= timedelta(days=1)
    for _ in range(3700):
        if is_working_day(cur, calendar):
            return cur
        cur -= timedelta(days=1)
    raise ValueError(f"Calendar {calendar.id} has no working day in search horizon")


def add_workdays(start: datetime, days: float, calendar: Calendar) -> datetime:
    """Add signed working-day units while honoring weekdays and exceptions.

    A working-day unit is based on ``calendar.hours_per_day``. Whole units move
    between working dates; fractional units are represented as clock hours on a
    valid working date. This deliberately avoids pretending to be a full P6
    shift-level calendar implementation.
    """
    amount = finite_float(days, 0.0, field="days")
    if abs(amount) <= 1e-12:
        return start

    direction = 1 if amount > 0 else -1
    magnitude = abs(amount)
    whole = int(magnitude)
    fraction = magnitude - whole
    cur = start

    if whole:
        # Fast path for stable weekly calendars. Moving exactly seven calendar
        # days from any date crosses one complete weekly work pattern, so large
        # CPM offsets can be converted in O(1) weeks plus at most six day probes.
        # Exception calendars intentionally retain the exact day-by-day path.
        stable_week = not calendar.working_dates and not calendar.non_working_dates
        weekly_workdays = [
            weekday for weekday in range(7)
            if weekday in calendar.working_weekdays and calendar.weekday_hours(weekday) > 0
        ]
        counted = 0
        if stable_week and weekly_workdays:
            # Leave the final weekly block for exact day stepping. A direct
            # N/working-days-per-week jump can land on a weekend even though
            # the Nth working day occurred earlier in that calendar week.
            full_weeks = (whole - 1) // len(weekly_workdays)
            if full_weeks:
                cur += timedelta(days=direction * 7 * full_weeks)
                counted = full_weeks * len(weekly_workdays)
        while counted < whole:
            cur += timedelta(days=direction)
            if is_working_day(cur, calendar):
                counted += 1

    if fraction:
        if not is_working_day(cur, calendar):
            cur = (
                next_working_day(cur, calendar, include_current=False)
                if direction > 0
                else previous_working_day(cur, calendar, include_current=False)
            )
        cur += timedelta(hours=direction * fraction * calendar.hours_per_day)
    return cur


def workdays_between(start: datetime, end: datetime, calendar: Calendar) -> float:
    """Return a signed working-day difference suitable for constraint offsets."""
    if start == end:
        return 0.0
    if end < start:
        return -workdays_between(end, start, calendar)

    # Same-day fractions are useful for timestamped constraints.
    if start.date() == end.date():
        if not is_working_day(start, calendar):
            return 0.0
        return (end - start).total_seconds() / 3600.0 / calendar.hours_per_day

    count = 0.0
    cur_date = start.date()
    end_date = end.date()
    while cur_date < end_date:
        cur_date += timedelta(days=1)
        probe = datetime.combine(cur_date, start.time())
        if is_working_day(probe, calendar):
            count += 1.0

    # Add the relative time-of-day difference on the destination working day.
    if is_working_day(end, calendar):
        start_seconds = (start.hour * 3600 + start.minute * 60 + start.second + start.microsecond / 1_000_000)
        end_seconds = (end.hour * 3600 + end.minute * 60 + end.second + end.microsecond / 1_000_000)
        count += (end_seconds - start_seconds) / 3600.0 / calendar.hours_per_day
    return count


def forecast_activity_dates(schedule: ProjectSchedule, anchor: datetime | None = None) -> Dict[str, Dict[str, datetime]]:
    anchor = anchor or schedule.data_date or datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    result: Dict[str, Dict[str, datetime]] = {}
    for aid, activity in schedule.activities.items():
        calendar = schedule.get_calendar(activity.calendar_id)
        start = add_workdays(anchor, activity.es, calendar)
        finish = add_workdays(anchor, activity.ef, calendar)
        activity.forecast_start = start
        activity.forecast_finish = finish
        result[aid] = {"start": start, "finish": finish}
    return result


def infer_working_weekdays(day_hours: float, week_hours: float, fallback: Iterable[int] = (0, 1, 2, 3, 4)) -> List[int]:
    day = finite_float(day_hours, 0.0)
    week = finite_float(week_hours, 0.0)
    if day <= 0 or week <= 0:
        return list(fallback)
    count = max(1, min(7, int(round(week / day))))
    # Conservative regional-neutral inference: Monday onward. The source XER
    # work-pattern blob is still preserved and parity is explicitly reported.
    return list(range(count))


def calendar_summary(calendar: Calendar) -> Dict[str, object]:
    return {
        "id": calendar.id,
        "name": calendar.name,
        "working_weekdays": list(calendar.working_weekdays),
        "hours_per_day": calendar.hours_per_day,
        "working_days_per_week": len(calendar.working_weekdays),
        "non_working_exception_count": len(calendar.non_working_dates),
        "working_exception_count": len(calendar.working_dates),
    }
