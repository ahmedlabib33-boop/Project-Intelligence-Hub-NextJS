from __future__ import annotations

"""Command-line interface for Primavera Planning & Recovery Intelligence 10X.

The CLI intentionally uses the same deterministic engine, validation and package
builders as the web application. It never auto-accepts a recovery result.
"""

import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys
from typing import Any, Dict, Iterable, Optional
import zipfile

from core.cpm import calculate_cpm
from core.errors import ScheduleError, ScenarioValidationError
from core.exporter import schedule_to_excel_bytes
from core.integrity import append_audit_event, schedule_fingerprint, verify_audit_chain
from core.models import ProjectSchedule
from core.package_export import build_final_recovery_package
from core.qa import schedule_quality
from core.recovery import apply_scenario, generate_recovery_scenarios
from core.utils import safe_filename, utc_now_iso
from core.version import ENGINE_ID, VERSION
from core.xer import parse_xer_bytes
from core.schedule_import import parse_csv_schedule_bytes, parse_xlsx_schedule_bytes, parse_xml_schedule_bytes
from core.document_intelligence import extract_document_pack, evidence_summary
from core.tender_builder import build_tender_schedule
from core.schedule_doctor import build_repair_plan, apply_repairs
from core.data_vault import build_schedule_data_vault
from core.report_studio import load_report_data, render_template


def _json_bytes(value: Any) -> bytes:
    return json.dumps(value, indent=2, ensure_ascii=False, sort_keys=True, default=str).encode("utf-8") + b"\n"


def _write(path: Optional[str], payload: bytes) -> None:
    if not path:
        return
    target = Path(path).expanduser().resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(payload)


def _load_schedule(path: str, *, hours_per_day: float = 8.0, project_id: str = "") -> ProjectSchedule:
    source = Path(path).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(f"Input file not found: {source}")
    data = source.read_bytes()
    suffix = source.suffix.lower()
    if suffix == ".xer":
        schedule = parse_xer_bytes(data, default_hours_per_day=hours_per_day, project_id=project_id or None)
    elif suffix == ".json":
        try:
            schedule = ProjectSchedule.from_dict(json.loads(data.decode("utf-8-sig")))
        except UnicodeDecodeError as exc:
            raise ValueError("JSON must be UTF-8 text") from exc
        schedule.metadata["import_format"] = "JSON"
        schedule.metadata["source_json_size_bytes"] = len(data)
        schedule.metadata["source_filename"] = safe_filename(source.name)
    elif suffix in {".xlsx", ".xlsm"}:
        schedule = parse_xlsx_schedule_bytes(data, filename=source.name)
    elif suffix in {".csv", ".tsv"}:
        schedule = parse_csv_schedule_bytes(data, filename=source.name)
    elif suffix == ".xml":
        schedule = parse_xml_schedule_bytes(data, filename=source.name)
    else:
        raise ValueError("Supported schedule inputs are .xer, .json, .xlsx, .xlsm, .csv, .tsv and .xml")
    try:
        calculate_cpm(schedule)
    except ScheduleError as exc:
        schedule.metadata["cpm_import_error"] = str(exc)
    return schedule


def _summary(schedule: ProjectSchedule) -> Dict[str, Any]:
    calc = calculate_cpm(schedule, compute_path_drag=True)
    qa = schedule_quality(schedule)
    forecast = max(
        (activity.forecast_finish for activity in schedule.activities.values() if activity.forecast_finish),
        default=None,
    )
    return {
        "engine": ENGINE_ID,
        "project_id": schedule.project_id,
        "project_name": schedule.project_name,
        "data_date": schedule.data_date.isoformat() if schedule.data_date else None,
        "forecast_finish": forecast.isoformat() if forecast else None,
        "finish_offset_days": round(float(calc["project_finish_offset_days"]), 6),
        "activities": len(schedule.activities),
        "relationships": len(schedule.relationships),
        "critical_activities": len(calc["critical_activity_ids"]),
        "driving_paths": calc["critical_paths"],
        "constraint_violations": calc["constraint_violations"],
        "qa": qa,
        "schedule_fingerprint": schedule_fingerprint(schedule),
    }


def _select_scenario(result: Dict[str, Any], scenario_id: str = "") -> Dict[str, Any]:
    scenarios = list(result.get("scenarios") or [])
    if not scenarios:
        raise ScenarioValidationError("No valid recovery scenario was generated")
    if scenario_id:
        for scenario in scenarios:
            if scenario.get("id") == scenario_id:
                return scenario
        raise ScenarioValidationError(f"Scenario not found: {scenario_id}")
    return max(
        scenarios,
        key=lambda item: (
            bool(item.get("target_met")),
            float(item.get("score", 0.0)),
            float(item.get("recovery_days", 0.0)),
            -int(item.get("change_count", 0)),
            str(item.get("id", "")),
        ),
    )


def _audit(stage_messages: Iterable[tuple[str, str, str]]) -> list[Dict[str, Any]]:
    log: list[Dict[str, Any]] = []
    for stage, message, actor in stage_messages:
        append_audit_event(log, {"time": utc_now_iso(), "stage": stage, "message": message, "actor": actor})
    return log


def command_analyze(args: argparse.Namespace) -> int:
    schedule = _load_schedule(args.input, hours_per_day=args.hours_per_day, project_id=args.project_id)
    summary = _summary(schedule)
    payload = {
        "summary": summary,
        "schedule": schedule.to_dict(include_raw_tables=False),
    }
    _write(args.out_json, _json_bytes(payload))
    if args.out_xlsx:
        log = _audit([("IMPORT", f"Analyzed {Path(args.input).name}", "CLI")])
        _write(args.out_xlsx, schedule_to_excel_bytes(schedule, {"mode": "CLI_ANALYZE"}, log))
    print(json.dumps(summary, indent=2, ensure_ascii=False, default=str))
    return 0


def command_recover(args: argparse.Namespace) -> int:
    schedule = _load_schedule(args.input, hours_per_day=args.hours_per_day, project_id=args.project_id)
    result = generate_recovery_scenarios(
        schedule,
        target_recovery_days=args.target,
        near_critical_threshold=args.near_critical,
    )
    output: Dict[str, Any] = {
        "engine": ENGINE_ID,
        "base_summary": _summary(schedule),
        "recovery": result,
    }
    target_schedule = schedule
    if args.apply:
        if not args.approved_by.strip():
            raise ScenarioValidationError("--approved-by is required when --apply is used")
        selected = _select_scenario(result, args.scenario_id)
        target_schedule = apply_scenario(schedule, selected, approved_by=args.approved_by.strip())
        for change in target_schedule.changes[-len(selected.get("changes", [])) :]:
            change.evidence_ref = args.approval_reference.strip()
        output.update({
            "selected_scenario": selected,
            "revised_summary": _summary(target_schedule),
            "revised_schedule": target_schedule.to_dict(include_raw_tables=False),
        })
    elif args.scenario_id:
        output["selected_scenario"] = _select_scenario(result, args.scenario_id)

    _write(args.out_json, _json_bytes(output))
    if args.out_xlsx:
        log = _audit([
            ("IMPORT", f"Analyzed {Path(args.input).name}", "CLI"),
            ("RECOVERY", f"Generated {len(result.get('scenarios', []))} scenarios", "CLI"),
        ])
        if args.apply:
            append_audit_event(log, {"stage": "APPLY", "message": "Applied approved scenario to a clone", "actor": args.approved_by})
        _write(args.out_xlsx, schedule_to_excel_bytes(target_schedule, output, log))
    print(json.dumps({
        "scenario_count": len(result.get("scenarios", [])),
        "base_finish_offset_days": result.get("base_finish_offset_days"),
        "target_recovery_days": result.get("target_recovery_days"),
        "selected_scenario_id": (output.get("selected_scenario") or {}).get("id"),
        "output_fingerprint": schedule_fingerprint(target_schedule),
    }, indent=2))
    return 0


def command_package(args: argparse.Namespace) -> int:
    if not args.accept:
        raise ScenarioValidationError("Final package creation requires explicit --accept")
    if not args.reviewer.strip():
        raise ScenarioValidationError("Final package creation requires --reviewer")

    master = _load_schedule(args.input, hours_per_day=args.hours_per_day, project_id=args.project_id)
    recovery = generate_recovery_scenarios(
        master,
        target_recovery_days=args.target,
        near_critical_threshold=args.near_critical,
    )
    scenario = _select_scenario(recovery, args.scenario_id)
    revised = apply_scenario(master, scenario, approved_by=args.reviewer.strip())
    for change in revised.changes[-len(scenario.get("changes", [])) :]:
        change.evidence_ref = args.approval_reference.strip()

    log = _audit([
        ("IMPORT", f"Imported {Path(args.input).name}", "CLI"),
        ("RECOVERY", f"Generated {len(recovery.get('scenarios', []))} deterministic scenarios", "CLI"),
        ("APPLY", f"Applied scenario {scenario.get('id')} to a cloned schedule", args.reviewer.strip()),
        ("ACCEPT", "Reviewer explicitly accepted the revised schedule fingerprint", args.reviewer.strip()),
    ])
    accepted_fingerprint = schedule_fingerprint(revised)
    context = {
        "base_schedule": master,
        "scenario": scenario,
        "target_recovery_days": args.target,
        "accepted_fingerprint": accepted_fingerprint,
        "accepted_by": args.reviewer.strip(),
        "acceptance_reference": args.approval_reference.strip(),
        "accepted_at": utc_now_iso(),
        "mode": "CLI_PACKAGE",
    }
    package = build_final_recovery_package(revised, context, log, accepted=True)
    out = args.out or f"{safe_filename(revised.project_id)}_Recovery_10X_Package.zip"
    _write(out, package)
    print(json.dumps({
        "package": str(Path(out).expanduser().resolve()),
        "bytes": len(package),
        "scenario_id": scenario.get("id"),
        "accepted_fingerprint": accepted_fingerprint,
        "audit_chain": verify_audit_chain(log),
    }, indent=2))
    return 0


def command_verify_package(args: argparse.Namespace) -> int:
    source = Path(args.package).expanduser().resolve()
    failures = []
    checked = 0
    with zipfile.ZipFile(source) as archive:
        names = set(archive.namelist())
        required = {"CHECKSUMS.sha256", "PACKAGE_MANIFEST.json", "READ_ME_FIRST.txt"}
        missing = sorted(required - names)
        if missing:
            failures.append(f"Missing required entries: {missing}")
        if "CHECKSUMS.sha256" in names:
            for line_no, line in enumerate(archive.read("CHECKSUMS.sha256").decode("ascii").splitlines(), start=1):
                if not line.strip():
                    continue
                try:
                    expected, path = line.split("  ", 1)
                except ValueError:
                    failures.append(f"Malformed checksum line {line_no}")
                    continue
                if path not in names:
                    failures.append(f"Missing checksummed file: {path}")
                    continue
                actual = sha256(archive.read(path)).hexdigest()
                checked += 1
                if actual != expected:
                    failures.append(f"Checksum mismatch: {path}")
    result = {"package": str(source), "valid": not failures, "checked_files": checked, "failures": failures}
    print(json.dumps(result, indent=2))
    return 0 if not failures else 2


def command_doctor(args: argparse.Namespace) -> int:
    schedule = _load_schedule(args.input, hours_per_day=args.hours_per_day, project_id=args.project_id)
    plan = build_repair_plan(schedule)
    target = schedule
    repair = None
    if args.apply_safe:
        target, repair = apply_repairs(schedule, safe_only=True, approved_by=args.approved_by or "CLI")
    payload = {"engine": ENGINE_ID, "plan": plan, "repair": repair, "schedule": target.to_dict(include_raw_tables=False), "summary": _summary(target) if not target.metadata.get("cpm_import_error") else {"project_name": target.project_name}}
    _write(args.out_json, _json_bytes(payload))
    if args.out_xlsx:
        _write(args.out_xlsx, schedule_to_excel_bytes(target, {"mode": "CLI_DOCTOR"}, []))
    print(json.dumps({"safe_fix_count": plan["safe_fix_count"], "review_fix_count": plan["review_fix_count"], "applied_count": (repair or {}).get("applied_count", 0)}, indent=2))
    return 0


def command_data_vault(args: argparse.Namespace) -> int:
    source = Path(args.input).expanduser().resolve()
    schedule = _load_schedule(str(source), hours_per_day=args.hours_per_day, project_id=args.project_id)
    payload = build_schedule_data_vault(schedule, summary=_summary(schedule), audit_log=[], source_files=[(source.name, source.read_bytes())])
    out = args.out or f"{safe_filename(schedule.project_name, 'Schedule')}_Data_Vault.zip"
    _write(out, payload)
    print(json.dumps({"out": str(Path(out).resolve()), "bytes": len(payload)}, indent=2))
    return 0


def command_tender_build(args: argparse.Namespace) -> int:
    packed=[]
    for item in args.inputs:
        path=Path(item).expanduser().resolve()
        if not path.is_file(): raise FileNotFoundError(f"Evidence file not found: {path}")
        packed.append((path.name,path.read_bytes()))
    docs=extract_document_pack(packed)
    schedule, build=build_tender_schedule(docs, project_name=args.project_name, data_date=args.data_date or None, mode=args.mode, default_duration_days=args.default_duration)
    calculate_cpm(schedule)
    _write(args.out_json, _json_bytes({"evidence": evidence_summary(docs), "build": build, "schedule": schedule.to_dict(include_raw_tables=False), "summary": _summary(schedule)}))
    if args.out_xlsx: _write(args.out_xlsx, schedule_to_excel_bytes(schedule, {"mode":"CLI_TENDER_BUILD"}, []))
    if args.out_vault: _write(args.out_vault, build_schedule_data_vault(schedule, summary=_summary(schedule), audit_log=[], source_files=packed))
    print(json.dumps({"project":schedule.project_name,"mode":build["mode"],"evidence_documents":len(docs),"activities":len(schedule.activities),"assumed_durations":build["assumed_duration_count"]},indent=2))
    return 0


def command_report_fill(args: argparse.Namespace) -> int:
    template=Path(args.template).expanduser().resolve()
    if not template.is_file(): raise FileNotFoundError(f"Template not found: {template}")
    data={}
    if args.data:
        data_path=Path(args.data).expanduser().resolve()
        if not data_path.is_file(): raise FileNotFoundError(f"Data file not found: {data_path}")
        data=load_report_data(data_path.name,data_path.read_bytes())
    content, _media, ext=render_template(template.name,template.read_bytes(),data)
    out=args.out or str(template.with_name(template.stem+"_POPULATED"+ext))
    _write(out,content)
    print(json.dumps({"out":str(Path(out).resolve()),"bytes":len(content)},indent=2))
    return 0


def command_serve(args: argparse.Namespace) -> int:
    import uvicorn

    uvicorn.run("app:app", host=args.host, port=args.port, reload=args.reload)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="pri10x", description=ENGINE_ID)
    parser.add_argument("--version", action="version", version=f"%(prog)s {VERSION}")
    sub = parser.add_subparsers(dest="command", required=True)

    def common_input(command):
        command.add_argument("input", help="Input schedule: .xer, .json, .xlsx, .xlsm, .csv, .tsv or .xml")
        command.add_argument("--hours-per-day", type=float, default=8.0)
        command.add_argument("--project-id", default="", help="Internal XER project ID or project short name")

    analyze = sub.add_parser("analyze", help="Calculate CPM, QA and fingerprints")
    common_input(analyze)
    analyze.add_argument("--out-json")
    analyze.add_argument("--out-xlsx")
    analyze.set_defaults(func=command_analyze)

    recover = sub.add_parser("recover", help="Generate recovery scenarios and optionally apply one to a clone")
    common_input(recover)
    recover.add_argument("--target", type=float, default=0.0, help="Target recovery in working days")
    recover.add_argument("--near-critical", type=float, default=5.0)
    recover.add_argument("--scenario-id", default="")
    recover.add_argument("--apply", action="store_true", help="Apply the selected/best scenario to a clone")
    recover.add_argument("--approved-by", default="")
    recover.add_argument("--approval-reference", default="")
    recover.add_argument("--out-json")
    recover.add_argument("--out-xlsx")
    recover.set_defaults(func=command_recover)

    package = sub.add_parser("package", help="Create a checksum-verified accepted recovery package")
    common_input(package)
    package.add_argument("--target", type=float, default=0.0)
    package.add_argument("--near-critical", type=float, default=5.0)
    package.add_argument("--scenario-id", default="")
    package.add_argument("--accept", action="store_true", help="Explicitly accept the generated clone")
    package.add_argument("--reviewer", default="")
    package.add_argument("--approval-reference", default="")
    package.add_argument("--out", required=True)
    package.set_defaults(func=command_package)

    doctor = sub.add_parser("doctor", help="Diagnose schedule faults and optionally apply deterministic safe fixes to a clone")
    common_input(doctor)
    doctor.add_argument("--apply-safe", action="store_true")
    doctor.add_argument("--approved-by", default="")
    doctor.add_argument("--out-json")
    doctor.add_argument("--out-xlsx")
    doctor.set_defaults(func=command_doctor)

    vault = sub.add_parser("data-vault", help="Export all normalized, raw, QA and source data to a checksum-controlled ZIP")
    common_input(vault)
    vault.add_argument("--out")
    vault.set_defaults(func=command_data_vault)

    tender = sub.add_parser("tender-build", help="Build a tender or detailed schedule from mixed evidence documents")
    tender.add_argument("inputs", nargs="+", help="Evidence files and/or ZIP packs")
    tender.add_argument("--project-name", default="Tender / Detailed Schedule")
    tender.add_argument("--data-date", default="")
    tender.add_argument("--mode", choices=["TENDER","DETAILED"], default="TENDER")
    tender.add_argument("--default-duration", type=float, default=5.0)
    tender.add_argument("--out-json")
    tender.add_argument("--out-xlsx")
    tender.add_argument("--out-vault")
    tender.set_defaults(func=command_tender_build)

    report = sub.add_parser("report-fill", help="Populate an existing report/template with structured data")
    report.add_argument("template")
    report.add_argument("--data")
    report.add_argument("--out")
    report.set_defaults(func=command_report_fill)

    verify = sub.add_parser("verify-package", help="Verify every SHA-256 entry in a recovery package")
    verify.add_argument("package")
    verify.set_defaults(func=command_verify_package)

    serve = sub.add_parser("serve", help="Run the local web application")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8765)
    serve.add_argument("--reload", action="store_true")
    serve.set_defaults(func=command_serve)
    return parser


def main(argv: Optional[list[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if getattr(args, "hours_per_day", 8.0) <= 0 or getattr(args, "hours_per_day", 8.0) > 24:
            parser.error("--hours-per-day must be greater than 0 and not greater than 24")
        if getattr(args, "target", 0.0) < 0:
            parser.error("--target cannot be negative")
        return int(args.func(args))
    except (ScheduleError, ValueError, FileNotFoundError, zipfile.BadZipFile) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
